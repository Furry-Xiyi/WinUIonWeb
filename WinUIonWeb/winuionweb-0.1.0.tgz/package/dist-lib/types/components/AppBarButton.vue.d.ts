import { type PropType } from 'vue';
import { xamlControlIdentityKey } from './xamlRuntime';
export declare const AppBarButtonFlyout: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const AppBarButtonIcon: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const AppBarButtonContent: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const AppBarButtonKeyboardAccelerators: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Label: {
        type: StringConstructor;
        default: undefined;
    };
    Icon: {
        type: PropType<unknown>;
        default: unknown;
    };
    Content: {
        type: PropType<unknown>;
        default: unknown;
    };
    Command: {
        type: PropType<unknown>;
        default: unknown;
    };
    CommandParameter: {
        type: PropType<unknown>;
        default: unknown;
    };
    Flyout: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsCompact: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    LabelPosition: {
        type: StringConstructor;
        default: string;
    };
    DynamicOverflowOrder: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    AllowFocusOnInteraction: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    AllowFocusWhenDisabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    KeyboardAccelerators: {
        type: PropType<unknown>;
        default: unknown;
    };
    KeyboardAcceleratorTextOverride: {
        type: StringConstructor;
        default: string;
    };
    KeyboardAcceleratorPlacementMode: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: PropType<unknown>;
        default: unknown;
    };
    Foreground: {
        type: PropType<unknown>;
        default: unknown;
    };
    BorderBrush: {
        type: PropType<unknown>;
        default: unknown;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    FontFamily: {
        type: StringConstructor;
        default: undefined;
    };
    FontWeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
    Style: {
        type: PropType<unknown>;
        default: unknown;
    };
    'AutomationProperties.Name': {
        type: StringConstructor;
        default: string;
    };
    'ToolTipService.ToolTip': {
        type: PropType<unknown>;
        default: unknown;
    };
}>, {
    [xamlControlIdentityKey]: boolean;
    Name: import("vue").ComputedRef<string>;
    IsInOverflow: import("vue").ComputedRef<boolean>;
    Label: import("vue").WritableComputedRef<string, string>;
    IsEnabled: import("vue").WritableComputedRef<boolean, boolean>;
    ActualWidth: import("vue").ComputedRef<number>;
    ActualHeight: import("vue").ComputedRef<number>;
    Focus: () => boolean;
    $el: import("vue").Ref<HTMLButtonElement | null, HTMLButtonElement | null>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Click: (...args: any[]) => void;
    KeyDown: (...args: any[]) => void;
    GotFocus: (...args: any[]) => void;
    LostFocus: (...args: any[]) => void;
    PointerMoved: (...args: any[]) => void;
    PointerPressed: (...args: any[]) => void;
    PointerReleased: (...args: any[]) => void;
    PointerEntered: (...args: any[]) => void;
    PointerExited: (...args: any[]) => void;
    PointerCanceled: (...args: any[]) => void;
    PointerCaptureLost: (...args: any[]) => void;
    KeyUp: (...args: any[]) => void;
    "update:Foreground": (...args: any[]) => void;
    "update:Label": (...args: any[]) => void;
    "update:Icon": (...args: any[]) => void;
    "update:Content": (...args: any[]) => void;
    "update:Command": (...args: any[]) => void;
    "update:CommandParameter": (...args: any[]) => void;
    "update:Flyout": (...args: any[]) => void;
    "update:IsCompact": (...args: any[]) => void;
    "update:LabelPosition": (...args: any[]) => void;
    "update:DynamicOverflowOrder": (...args: any[]) => void;
    "update:IsEnabled": (...args: any[]) => void;
    "update:IsTabStop": (...args: any[]) => void;
    "update:Visibility": (...args: any[]) => void;
    "update:AllowFocusOnInteraction": (...args: any[]) => void;
    "update:AllowFocusWhenDisabled": (...args: any[]) => void;
    "update:KeyboardAccelerators": (...args: any[]) => void;
    "update:KeyboardAcceleratorTextOverride": (...args: any[]) => void;
    "update:KeyboardAcceleratorPlacementMode": (...args: any[]) => void;
    "update:Background": (...args: any[]) => void;
    "update:BorderBrush": (...args: any[]) => void;
    "update:BorderThickness": (...args: any[]) => void;
    "update:CornerRadius": (...args: any[]) => void;
    "update:Padding": (...args: any[]) => void;
    "update:Margin": (...args: any[]) => void;
    "update:Width": (...args: any[]) => void;
    "update:Height": (...args: any[]) => void;
    "update:MinWidth": (...args: any[]) => void;
    "update:MinHeight": (...args: any[]) => void;
    "update:MaxWidth": (...args: any[]) => void;
    "update:MaxHeight": (...args: any[]) => void;
    "update:FontFamily": (...args: any[]) => void;
    "update:FontWeight": (...args: any[]) => void;
    "update:FontSize": (...args: any[]) => void;
    "update:HorizontalAlignment": (...args: any[]) => void;
    "update:VerticalAlignment": (...args: any[]) => void;
    "update:HorizontalContentAlignment": (...args: any[]) => void;
    "update:VerticalContentAlignment": (...args: any[]) => void;
    "update:FlowDirection": (...args: any[]) => void;
    "update:Style": (...args: any[]) => void;
    "update:AutomationProperties.Name": (...args: any[]) => void;
    "update:ToolTipService.ToolTip": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Label: {
        type: StringConstructor;
        default: undefined;
    };
    Icon: {
        type: PropType<unknown>;
        default: unknown;
    };
    Content: {
        type: PropType<unknown>;
        default: unknown;
    };
    Command: {
        type: PropType<unknown>;
        default: unknown;
    };
    CommandParameter: {
        type: PropType<unknown>;
        default: unknown;
    };
    Flyout: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsCompact: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    LabelPosition: {
        type: StringConstructor;
        default: string;
    };
    DynamicOverflowOrder: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    AllowFocusOnInteraction: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    AllowFocusWhenDisabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    KeyboardAccelerators: {
        type: PropType<unknown>;
        default: unknown;
    };
    KeyboardAcceleratorTextOverride: {
        type: StringConstructor;
        default: string;
    };
    KeyboardAcceleratorPlacementMode: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: PropType<unknown>;
        default: unknown;
    };
    Foreground: {
        type: PropType<unknown>;
        default: unknown;
    };
    BorderBrush: {
        type: PropType<unknown>;
        default: unknown;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    FontFamily: {
        type: StringConstructor;
        default: undefined;
    };
    FontWeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
    Style: {
        type: PropType<unknown>;
        default: unknown;
    };
    'AutomationProperties.Name': {
        type: StringConstructor;
        default: string;
    };
    'ToolTipService.ToolTip': {
        type: PropType<unknown>;
        default: unknown;
    };
}>> & Readonly<{
    onClick?: ((...args: any[]) => any) | undefined;
    onKeyDown?: ((...args: any[]) => any) | undefined;
    onGotFocus?: ((...args: any[]) => any) | undefined;
    onLostFocus?: ((...args: any[]) => any) | undefined;
    onPointerMoved?: ((...args: any[]) => any) | undefined;
    onPointerPressed?: ((...args: any[]) => any) | undefined;
    onPointerReleased?: ((...args: any[]) => any) | undefined;
    onPointerEntered?: ((...args: any[]) => any) | undefined;
    onPointerExited?: ((...args: any[]) => any) | undefined;
    onPointerCanceled?: ((...args: any[]) => any) | undefined;
    onPointerCaptureLost?: ((...args: any[]) => any) | undefined;
    onKeyUp?: ((...args: any[]) => any) | undefined;
    "onUpdate:Foreground"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Icon"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Content"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Command"?: ((...args: any[]) => any) | undefined;
    "onUpdate:CommandParameter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Flyout"?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsCompact"?: ((...args: any[]) => any) | undefined;
    "onUpdate:LabelPosition"?: ((...args: any[]) => any) | undefined;
    "onUpdate:DynamicOverflowOrder"?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsTabStop"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Visibility"?: ((...args: any[]) => any) | undefined;
    "onUpdate:AllowFocusOnInteraction"?: ((...args: any[]) => any) | undefined;
    "onUpdate:AllowFocusWhenDisabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:KeyboardAccelerators"?: ((...args: any[]) => any) | undefined;
    "onUpdate:KeyboardAcceleratorTextOverride"?: ((...args: any[]) => any) | undefined;
    "onUpdate:KeyboardAcceleratorPlacementMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Background"?: ((...args: any[]) => any) | undefined;
    "onUpdate:BorderBrush"?: ((...args: any[]) => any) | undefined;
    "onUpdate:BorderThickness"?: ((...args: any[]) => any) | undefined;
    "onUpdate:CornerRadius"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Padding"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:MinWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:MinHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:MaxWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:MaxHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:FontFamily"?: ((...args: any[]) => any) | undefined;
    "onUpdate:FontWeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:FontSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:HorizontalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:VerticalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:HorizontalContentAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:VerticalContentAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:FlowDirection"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Style"?: ((...args: any[]) => any) | undefined;
    "onUpdate:AutomationProperties.Name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ToolTipService.ToolTip"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: unknown;
    Command: unknown;
    KeyboardAccelerators: unknown;
    Label: string;
    IsEnabled: string | boolean;
    Background: unknown;
    BorderBrush: unknown;
    BorderThickness: string | number;
    CornerRadius: string | number;
    FontSize: string | number;
    HorizontalContentAlignment: string;
    VerticalContentAlignment: string;
    KeyboardAcceleratorPlacementMode: string;
    IsTabStop: string | boolean;
    FontFamily: string;
    FontWeight: string | number;
    Flyout: unknown;
    Style: unknown;
    'ToolTipService.ToolTip': unknown;
    Visibility: string;
    Content: unknown;
    FlowDirection: string;
    'AutomationProperties.Name': string;
    CommandParameter: unknown;
    Icon: unknown;
    IsCompact: string | boolean;
    LabelPosition: string;
    DynamicOverflowOrder: string | number;
    AllowFocusOnInteraction: string | boolean;
    AllowFocusWhenDisabled: string | boolean;
    KeyboardAcceleratorTextOverride: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
