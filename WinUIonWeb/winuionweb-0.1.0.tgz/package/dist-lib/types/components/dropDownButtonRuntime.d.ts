import { type ComputedRef, type Ref } from 'vue';
type GlyphInput = Record<string, (...args: any[]) => void>;
export declare const useDropDownButtonInput: (element: Ref<HTMLButtonElement | null>, enabled: ComputedRef<boolean>, clickMode: ComputedRef<string>, invoke: (event: Event) => void, raise: (name: string, event: Event, extra?: Record<string, unknown>) => boolean, glyph: GlyphInput) => {
    IsPressed: Ref<boolean, boolean>;
    IsPointerOver: Ref<boolean, boolean>;
    clearPressed: () => void;
    onPointerEntered: (event: PointerEvent) => void;
    onPointerExited: (event: PointerEvent) => void;
    onPointerPressed: (event: PointerEvent) => void;
    onPointerMoved: (event: PointerEvent) => void;
    onPointerReleased: (event: PointerEvent) => void;
    onPointerCanceled: (event: PointerEvent) => void;
    onPointerCaptureLost: (event: PointerEvent) => void;
    onKeyDown: (event: KeyboardEvent) => void;
    onKeyUp: (event: KeyboardEvent) => void;
    onNativeClick: (event: MouseEvent) => void;
};
export {};
