declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Content: {
        default: undefined;
    };
    PrimaryCommands: {
        default: undefined;
    };
    SecondaryCommands: {
        default: undefined;
    };
    IsOpen: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsSticky: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsDynamicOverflowEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    DefaultLabelPosition: {
        type: StringConstructor;
        default: string;
    };
    ClosedDisplayMode: {
        type: StringConstructor;
        default: string;
    };
    OverflowButtonVisibility: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        default: undefined;
    };
    Foreground: {
        default: undefined;
    };
    Padding: {
        default: string;
    };
    CornerRadius: {
        default: undefined;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
}>, Record<string, unknown>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Opening: (...args: any[]) => void;
    Opened: (...args: any[]) => void;
    Closing: (...args: any[]) => void;
    Closed: (...args: any[]) => void;
    DynamicOverflowItemsChanging: (...args: any[]) => void;
    "update:IsOpen": (...args: any[]) => void;
    "update:Foreground": (...args: any[]) => void;
    "update:Content": (...args: any[]) => void;
    "update:IsEnabled": (...args: any[]) => void;
    "update:Background": (...args: any[]) => void;
    "update:CornerRadius": (...args: any[]) => void;
    "update:Padding": (...args: any[]) => void;
    "update:HorizontalAlignment": (...args: any[]) => void;
    "update:IsSticky": (...args: any[]) => void;
    "update:IsDynamicOverflowEnabled": (...args: any[]) => void;
    "update:DefaultLabelPosition": (...args: any[]) => void;
    "update:ClosedDisplayMode": (...args: any[]) => void;
    "update:OverflowButtonVisibility": (...args: any[]) => void;
    "update:PrimaryCommands": (...args: any[]) => void;
    "update:SecondaryCommands": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Content: {
        default: undefined;
    };
    PrimaryCommands: {
        default: undefined;
    };
    SecondaryCommands: {
        default: undefined;
    };
    IsOpen: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsSticky: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsDynamicOverflowEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    DefaultLabelPosition: {
        type: StringConstructor;
        default: string;
    };
    ClosedDisplayMode: {
        type: StringConstructor;
        default: string;
    };
    OverflowButtonVisibility: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        default: undefined;
    };
    Foreground: {
        default: undefined;
    };
    Padding: {
        default: string;
    };
    CornerRadius: {
        default: undefined;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onOpening?: ((...args: any[]) => any) | undefined;
    onOpened?: ((...args: any[]) => any) | undefined;
    onClosing?: ((...args: any[]) => any) | undefined;
    onClosed?: ((...args: any[]) => any) | undefined;
    onDynamicOverflowItemsChanging?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsOpen"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Foreground"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Content"?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Background"?: ((...args: any[]) => any) | undefined;
    "onUpdate:CornerRadius"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Padding"?: ((...args: any[]) => any) | undefined;
    "onUpdate:HorizontalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsSticky"?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsDynamicOverflowEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:DefaultLabelPosition"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ClosedDisplayMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:OverflowButtonVisibility"?: ((...args: any[]) => any) | undefined;
    "onUpdate:PrimaryCommands"?: ((...args: any[]) => any) | undefined;
    "onUpdate:SecondaryCommands"?: ((...args: any[]) => any) | undefined;
}>, {
    Padding: string;
    HorizontalAlignment: string;
    Foreground: undefined;
    IsEnabled: string | boolean;
    Background: undefined;
    CornerRadius: undefined;
    Content: undefined;
    IsOpen: string | boolean;
    PrimaryCommands: undefined;
    SecondaryCommands: undefined;
    IsSticky: string | boolean;
    IsDynamicOverflowEnabled: string | boolean;
    DefaultLabelPosition: string;
    ClosedDisplayMode: string;
    OverflowButtonVisibility: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
