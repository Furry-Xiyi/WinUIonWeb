import { type PropType, type VNode } from 'vue';
export declare const MenuFlyoutItemsProperty: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const MenuFlyoutPresenterStyleProperty: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const MenuFlyoutItemIcon: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const MenuFlyoutItemKeyboardAccelerators: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const MenuFlyoutSubItemItems: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const KeyboardAccelerator: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Key: {
        type: StringConstructor;
        default: string;
    };
    Modifiers: {
        type: (StringConstructor | ArrayConstructor)[];
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
}>, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Key: {
        type: StringConstructor;
        default: string;
    };
    Modifiers: {
        type: (StringConstructor | ArrayConstructor)[];
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
}>> & Readonly<{}>, {
    Key: string;
    Modifiers: string | unknown[];
    IsEnabled: string | boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const MenuFlyoutItem: {
    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
        Text: {
            type: (NumberConstructor | StringConstructor)[];
            default: undefined;
        };
        Icon: {
            type: PropType<unknown>;
            default: unknown;
        };
        Tag: {
            type: PropType<unknown>;
            default: unknown;
        };
        DataContext: {
            type: PropType<unknown>;
            default: unknown;
        };
        Command: {
            type: PropType<unknown>;
            default: unknown;
        };
        CommandParameter: {
            type: PropType<unknown>;
            default: unknown;
        };
        IsEnabled: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        IsChecked: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        GroupName: {
            type: StringConstructor;
            default: string;
        };
        KeyboardAccelerators: {
            type: PropType<unknown[] | string>;
            default: undefined;
        };
        KeyboardAcceleratorTextOverride: {
            type: StringConstructor;
            default: string;
        };
        KeyboardAcceleratorPlacementMode: {
            type: StringConstructor;
            default: string;
        };
        PreventDismissOnPointer: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        Items: {
            type: PropType<VNode[] | string>;
            default: undefined;
        };
        Foreground: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        Background: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        BorderBrush: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        BorderThickness: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        Padding: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        CornerRadius: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        FontFamily: {
            type: StringConstructor;
            default: string;
        };
        FontSize: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        FontWeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        HorizontalContentAlignment: {
            type: StringConstructor;
            default: string;
        };
        VerticalContentAlignment: {
            type: StringConstructor;
            default: string;
        };
        Width: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        Height: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        MinWidth: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        MinHeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        MaxWidth: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        MaxHeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        Margin: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        HorizontalAlignment: {
            type: StringConstructor;
            default: string;
        };
        VerticalAlignment: {
            type: StringConstructor;
            default: string;
        };
        FlowDirection: {
            type: StringConstructor;
            default: string;
        };
        Visibility: {
            type: StringConstructor;
            default: string;
        };
        IsTabStop: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
    }>> & Readonly<{
        [x: `on${Capitalize<string>}`]: ((...args: any[]) => any) | undefined;
    }>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, string[], import("vue").PublicProps, {
        Width: string | number;
        Height: string | number;
        MinWidth: string | number;
        MaxWidth: string | number;
        MinHeight: string | number;
        MaxHeight: string | number;
        Margin: string | number;
        Padding: string | number;
        HorizontalAlignment: string;
        VerticalAlignment: string;
        Foreground: string | Record<string, any>;
        Command: unknown;
        KeyboardAccelerators: string | unknown[];
        IsEnabled: string | boolean;
        Background: string | Record<string, any>;
        BorderBrush: string | Record<string, any>;
        BorderThickness: string | number;
        CornerRadius: string | number;
        FontSize: string | number;
        HorizontalContentAlignment: string;
        VerticalContentAlignment: string;
        KeyboardAcceleratorPlacementMode: string;
        IsTabStop: string | boolean;
        FontFamily: string;
        FontWeight: string | number;
        IsChecked: string | boolean;
        Text: string | number;
        Visibility: string;
        DataContext: unknown;
        FlowDirection: string;
        Tag: unknown;
        CommandParameter: unknown;
        Icon: unknown;
        KeyboardAcceleratorTextOverride: string;
        Items: string | VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>[];
        GroupName: string;
        PreventDismissOnPointer: string | boolean;
    }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        Text: {
            type: (NumberConstructor | StringConstructor)[];
            default: undefined;
        };
        Icon: {
            type: PropType<unknown>;
            default: unknown;
        };
        Tag: {
            type: PropType<unknown>;
            default: unknown;
        };
        DataContext: {
            type: PropType<unknown>;
            default: unknown;
        };
        Command: {
            type: PropType<unknown>;
            default: unknown;
        };
        CommandParameter: {
            type: PropType<unknown>;
            default: unknown;
        };
        IsEnabled: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        IsChecked: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        GroupName: {
            type: StringConstructor;
            default: string;
        };
        KeyboardAccelerators: {
            type: PropType<unknown[] | string>;
            default: undefined;
        };
        KeyboardAcceleratorTextOverride: {
            type: StringConstructor;
            default: string;
        };
        KeyboardAcceleratorPlacementMode: {
            type: StringConstructor;
            default: string;
        };
        PreventDismissOnPointer: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        Items: {
            type: PropType<VNode[] | string>;
            default: undefined;
        };
        Foreground: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        Background: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        BorderBrush: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        BorderThickness: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        Padding: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        CornerRadius: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        FontFamily: {
            type: StringConstructor;
            default: string;
        };
        FontSize: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        FontWeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        HorizontalContentAlignment: {
            type: StringConstructor;
            default: string;
        };
        VerticalContentAlignment: {
            type: StringConstructor;
            default: string;
        };
        Width: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        Height: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        MinWidth: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        MinHeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        MaxWidth: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        MaxHeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        Margin: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        HorizontalAlignment: {
            type: StringConstructor;
            default: string;
        };
        VerticalAlignment: {
            type: StringConstructor;
            default: string;
        };
        FlowDirection: {
            type: StringConstructor;
            default: string;
        };
        Visibility: {
            type: StringConstructor;
            default: string;
        };
        IsTabStop: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
    }>> & Readonly<{
        [x: `on${Capitalize<string>}`]: ((...args: any[]) => any) | undefined;
    }>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>, {}, {}, {}, {
        Width: string | number;
        Height: string | number;
        MinWidth: string | number;
        MaxWidth: string | number;
        MinHeight: string | number;
        MaxHeight: string | number;
        Margin: string | number;
        Padding: string | number;
        HorizontalAlignment: string;
        VerticalAlignment: string;
        Foreground: string | Record<string, any>;
        Command: unknown;
        KeyboardAccelerators: string | unknown[];
        IsEnabled: string | boolean;
        Background: string | Record<string, any>;
        BorderBrush: string | Record<string, any>;
        BorderThickness: string | number;
        CornerRadius: string | number;
        FontSize: string | number;
        HorizontalContentAlignment: string;
        VerticalContentAlignment: string;
        KeyboardAcceleratorPlacementMode: string;
        IsTabStop: string | boolean;
        FontFamily: string;
        FontWeight: string | number;
        IsChecked: string | boolean;
        Text: string | number;
        Visibility: string;
        DataContext: unknown;
        FlowDirection: string;
        Tag: unknown;
        CommandParameter: unknown;
        Icon: unknown;
        KeyboardAcceleratorTextOverride: string;
        Items: string | VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>[];
        GroupName: string;
        PreventDismissOnPointer: string | boolean;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    Text: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Icon: {
        type: PropType<unknown>;
        default: unknown;
    };
    Tag: {
        type: PropType<unknown>;
        default: unknown;
    };
    DataContext: {
        type: PropType<unknown>;
        default: unknown;
    };
    Command: {
        type: PropType<unknown>;
        default: unknown;
    };
    CommandParameter: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsChecked: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    GroupName: {
        type: StringConstructor;
        default: string;
    };
    KeyboardAccelerators: {
        type: PropType<unknown[] | string>;
        default: undefined;
    };
    KeyboardAcceleratorTextOverride: {
        type: StringConstructor;
        default: string;
    };
    KeyboardAcceleratorPlacementMode: {
        type: StringConstructor;
        default: string;
    };
    PreventDismissOnPointer: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Items: {
        type: PropType<VNode[] | string>;
        default: undefined;
    };
    Foreground: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderBrush: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FontWeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
}>> & Readonly<{
    [x: `on${Capitalize<string>}`]: ((...args: any[]) => any) | undefined;
}>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, string[], string, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string | Record<string, any>;
    Command: unknown;
    KeyboardAccelerators: string | unknown[];
    IsEnabled: string | boolean;
    Background: string | Record<string, any>;
    BorderBrush: string | Record<string, any>;
    BorderThickness: string | number;
    CornerRadius: string | number;
    FontSize: string | number;
    HorizontalContentAlignment: string;
    VerticalContentAlignment: string;
    KeyboardAcceleratorPlacementMode: string;
    IsTabStop: string | boolean;
    FontFamily: string;
    FontWeight: string | number;
    IsChecked: string | boolean;
    Text: string | number;
    Visibility: string;
    DataContext: unknown;
    FlowDirection: string;
    Tag: unknown;
    CommandParameter: unknown;
    Icon: unknown;
    KeyboardAcceleratorTextOverride: string;
    Items: string | VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>[];
    GroupName: string;
    PreventDismissOnPointer: string | boolean;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & {
    Icon: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    KeyboardAccelerators: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    Items: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
};
export declare const ToggleMenuFlyoutItem: {
    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
        Text: {
            type: (NumberConstructor | StringConstructor)[];
            default: undefined;
        };
        Icon: {
            type: PropType<unknown>;
            default: unknown;
        };
        Tag: {
            type: PropType<unknown>;
            default: unknown;
        };
        DataContext: {
            type: PropType<unknown>;
            default: unknown;
        };
        Command: {
            type: PropType<unknown>;
            default: unknown;
        };
        CommandParameter: {
            type: PropType<unknown>;
            default: unknown;
        };
        IsEnabled: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        IsChecked: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        GroupName: {
            type: StringConstructor;
            default: string;
        };
        KeyboardAccelerators: {
            type: PropType<unknown[] | string>;
            default: undefined;
        };
        KeyboardAcceleratorTextOverride: {
            type: StringConstructor;
            default: string;
        };
        KeyboardAcceleratorPlacementMode: {
            type: StringConstructor;
            default: string;
        };
        PreventDismissOnPointer: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        Items: {
            type: PropType<VNode[] | string>;
            default: undefined;
        };
        Foreground: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        Background: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        BorderBrush: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        BorderThickness: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        Padding: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        CornerRadius: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        FontFamily: {
            type: StringConstructor;
            default: string;
        };
        FontSize: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        FontWeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        HorizontalContentAlignment: {
            type: StringConstructor;
            default: string;
        };
        VerticalContentAlignment: {
            type: StringConstructor;
            default: string;
        };
        Width: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        Height: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        MinWidth: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        MinHeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        MaxWidth: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        MaxHeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        Margin: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        HorizontalAlignment: {
            type: StringConstructor;
            default: string;
        };
        VerticalAlignment: {
            type: StringConstructor;
            default: string;
        };
        FlowDirection: {
            type: StringConstructor;
            default: string;
        };
        Visibility: {
            type: StringConstructor;
            default: string;
        };
        IsTabStop: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
    }>> & Readonly<{
        [x: `on${Capitalize<string>}`]: ((...args: any[]) => any) | undefined;
    }>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, string[], import("vue").PublicProps, {
        Width: string | number;
        Height: string | number;
        MinWidth: string | number;
        MaxWidth: string | number;
        MinHeight: string | number;
        MaxHeight: string | number;
        Margin: string | number;
        Padding: string | number;
        HorizontalAlignment: string;
        VerticalAlignment: string;
        Foreground: string | Record<string, any>;
        Command: unknown;
        KeyboardAccelerators: string | unknown[];
        IsEnabled: string | boolean;
        Background: string | Record<string, any>;
        BorderBrush: string | Record<string, any>;
        BorderThickness: string | number;
        CornerRadius: string | number;
        FontSize: string | number;
        HorizontalContentAlignment: string;
        VerticalContentAlignment: string;
        KeyboardAcceleratorPlacementMode: string;
        IsTabStop: string | boolean;
        FontFamily: string;
        FontWeight: string | number;
        IsChecked: string | boolean;
        Text: string | number;
        Visibility: string;
        DataContext: unknown;
        FlowDirection: string;
        Tag: unknown;
        CommandParameter: unknown;
        Icon: unknown;
        KeyboardAcceleratorTextOverride: string;
        Items: string | VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>[];
        GroupName: string;
        PreventDismissOnPointer: string | boolean;
    }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        Text: {
            type: (NumberConstructor | StringConstructor)[];
            default: undefined;
        };
        Icon: {
            type: PropType<unknown>;
            default: unknown;
        };
        Tag: {
            type: PropType<unknown>;
            default: unknown;
        };
        DataContext: {
            type: PropType<unknown>;
            default: unknown;
        };
        Command: {
            type: PropType<unknown>;
            default: unknown;
        };
        CommandParameter: {
            type: PropType<unknown>;
            default: unknown;
        };
        IsEnabled: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        IsChecked: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        GroupName: {
            type: StringConstructor;
            default: string;
        };
        KeyboardAccelerators: {
            type: PropType<unknown[] | string>;
            default: undefined;
        };
        KeyboardAcceleratorTextOverride: {
            type: StringConstructor;
            default: string;
        };
        KeyboardAcceleratorPlacementMode: {
            type: StringConstructor;
            default: string;
        };
        PreventDismissOnPointer: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        Items: {
            type: PropType<VNode[] | string>;
            default: undefined;
        };
        Foreground: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        Background: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        BorderBrush: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        BorderThickness: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        Padding: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        CornerRadius: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        FontFamily: {
            type: StringConstructor;
            default: string;
        };
        FontSize: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        FontWeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        HorizontalContentAlignment: {
            type: StringConstructor;
            default: string;
        };
        VerticalContentAlignment: {
            type: StringConstructor;
            default: string;
        };
        Width: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        Height: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        MinWidth: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        MinHeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        MaxWidth: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        MaxHeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        Margin: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        HorizontalAlignment: {
            type: StringConstructor;
            default: string;
        };
        VerticalAlignment: {
            type: StringConstructor;
            default: string;
        };
        FlowDirection: {
            type: StringConstructor;
            default: string;
        };
        Visibility: {
            type: StringConstructor;
            default: string;
        };
        IsTabStop: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
    }>> & Readonly<{
        [x: `on${Capitalize<string>}`]: ((...args: any[]) => any) | undefined;
    }>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>, {}, {}, {}, {
        Width: string | number;
        Height: string | number;
        MinWidth: string | number;
        MaxWidth: string | number;
        MinHeight: string | number;
        MaxHeight: string | number;
        Margin: string | number;
        Padding: string | number;
        HorizontalAlignment: string;
        VerticalAlignment: string;
        Foreground: string | Record<string, any>;
        Command: unknown;
        KeyboardAccelerators: string | unknown[];
        IsEnabled: string | boolean;
        Background: string | Record<string, any>;
        BorderBrush: string | Record<string, any>;
        BorderThickness: string | number;
        CornerRadius: string | number;
        FontSize: string | number;
        HorizontalContentAlignment: string;
        VerticalContentAlignment: string;
        KeyboardAcceleratorPlacementMode: string;
        IsTabStop: string | boolean;
        FontFamily: string;
        FontWeight: string | number;
        IsChecked: string | boolean;
        Text: string | number;
        Visibility: string;
        DataContext: unknown;
        FlowDirection: string;
        Tag: unknown;
        CommandParameter: unknown;
        Icon: unknown;
        KeyboardAcceleratorTextOverride: string;
        Items: string | VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>[];
        GroupName: string;
        PreventDismissOnPointer: string | boolean;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    Text: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Icon: {
        type: PropType<unknown>;
        default: unknown;
    };
    Tag: {
        type: PropType<unknown>;
        default: unknown;
    };
    DataContext: {
        type: PropType<unknown>;
        default: unknown;
    };
    Command: {
        type: PropType<unknown>;
        default: unknown;
    };
    CommandParameter: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsChecked: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    GroupName: {
        type: StringConstructor;
        default: string;
    };
    KeyboardAccelerators: {
        type: PropType<unknown[] | string>;
        default: undefined;
    };
    KeyboardAcceleratorTextOverride: {
        type: StringConstructor;
        default: string;
    };
    KeyboardAcceleratorPlacementMode: {
        type: StringConstructor;
        default: string;
    };
    PreventDismissOnPointer: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Items: {
        type: PropType<VNode[] | string>;
        default: undefined;
    };
    Foreground: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderBrush: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FontWeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
}>> & Readonly<{
    [x: `on${Capitalize<string>}`]: ((...args: any[]) => any) | undefined;
}>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, string[], string, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string | Record<string, any>;
    Command: unknown;
    KeyboardAccelerators: string | unknown[];
    IsEnabled: string | boolean;
    Background: string | Record<string, any>;
    BorderBrush: string | Record<string, any>;
    BorderThickness: string | number;
    CornerRadius: string | number;
    FontSize: string | number;
    HorizontalContentAlignment: string;
    VerticalContentAlignment: string;
    KeyboardAcceleratorPlacementMode: string;
    IsTabStop: string | boolean;
    FontFamily: string;
    FontWeight: string | number;
    IsChecked: string | boolean;
    Text: string | number;
    Visibility: string;
    DataContext: unknown;
    FlowDirection: string;
    Tag: unknown;
    CommandParameter: unknown;
    Icon: unknown;
    KeyboardAcceleratorTextOverride: string;
    Items: string | VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>[];
    GroupName: string;
    PreventDismissOnPointer: string | boolean;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & {
    Icon: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    KeyboardAccelerators: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    Items: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
};
export declare const RadioMenuFlyoutItem: {
    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
        Text: {
            type: (NumberConstructor | StringConstructor)[];
            default: undefined;
        };
        Icon: {
            type: PropType<unknown>;
            default: unknown;
        };
        Tag: {
            type: PropType<unknown>;
            default: unknown;
        };
        DataContext: {
            type: PropType<unknown>;
            default: unknown;
        };
        Command: {
            type: PropType<unknown>;
            default: unknown;
        };
        CommandParameter: {
            type: PropType<unknown>;
            default: unknown;
        };
        IsEnabled: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        IsChecked: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        GroupName: {
            type: StringConstructor;
            default: string;
        };
        KeyboardAccelerators: {
            type: PropType<unknown[] | string>;
            default: undefined;
        };
        KeyboardAcceleratorTextOverride: {
            type: StringConstructor;
            default: string;
        };
        KeyboardAcceleratorPlacementMode: {
            type: StringConstructor;
            default: string;
        };
        PreventDismissOnPointer: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        Items: {
            type: PropType<VNode[] | string>;
            default: undefined;
        };
        Foreground: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        Background: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        BorderBrush: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        BorderThickness: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        Padding: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        CornerRadius: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        FontFamily: {
            type: StringConstructor;
            default: string;
        };
        FontSize: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        FontWeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        HorizontalContentAlignment: {
            type: StringConstructor;
            default: string;
        };
        VerticalContentAlignment: {
            type: StringConstructor;
            default: string;
        };
        Width: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        Height: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        MinWidth: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        MinHeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        MaxWidth: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        MaxHeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        Margin: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        HorizontalAlignment: {
            type: StringConstructor;
            default: string;
        };
        VerticalAlignment: {
            type: StringConstructor;
            default: string;
        };
        FlowDirection: {
            type: StringConstructor;
            default: string;
        };
        Visibility: {
            type: StringConstructor;
            default: string;
        };
        IsTabStop: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
    }>> & Readonly<{
        [x: `on${Capitalize<string>}`]: ((...args: any[]) => any) | undefined;
    }>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, string[], import("vue").PublicProps, {
        Width: string | number;
        Height: string | number;
        MinWidth: string | number;
        MaxWidth: string | number;
        MinHeight: string | number;
        MaxHeight: string | number;
        Margin: string | number;
        Padding: string | number;
        HorizontalAlignment: string;
        VerticalAlignment: string;
        Foreground: string | Record<string, any>;
        Command: unknown;
        KeyboardAccelerators: string | unknown[];
        IsEnabled: string | boolean;
        Background: string | Record<string, any>;
        BorderBrush: string | Record<string, any>;
        BorderThickness: string | number;
        CornerRadius: string | number;
        FontSize: string | number;
        HorizontalContentAlignment: string;
        VerticalContentAlignment: string;
        KeyboardAcceleratorPlacementMode: string;
        IsTabStop: string | boolean;
        FontFamily: string;
        FontWeight: string | number;
        IsChecked: string | boolean;
        Text: string | number;
        Visibility: string;
        DataContext: unknown;
        FlowDirection: string;
        Tag: unknown;
        CommandParameter: unknown;
        Icon: unknown;
        KeyboardAcceleratorTextOverride: string;
        Items: string | VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>[];
        GroupName: string;
        PreventDismissOnPointer: string | boolean;
    }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        Text: {
            type: (NumberConstructor | StringConstructor)[];
            default: undefined;
        };
        Icon: {
            type: PropType<unknown>;
            default: unknown;
        };
        Tag: {
            type: PropType<unknown>;
            default: unknown;
        };
        DataContext: {
            type: PropType<unknown>;
            default: unknown;
        };
        Command: {
            type: PropType<unknown>;
            default: unknown;
        };
        CommandParameter: {
            type: PropType<unknown>;
            default: unknown;
        };
        IsEnabled: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        IsChecked: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        GroupName: {
            type: StringConstructor;
            default: string;
        };
        KeyboardAccelerators: {
            type: PropType<unknown[] | string>;
            default: undefined;
        };
        KeyboardAcceleratorTextOverride: {
            type: StringConstructor;
            default: string;
        };
        KeyboardAcceleratorPlacementMode: {
            type: StringConstructor;
            default: string;
        };
        PreventDismissOnPointer: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        Items: {
            type: PropType<VNode[] | string>;
            default: undefined;
        };
        Foreground: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        Background: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        BorderBrush: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        BorderThickness: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        Padding: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        CornerRadius: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        FontFamily: {
            type: StringConstructor;
            default: string;
        };
        FontSize: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        FontWeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        HorizontalContentAlignment: {
            type: StringConstructor;
            default: string;
        };
        VerticalContentAlignment: {
            type: StringConstructor;
            default: string;
        };
        Width: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        Height: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        MinWidth: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        MinHeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        MaxWidth: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        MaxHeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        Margin: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        HorizontalAlignment: {
            type: StringConstructor;
            default: string;
        };
        VerticalAlignment: {
            type: StringConstructor;
            default: string;
        };
        FlowDirection: {
            type: StringConstructor;
            default: string;
        };
        Visibility: {
            type: StringConstructor;
            default: string;
        };
        IsTabStop: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
    }>> & Readonly<{
        [x: `on${Capitalize<string>}`]: ((...args: any[]) => any) | undefined;
    }>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>, {}, {}, {}, {
        Width: string | number;
        Height: string | number;
        MinWidth: string | number;
        MaxWidth: string | number;
        MinHeight: string | number;
        MaxHeight: string | number;
        Margin: string | number;
        Padding: string | number;
        HorizontalAlignment: string;
        VerticalAlignment: string;
        Foreground: string | Record<string, any>;
        Command: unknown;
        KeyboardAccelerators: string | unknown[];
        IsEnabled: string | boolean;
        Background: string | Record<string, any>;
        BorderBrush: string | Record<string, any>;
        BorderThickness: string | number;
        CornerRadius: string | number;
        FontSize: string | number;
        HorizontalContentAlignment: string;
        VerticalContentAlignment: string;
        KeyboardAcceleratorPlacementMode: string;
        IsTabStop: string | boolean;
        FontFamily: string;
        FontWeight: string | number;
        IsChecked: string | boolean;
        Text: string | number;
        Visibility: string;
        DataContext: unknown;
        FlowDirection: string;
        Tag: unknown;
        CommandParameter: unknown;
        Icon: unknown;
        KeyboardAcceleratorTextOverride: string;
        Items: string | VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>[];
        GroupName: string;
        PreventDismissOnPointer: string | boolean;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    Text: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Icon: {
        type: PropType<unknown>;
        default: unknown;
    };
    Tag: {
        type: PropType<unknown>;
        default: unknown;
    };
    DataContext: {
        type: PropType<unknown>;
        default: unknown;
    };
    Command: {
        type: PropType<unknown>;
        default: unknown;
    };
    CommandParameter: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsChecked: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    GroupName: {
        type: StringConstructor;
        default: string;
    };
    KeyboardAccelerators: {
        type: PropType<unknown[] | string>;
        default: undefined;
    };
    KeyboardAcceleratorTextOverride: {
        type: StringConstructor;
        default: string;
    };
    KeyboardAcceleratorPlacementMode: {
        type: StringConstructor;
        default: string;
    };
    PreventDismissOnPointer: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Items: {
        type: PropType<VNode[] | string>;
        default: undefined;
    };
    Foreground: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderBrush: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FontWeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
}>> & Readonly<{
    [x: `on${Capitalize<string>}`]: ((...args: any[]) => any) | undefined;
}>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, string[], string, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string | Record<string, any>;
    Command: unknown;
    KeyboardAccelerators: string | unknown[];
    IsEnabled: string | boolean;
    Background: string | Record<string, any>;
    BorderBrush: string | Record<string, any>;
    BorderThickness: string | number;
    CornerRadius: string | number;
    FontSize: string | number;
    HorizontalContentAlignment: string;
    VerticalContentAlignment: string;
    KeyboardAcceleratorPlacementMode: string;
    IsTabStop: string | boolean;
    FontFamily: string;
    FontWeight: string | number;
    IsChecked: string | boolean;
    Text: string | number;
    Visibility: string;
    DataContext: unknown;
    FlowDirection: string;
    Tag: unknown;
    CommandParameter: unknown;
    Icon: unknown;
    KeyboardAcceleratorTextOverride: string;
    Items: string | VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>[];
    GroupName: string;
    PreventDismissOnPointer: string | boolean;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & {
    Icon: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    KeyboardAccelerators: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    Items: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
};
export declare const MenuFlyoutSubItem: {
    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
        Text: {
            type: (NumberConstructor | StringConstructor)[];
            default: undefined;
        };
        Icon: {
            type: PropType<unknown>;
            default: unknown;
        };
        Tag: {
            type: PropType<unknown>;
            default: unknown;
        };
        DataContext: {
            type: PropType<unknown>;
            default: unknown;
        };
        Command: {
            type: PropType<unknown>;
            default: unknown;
        };
        CommandParameter: {
            type: PropType<unknown>;
            default: unknown;
        };
        IsEnabled: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        IsChecked: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        GroupName: {
            type: StringConstructor;
            default: string;
        };
        KeyboardAccelerators: {
            type: PropType<unknown[] | string>;
            default: undefined;
        };
        KeyboardAcceleratorTextOverride: {
            type: StringConstructor;
            default: string;
        };
        KeyboardAcceleratorPlacementMode: {
            type: StringConstructor;
            default: string;
        };
        PreventDismissOnPointer: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        Items: {
            type: PropType<VNode[] | string>;
            default: undefined;
        };
        Foreground: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        Background: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        BorderBrush: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        BorderThickness: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        Padding: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        CornerRadius: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        FontFamily: {
            type: StringConstructor;
            default: string;
        };
        FontSize: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        FontWeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        HorizontalContentAlignment: {
            type: StringConstructor;
            default: string;
        };
        VerticalContentAlignment: {
            type: StringConstructor;
            default: string;
        };
        Width: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        Height: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        MinWidth: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        MinHeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        MaxWidth: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        MaxHeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        Margin: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        HorizontalAlignment: {
            type: StringConstructor;
            default: string;
        };
        VerticalAlignment: {
            type: StringConstructor;
            default: string;
        };
        FlowDirection: {
            type: StringConstructor;
            default: string;
        };
        Visibility: {
            type: StringConstructor;
            default: string;
        };
        IsTabStop: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
    }>> & Readonly<{
        [x: `on${Capitalize<string>}`]: ((...args: any[]) => any) | undefined;
    }>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, string[], import("vue").PublicProps, {
        Width: string | number;
        Height: string | number;
        MinWidth: string | number;
        MaxWidth: string | number;
        MinHeight: string | number;
        MaxHeight: string | number;
        Margin: string | number;
        Padding: string | number;
        HorizontalAlignment: string;
        VerticalAlignment: string;
        Foreground: string | Record<string, any>;
        Command: unknown;
        KeyboardAccelerators: string | unknown[];
        IsEnabled: string | boolean;
        Background: string | Record<string, any>;
        BorderBrush: string | Record<string, any>;
        BorderThickness: string | number;
        CornerRadius: string | number;
        FontSize: string | number;
        HorizontalContentAlignment: string;
        VerticalContentAlignment: string;
        KeyboardAcceleratorPlacementMode: string;
        IsTabStop: string | boolean;
        FontFamily: string;
        FontWeight: string | number;
        IsChecked: string | boolean;
        Text: string | number;
        Visibility: string;
        DataContext: unknown;
        FlowDirection: string;
        Tag: unknown;
        CommandParameter: unknown;
        Icon: unknown;
        KeyboardAcceleratorTextOverride: string;
        Items: string | VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>[];
        GroupName: string;
        PreventDismissOnPointer: string | boolean;
    }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        Text: {
            type: (NumberConstructor | StringConstructor)[];
            default: undefined;
        };
        Icon: {
            type: PropType<unknown>;
            default: unknown;
        };
        Tag: {
            type: PropType<unknown>;
            default: unknown;
        };
        DataContext: {
            type: PropType<unknown>;
            default: unknown;
        };
        Command: {
            type: PropType<unknown>;
            default: unknown;
        };
        CommandParameter: {
            type: PropType<unknown>;
            default: unknown;
        };
        IsEnabled: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        IsChecked: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        GroupName: {
            type: StringConstructor;
            default: string;
        };
        KeyboardAccelerators: {
            type: PropType<unknown[] | string>;
            default: undefined;
        };
        KeyboardAcceleratorTextOverride: {
            type: StringConstructor;
            default: string;
        };
        KeyboardAcceleratorPlacementMode: {
            type: StringConstructor;
            default: string;
        };
        PreventDismissOnPointer: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        Items: {
            type: PropType<VNode[] | string>;
            default: undefined;
        };
        Foreground: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        Background: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        BorderBrush: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        BorderThickness: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        Padding: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        CornerRadius: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        FontFamily: {
            type: StringConstructor;
            default: string;
        };
        FontSize: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        FontWeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        HorizontalContentAlignment: {
            type: StringConstructor;
            default: string;
        };
        VerticalContentAlignment: {
            type: StringConstructor;
            default: string;
        };
        Width: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        Height: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        MinWidth: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        MinHeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        MaxWidth: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        MaxHeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        Margin: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        HorizontalAlignment: {
            type: StringConstructor;
            default: string;
        };
        VerticalAlignment: {
            type: StringConstructor;
            default: string;
        };
        FlowDirection: {
            type: StringConstructor;
            default: string;
        };
        Visibility: {
            type: StringConstructor;
            default: string;
        };
        IsTabStop: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
    }>> & Readonly<{
        [x: `on${Capitalize<string>}`]: ((...args: any[]) => any) | undefined;
    }>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>, {}, {}, {}, {
        Width: string | number;
        Height: string | number;
        MinWidth: string | number;
        MaxWidth: string | number;
        MinHeight: string | number;
        MaxHeight: string | number;
        Margin: string | number;
        Padding: string | number;
        HorizontalAlignment: string;
        VerticalAlignment: string;
        Foreground: string | Record<string, any>;
        Command: unknown;
        KeyboardAccelerators: string | unknown[];
        IsEnabled: string | boolean;
        Background: string | Record<string, any>;
        BorderBrush: string | Record<string, any>;
        BorderThickness: string | number;
        CornerRadius: string | number;
        FontSize: string | number;
        HorizontalContentAlignment: string;
        VerticalContentAlignment: string;
        KeyboardAcceleratorPlacementMode: string;
        IsTabStop: string | boolean;
        FontFamily: string;
        FontWeight: string | number;
        IsChecked: string | boolean;
        Text: string | number;
        Visibility: string;
        DataContext: unknown;
        FlowDirection: string;
        Tag: unknown;
        CommandParameter: unknown;
        Icon: unknown;
        KeyboardAcceleratorTextOverride: string;
        Items: string | VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>[];
        GroupName: string;
        PreventDismissOnPointer: string | boolean;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    Text: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Icon: {
        type: PropType<unknown>;
        default: unknown;
    };
    Tag: {
        type: PropType<unknown>;
        default: unknown;
    };
    DataContext: {
        type: PropType<unknown>;
        default: unknown;
    };
    Command: {
        type: PropType<unknown>;
        default: unknown;
    };
    CommandParameter: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsChecked: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    GroupName: {
        type: StringConstructor;
        default: string;
    };
    KeyboardAccelerators: {
        type: PropType<unknown[] | string>;
        default: undefined;
    };
    KeyboardAcceleratorTextOverride: {
        type: StringConstructor;
        default: string;
    };
    KeyboardAcceleratorPlacementMode: {
        type: StringConstructor;
        default: string;
    };
    PreventDismissOnPointer: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Items: {
        type: PropType<VNode[] | string>;
        default: undefined;
    };
    Foreground: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderBrush: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FontWeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
}>> & Readonly<{
    [x: `on${Capitalize<string>}`]: ((...args: any[]) => any) | undefined;
}>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, string[], string, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string | Record<string, any>;
    Command: unknown;
    KeyboardAccelerators: string | unknown[];
    IsEnabled: string | boolean;
    Background: string | Record<string, any>;
    BorderBrush: string | Record<string, any>;
    BorderThickness: string | number;
    CornerRadius: string | number;
    FontSize: string | number;
    HorizontalContentAlignment: string;
    VerticalContentAlignment: string;
    KeyboardAcceleratorPlacementMode: string;
    IsTabStop: string | boolean;
    FontFamily: string;
    FontWeight: string | number;
    IsChecked: string | boolean;
    Text: string | number;
    Visibility: string;
    DataContext: unknown;
    FlowDirection: string;
    Tag: unknown;
    CommandParameter: unknown;
    Icon: unknown;
    KeyboardAcceleratorTextOverride: string;
    Items: string | VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>[];
    GroupName: string;
    PreventDismissOnPointer: string | boolean;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & {
    Icon: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    KeyboardAccelerators: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    Items: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
};
export declare const SplitMenuFlyoutItem: {
    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
        Text: {
            type: (NumberConstructor | StringConstructor)[];
            default: undefined;
        };
        Icon: {
            type: PropType<unknown>;
            default: unknown;
        };
        Tag: {
            type: PropType<unknown>;
            default: unknown;
        };
        DataContext: {
            type: PropType<unknown>;
            default: unknown;
        };
        Command: {
            type: PropType<unknown>;
            default: unknown;
        };
        CommandParameter: {
            type: PropType<unknown>;
            default: unknown;
        };
        IsEnabled: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        IsChecked: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        GroupName: {
            type: StringConstructor;
            default: string;
        };
        KeyboardAccelerators: {
            type: PropType<unknown[] | string>;
            default: undefined;
        };
        KeyboardAcceleratorTextOverride: {
            type: StringConstructor;
            default: string;
        };
        KeyboardAcceleratorPlacementMode: {
            type: StringConstructor;
            default: string;
        };
        PreventDismissOnPointer: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        Items: {
            type: PropType<VNode[] | string>;
            default: undefined;
        };
        Foreground: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        Background: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        BorderBrush: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        BorderThickness: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        Padding: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        CornerRadius: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        FontFamily: {
            type: StringConstructor;
            default: string;
        };
        FontSize: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        FontWeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        HorizontalContentAlignment: {
            type: StringConstructor;
            default: string;
        };
        VerticalContentAlignment: {
            type: StringConstructor;
            default: string;
        };
        Width: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        Height: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        MinWidth: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        MinHeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        MaxWidth: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        MaxHeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        Margin: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        HorizontalAlignment: {
            type: StringConstructor;
            default: string;
        };
        VerticalAlignment: {
            type: StringConstructor;
            default: string;
        };
        FlowDirection: {
            type: StringConstructor;
            default: string;
        };
        Visibility: {
            type: StringConstructor;
            default: string;
        };
        IsTabStop: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
    }>> & Readonly<{
        [x: `on${Capitalize<string>}`]: ((...args: any[]) => any) | undefined;
    }>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, string[], import("vue").PublicProps, {
        Width: string | number;
        Height: string | number;
        MinWidth: string | number;
        MaxWidth: string | number;
        MinHeight: string | number;
        MaxHeight: string | number;
        Margin: string | number;
        Padding: string | number;
        HorizontalAlignment: string;
        VerticalAlignment: string;
        Foreground: string | Record<string, any>;
        Command: unknown;
        KeyboardAccelerators: string | unknown[];
        IsEnabled: string | boolean;
        Background: string | Record<string, any>;
        BorderBrush: string | Record<string, any>;
        BorderThickness: string | number;
        CornerRadius: string | number;
        FontSize: string | number;
        HorizontalContentAlignment: string;
        VerticalContentAlignment: string;
        KeyboardAcceleratorPlacementMode: string;
        IsTabStop: string | boolean;
        FontFamily: string;
        FontWeight: string | number;
        IsChecked: string | boolean;
        Text: string | number;
        Visibility: string;
        DataContext: unknown;
        FlowDirection: string;
        Tag: unknown;
        CommandParameter: unknown;
        Icon: unknown;
        KeyboardAcceleratorTextOverride: string;
        Items: string | VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>[];
        GroupName: string;
        PreventDismissOnPointer: string | boolean;
    }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        Text: {
            type: (NumberConstructor | StringConstructor)[];
            default: undefined;
        };
        Icon: {
            type: PropType<unknown>;
            default: unknown;
        };
        Tag: {
            type: PropType<unknown>;
            default: unknown;
        };
        DataContext: {
            type: PropType<unknown>;
            default: unknown;
        };
        Command: {
            type: PropType<unknown>;
            default: unknown;
        };
        CommandParameter: {
            type: PropType<unknown>;
            default: unknown;
        };
        IsEnabled: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        IsChecked: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        GroupName: {
            type: StringConstructor;
            default: string;
        };
        KeyboardAccelerators: {
            type: PropType<unknown[] | string>;
            default: undefined;
        };
        KeyboardAcceleratorTextOverride: {
            type: StringConstructor;
            default: string;
        };
        KeyboardAcceleratorPlacementMode: {
            type: StringConstructor;
            default: string;
        };
        PreventDismissOnPointer: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
        Items: {
            type: PropType<VNode[] | string>;
            default: undefined;
        };
        Foreground: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        Background: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        BorderBrush: {
            type: (StringConstructor | ObjectConstructor)[];
            default: string;
        };
        BorderThickness: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        Padding: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        CornerRadius: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        FontFamily: {
            type: StringConstructor;
            default: string;
        };
        FontSize: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        FontWeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        HorizontalContentAlignment: {
            type: StringConstructor;
            default: string;
        };
        VerticalContentAlignment: {
            type: StringConstructor;
            default: string;
        };
        Width: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        Height: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        MinWidth: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        MinHeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: number;
        };
        MaxWidth: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        MaxHeight: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        Margin: {
            type: (NumberConstructor | StringConstructor)[];
            default: string;
        };
        HorizontalAlignment: {
            type: StringConstructor;
            default: string;
        };
        VerticalAlignment: {
            type: StringConstructor;
            default: string;
        };
        FlowDirection: {
            type: StringConstructor;
            default: string;
        };
        Visibility: {
            type: StringConstructor;
            default: string;
        };
        IsTabStop: {
            type: (StringConstructor | BooleanConstructor)[];
            default: boolean;
        };
    }>> & Readonly<{
        [x: `on${Capitalize<string>}`]: ((...args: any[]) => any) | undefined;
    }>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>, {}, {}, {}, {
        Width: string | number;
        Height: string | number;
        MinWidth: string | number;
        MaxWidth: string | number;
        MinHeight: string | number;
        MaxHeight: string | number;
        Margin: string | number;
        Padding: string | number;
        HorizontalAlignment: string;
        VerticalAlignment: string;
        Foreground: string | Record<string, any>;
        Command: unknown;
        KeyboardAccelerators: string | unknown[];
        IsEnabled: string | boolean;
        Background: string | Record<string, any>;
        BorderBrush: string | Record<string, any>;
        BorderThickness: string | number;
        CornerRadius: string | number;
        FontSize: string | number;
        HorizontalContentAlignment: string;
        VerticalContentAlignment: string;
        KeyboardAcceleratorPlacementMode: string;
        IsTabStop: string | boolean;
        FontFamily: string;
        FontWeight: string | number;
        IsChecked: string | boolean;
        Text: string | number;
        Visibility: string;
        DataContext: unknown;
        FlowDirection: string;
        Tag: unknown;
        CommandParameter: unknown;
        Icon: unknown;
        KeyboardAcceleratorTextOverride: string;
        Items: string | VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>[];
        GroupName: string;
        PreventDismissOnPointer: string | boolean;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    Text: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Icon: {
        type: PropType<unknown>;
        default: unknown;
    };
    Tag: {
        type: PropType<unknown>;
        default: unknown;
    };
    DataContext: {
        type: PropType<unknown>;
        default: unknown;
    };
    Command: {
        type: PropType<unknown>;
        default: unknown;
    };
    CommandParameter: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsChecked: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    GroupName: {
        type: StringConstructor;
        default: string;
    };
    KeyboardAccelerators: {
        type: PropType<unknown[] | string>;
        default: undefined;
    };
    KeyboardAcceleratorTextOverride: {
        type: StringConstructor;
        default: string;
    };
    KeyboardAcceleratorPlacementMode: {
        type: StringConstructor;
        default: string;
    };
    PreventDismissOnPointer: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Items: {
        type: PropType<VNode[] | string>;
        default: undefined;
    };
    Foreground: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderBrush: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FontWeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
}>> & Readonly<{
    [x: `on${Capitalize<string>}`]: ((...args: any[]) => any) | undefined;
}>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, string[], string, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string | Record<string, any>;
    Command: unknown;
    KeyboardAccelerators: string | unknown[];
    IsEnabled: string | boolean;
    Background: string | Record<string, any>;
    BorderBrush: string | Record<string, any>;
    BorderThickness: string | number;
    CornerRadius: string | number;
    FontSize: string | number;
    HorizontalContentAlignment: string;
    VerticalContentAlignment: string;
    KeyboardAcceleratorPlacementMode: string;
    IsTabStop: string | boolean;
    FontFamily: string;
    FontWeight: string | number;
    IsChecked: string | boolean;
    Text: string | number;
    Visibility: string;
    DataContext: unknown;
    FlowDirection: string;
    Tag: unknown;
    CommandParameter: unknown;
    Icon: unknown;
    KeyboardAcceleratorTextOverride: string;
    Items: string | VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>[];
    GroupName: string;
    PreventDismissOnPointer: string | boolean;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & {
    Icon: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    KeyboardAccelerators: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    Items: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
};
export declare const MenuFlyoutSeparator: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Background: {
        type: StringConstructor;
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
}>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Background: {
        type: StringConstructor;
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{}>, {
    Margin: string | number;
    Padding: string | number;
    Background: string;
    Visibility: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
