declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    IsCompact: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    DynamicOverflowOrder: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Foreground: {
        default: undefined;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
}>, {
    Name: import("vue").ComputedRef<string>;
    IsInOverflow: import("vue").ComputedRef<boolean>;
    $el: import("vue").Ref<HTMLElement | null, HTMLElement | null>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:Foreground": (...args: any[]) => void;
    "update:IsCompact": (...args: any[]) => void;
    "update:DynamicOverflowOrder": (...args: any[]) => void;
    "update:IsEnabled": (...args: any[]) => void;
    "update:IsTabStop": (...args: any[]) => void;
    "update:Visibility": (...args: any[]) => void;
    "update:Padding": (...args: any[]) => void;
    "update:Margin": (...args: any[]) => void;
    "update:Width": (...args: any[]) => void;
    "update:Height": (...args: any[]) => void;
    "update:MinWidth": (...args: any[]) => void;
    "update:MinHeight": (...args: any[]) => void;
    "update:MaxWidth": (...args: any[]) => void;
    "update:MaxHeight": (...args: any[]) => void;
    "update:HorizontalAlignment": (...args: any[]) => void;
    "update:VerticalAlignment": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    IsCompact: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    DynamicOverflowOrder: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Foreground: {
        default: undefined;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    "onUpdate:Foreground"?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsCompact"?: ((...args: any[]) => any) | undefined;
    "onUpdate:DynamicOverflowOrder"?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsTabStop"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Visibility"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Padding"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:MinWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:MinHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:MaxWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:MaxHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:HorizontalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:VerticalAlignment"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: undefined;
    IsEnabled: string | boolean;
    IsTabStop: string | boolean;
    Visibility: string;
    IsCompact: string | boolean;
    DynamicOverflowOrder: string | number;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
