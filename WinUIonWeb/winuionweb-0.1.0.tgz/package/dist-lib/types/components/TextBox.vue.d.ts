export declare const TextBoxHeader: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const TextBoxHeaderTemplate: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const TextBoxDescription: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const TextBoxContextFlyout: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const TextBoxSelectionFlyout: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<{
    Text?: string;
    PlaceholderText?: string;
    Header?: unknown;
    HeaderTemplate?: unknown;
    ContextFlyout?: unknown;
    SelectionFlyout?: unknown;
    Description?: string;
    AcceptsReturn?: boolean | string;
    IsReadOnly?: boolean | string;
    IsEnabled?: boolean | string;
    MaxLength?: number | string;
    TextWrapping?: ("WrapWholeWords" | "NoWrap" | "Wrap") | `{${string}}`;
    TextAlignment?: ("Left" | "Center" | "Right" | "Justify") | `{${string}}`;
    IsSpellCheckEnabled?: boolean | string;
    IsTextPredictionEnabled?: boolean | string;
    InputScope?: string;
    CharacterCasing?: ("Normal" | "Lower" | "Upper") | `{${string}}`;
    SelectionHighlightColor?: string;
    DesiredCandidateWindowAlignment?: ("Default" | "BottomEdge") | `{${string}}`;
    IsColorFontEnabled?: boolean | string;
    PreventKeyboardDisplayOnProgrammaticFocus?: boolean | string;
    FontFamily?: string;
    FontSize?: number | string;
    FontStyle?: string;
    FontWeight?: number | string;
    Foreground?: string;
    Background?: string;
    BorderBrush?: string;
    BorderThickness?: number | string;
    Padding?: number | string;
    CornerRadius?: number | string;
    PlaceholderForeground?: string;
    CharacterSpacing?: number | string;
    Width?: number | string;
    Height?: number | string;
    Margin?: number | string;
    HorizontalAlignment?: string;
    VerticalAlignment?: string;
    MinWidth?: number | string;
    MaxWidth?: number | string;
    MinHeight?: number | string;
    MaxHeight?: number | string;
}, {
    readonly Element: HTMLInputElement | HTMLTextAreaElement | null;
    IsEnabled: boolean;
    IsReadOnly: boolean;
    AcceptsReturn: boolean;
    TextWrapping: "WrapWholeWords" | "NoWrap" | "Wrap";
    Text: string;
    Focus: (options?: FocusOptions) => void;
    ContextFlyout: unknown;
    SelectionFlyout: unknown;
    SelectAll: () => void;
    Select: (start: number, length: number) => void;
    GetRectFromCharacterIndex: (index: number, trailingEdge?: boolean) => {
        x: number;
        y: number;
        width: number;
        height: number;
    };
    Undo: () => void;
    Redo: () => void;
    CopySelectionToClipboard: () => void;
    CutSelectionToClipboard: () => void;
    PasteFromClipboard: () => Promise<void>;
    readonly CanUndo: boolean;
    readonly CanRedo: boolean;
    SelectedText: string;
    SelectionStart: number;
    SelectionLength: number;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Paste: (args: {
        Handled: boolean;
    }) => any;
    TextCompositionStarted: () => any;
    TextCompositionChanged: () => any;
    TextCompositionEnded: () => any;
    BeforeTextChanging: (args: {
        NewText: string;
        Cancel: boolean;
    }) => any;
    TextChanging: (args: {
        IsContentChanging: boolean;
    }) => any;
    SelectionChanging: (args: {
        SelectionStart: number;
        SelectionLength: number;
        Cancel: boolean;
    }) => any;
    CopyingToClipboard: (args: {
        Handled: boolean;
    }) => any;
    CuttingToClipboard: (args: {
        Handled: boolean;
    }) => any;
    ContextMenuOpening: (args: {
        Handled: boolean;
        CursorLeft: number;
        CursorTop: number;
    }) => any;
    CandidateWindowBoundsChanged: (args: {
        Bounds: DOMRectReadOnly;
    }) => any;
    SelectionChanged: () => any;
    TextChanged: () => any;
    KeyDown: (args: {
        Key: string;
        OriginalSource: HTMLElement | null;
        Handled: boolean;
    }) => any;
    GotFocus: () => any;
    LostFocus: () => any;
    "update:Text": (value: string) => any;
}, string, import("vue").PublicProps, Readonly<{
    Text?: string;
    PlaceholderText?: string;
    Header?: unknown;
    HeaderTemplate?: unknown;
    ContextFlyout?: unknown;
    SelectionFlyout?: unknown;
    Description?: string;
    AcceptsReturn?: boolean | string;
    IsReadOnly?: boolean | string;
    IsEnabled?: boolean | string;
    MaxLength?: number | string;
    TextWrapping?: ("WrapWholeWords" | "NoWrap" | "Wrap") | `{${string}}`;
    TextAlignment?: ("Left" | "Center" | "Right" | "Justify") | `{${string}}`;
    IsSpellCheckEnabled?: boolean | string;
    IsTextPredictionEnabled?: boolean | string;
    InputScope?: string;
    CharacterCasing?: ("Normal" | "Lower" | "Upper") | `{${string}}`;
    SelectionHighlightColor?: string;
    DesiredCandidateWindowAlignment?: ("Default" | "BottomEdge") | `{${string}}`;
    IsColorFontEnabled?: boolean | string;
    PreventKeyboardDisplayOnProgrammaticFocus?: boolean | string;
    FontFamily?: string;
    FontSize?: number | string;
    FontStyle?: string;
    FontWeight?: number | string;
    Foreground?: string;
    Background?: string;
    BorderBrush?: string;
    BorderThickness?: number | string;
    Padding?: number | string;
    CornerRadius?: number | string;
    PlaceholderForeground?: string;
    CharacterSpacing?: number | string;
    Width?: number | string;
    Height?: number | string;
    Margin?: number | string;
    HorizontalAlignment?: string;
    VerticalAlignment?: string;
    MinWidth?: number | string;
    MaxWidth?: number | string;
    MinHeight?: number | string;
    MaxHeight?: number | string;
}> & Readonly<{
    onPaste?: ((args: {
        Handled: boolean;
    }) => any) | undefined;
    onTextCompositionStarted?: (() => any) | undefined;
    onTextCompositionChanged?: (() => any) | undefined;
    onTextCompositionEnded?: (() => any) | undefined;
    onBeforeTextChanging?: ((args: {
        NewText: string;
        Cancel: boolean;
    }) => any) | undefined;
    onTextChanging?: ((args: {
        IsContentChanging: boolean;
    }) => any) | undefined;
    onSelectionChanging?: ((args: {
        SelectionStart: number;
        SelectionLength: number;
        Cancel: boolean;
    }) => any) | undefined;
    onCopyingToClipboard?: ((args: {
        Handled: boolean;
    }) => any) | undefined;
    onCuttingToClipboard?: ((args: {
        Handled: boolean;
    }) => any) | undefined;
    onContextMenuOpening?: ((args: {
        Handled: boolean;
        CursorLeft: number;
        CursorTop: number;
    }) => any) | undefined;
    onCandidateWindowBoundsChanged?: ((args: {
        Bounds: DOMRectReadOnly;
    }) => any) | undefined;
    onSelectionChanged?: (() => any) | undefined;
    onTextChanged?: (() => any) | undefined;
    onKeyDown?: ((args: {
        Key: string;
        OriginalSource: HTMLElement | null;
        Handled: boolean;
    }) => any) | undefined;
    onGotFocus?: (() => any) | undefined;
    onLostFocus?: (() => any) | undefined;
    "onUpdate:Text"?: ((value: string) => any) | undefined;
}>, {
    Width: number | string;
    Height: number | string;
    MinWidth: number | string;
    MaxWidth: number | string;
    MinHeight: number | string;
    MaxHeight: number | string;
    Margin: number | string;
    Padding: number | string;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string;
    Description: string;
    IsEnabled: boolean | string;
    Header: string;
    Background: string;
    BorderBrush: string;
    BorderThickness: number | string;
    CornerRadius: number | string;
    FontSize: number | string;
    FontFamily: string;
    FontWeight: number | string;
    CharacterSpacing: number | string;
    FontStyle: string;
    TextAlignment: ("Left" | "Center" | "Right" | "Justify") | `{${string}}`;
    TextWrapping: ("WrapWholeWords" | "NoWrap" | "Wrap") | `{${string}}`;
    PlaceholderText: string;
    AcceptsReturn: boolean | string;
    IsReadOnly: boolean | string;
    MaxLength: number | string;
    IsSpellCheckEnabled: boolean | string;
    IsTextPredictionEnabled: boolean | string;
    InputScope: string;
    CharacterCasing: ("Normal" | "Lower" | "Upper") | `{${string}}`;
    SelectionHighlightColor: string;
    DesiredCandidateWindowAlignment: ("Default" | "BottomEdge") | `{${string}}`;
    IsColorFontEnabled: boolean | string;
    PreventKeyboardDisplayOnProgrammaticFocus: boolean | string;
    PlaceholderForeground: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
