import { type PropType } from 'vue';
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Header: {
        type: PropType<unknown>;
        default: unknown;
    };
    HeaderTemplate: {
        type: PropType<unknown>;
        default: unknown;
    };
    IconSource: {
        type: PropType<unknown>;
        default: unknown;
    };
    Content: {
        type: PropType<unknown>;
        default: unknown;
    };
    ContentTemplate: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsClosable: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsEnabled: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsSelected: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsTabStop: {
        type: PropType<unknown>;
        default: unknown;
    };
    Visibility: {
        type: PropType<unknown>;
        default: unknown;
    };
    Background: {
        type: PropType<unknown>;
        default: unknown;
    };
    Foreground: {
        type: PropType<unknown>;
        default: unknown;
    };
    BorderBrush: {
        type: PropType<unknown>;
        default: unknown;
    };
    BorderThickness: {
        type: PropType<unknown>;
        default: unknown;
    };
    CornerRadius: {
        type: PropType<unknown>;
        default: unknown;
    };
    Width: {
        type: PropType<unknown>;
        default: unknown;
    };
    Height: {
        type: PropType<unknown>;
        default: unknown;
    };
    MinWidth: {
        type: PropType<unknown>;
        default: unknown;
    };
    MaxWidth: {
        type: PropType<unknown>;
        default: unknown;
    };
    MinHeight: {
        type: PropType<unknown>;
        default: unknown;
    };
    MaxHeight: {
        type: PropType<unknown>;
        default: unknown;
    };
    Margin: {
        type: PropType<unknown>;
        default: unknown;
    };
    Padding: {
        type: PropType<unknown>;
        default: unknown;
    };
    HorizontalAlignment: {
        type: PropType<unknown>;
        default: unknown;
    };
    VerticalAlignment: {
        type: PropType<unknown>;
        default: unknown;
    };
    HorizontalContentAlignment: {
        type: PropType<unknown>;
        default: unknown;
    };
    VerticalContentAlignment: {
        type: PropType<unknown>;
        default: unknown;
    };
    FontSize: {
        type: PropType<unknown>;
        default: unknown;
    };
    FontWeight: {
        type: PropType<unknown>;
        default: unknown;
    };
    Opacity: {
        type: PropType<unknown>;
        default: unknown;
    };
    ContextFlyout: {
        type: PropType<unknown>;
        default: unknown;
    };
    AccessKey: {
        type: PropType<unknown>;
        default: unknown;
    };
    DataContext: {
        type: PropType<unknown>;
        default: unknown;
    };
}>, Record<string | symbol, any>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    CloseRequested: (...args: any[]) => void;
    "update:IsSelected": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Header: {
        type: PropType<unknown>;
        default: unknown;
    };
    HeaderTemplate: {
        type: PropType<unknown>;
        default: unknown;
    };
    IconSource: {
        type: PropType<unknown>;
        default: unknown;
    };
    Content: {
        type: PropType<unknown>;
        default: unknown;
    };
    ContentTemplate: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsClosable: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsEnabled: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsSelected: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsTabStop: {
        type: PropType<unknown>;
        default: unknown;
    };
    Visibility: {
        type: PropType<unknown>;
        default: unknown;
    };
    Background: {
        type: PropType<unknown>;
        default: unknown;
    };
    Foreground: {
        type: PropType<unknown>;
        default: unknown;
    };
    BorderBrush: {
        type: PropType<unknown>;
        default: unknown;
    };
    BorderThickness: {
        type: PropType<unknown>;
        default: unknown;
    };
    CornerRadius: {
        type: PropType<unknown>;
        default: unknown;
    };
    Width: {
        type: PropType<unknown>;
        default: unknown;
    };
    Height: {
        type: PropType<unknown>;
        default: unknown;
    };
    MinWidth: {
        type: PropType<unknown>;
        default: unknown;
    };
    MaxWidth: {
        type: PropType<unknown>;
        default: unknown;
    };
    MinHeight: {
        type: PropType<unknown>;
        default: unknown;
    };
    MaxHeight: {
        type: PropType<unknown>;
        default: unknown;
    };
    Margin: {
        type: PropType<unknown>;
        default: unknown;
    };
    Padding: {
        type: PropType<unknown>;
        default: unknown;
    };
    HorizontalAlignment: {
        type: PropType<unknown>;
        default: unknown;
    };
    VerticalAlignment: {
        type: PropType<unknown>;
        default: unknown;
    };
    HorizontalContentAlignment: {
        type: PropType<unknown>;
        default: unknown;
    };
    VerticalContentAlignment: {
        type: PropType<unknown>;
        default: unknown;
    };
    FontSize: {
        type: PropType<unknown>;
        default: unknown;
    };
    FontWeight: {
        type: PropType<unknown>;
        default: unknown;
    };
    Opacity: {
        type: PropType<unknown>;
        default: unknown;
    };
    ContextFlyout: {
        type: PropType<unknown>;
        default: unknown;
    };
    AccessKey: {
        type: PropType<unknown>;
        default: unknown;
    };
    DataContext: {
        type: PropType<unknown>;
        default: unknown;
    };
}>> & Readonly<{
    onCloseRequested?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsSelected"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: unknown;
    Height: unknown;
    MinWidth: unknown;
    MaxWidth: unknown;
    MinHeight: unknown;
    MaxHeight: unknown;
    Margin: unknown;
    Padding: unknown;
    HorizontalAlignment: unknown;
    VerticalAlignment: unknown;
    Foreground: unknown;
    Opacity: unknown;
    AccessKey: unknown;
    IconSource: unknown;
    IsEnabled: unknown;
    Header: unknown;
    Background: unknown;
    BorderBrush: unknown;
    BorderThickness: unknown;
    CornerRadius: unknown;
    FontSize: unknown;
    HorizontalContentAlignment: unknown;
    VerticalContentAlignment: unknown;
    IsTabStop: unknown;
    FontWeight: unknown;
    ContentTemplate: unknown;
    HeaderTemplate: unknown;
    ContextFlyout: unknown;
    Visibility: unknown;
    Content: unknown;
    IsClosable: unknown;
    IsSelected: unknown;
    DataContext: unknown;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
