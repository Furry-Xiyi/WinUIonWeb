export declare const titleBarHostAdapterKey: unique symbol;
/** Viewport-relative CSS pixels; the native adapter performs DPI conversion. */
export interface TitleBarRegion {
    X: number;
    Y: number;
    Width: number;
    Height: number;
}
/** Physical viewport edges in CSS pixels, independent of XAML FlowDirection. */
export interface TitleBarInsets {
    LeftInset: number;
    RightInset: number;
    /** The browser overlay's actual vertical band, when available. */
    TitleBarArea?: TitleBarRegion;
}
export type TitleBarHeightOption = 'Standard' | 'Tall' | 'Collapsed';
export interface TitleBarWindowConfiguration {
    ExtendsContentIntoTitleBar?: boolean;
    PreferredHeightOption?: TitleBarHeightOption;
}
export interface NativeTitleBarMetrics {
    /** Includes the actual WebView zoom as well as the native monitor DPI. */
    PhysicalPixelsPerCssPixel: number;
    LeftInset: number;
    RightInset: number;
    TitleBarArea?: TitleBarRegion;
}
export interface TitleBarDragRegions {
    Caption: TitleBarRegion;
    Passthrough: readonly TitleBarRegion[];
    Icon: TitleBarRegion | null;
    /** Actual Web-drawn button bounds; a Windows host may hit-test maximize for Snap Layouts. */
    CaptionButtons?: Partial<Record<TitleBarCaptionButton, TitleBarRegion>>;
}
export type TitleBarCaptionButton = 'minimize' | 'maximize' | 'close';
/**
 * A native host may keep the maximize hit-test alive so Windows 11 can show
 * Snap Layouts.  The host must route any native click through
 * SubscribeCaptionButtonAction; it must not draw the caption button.
 */
export type TitleBarCaptionHitTestMode = 'Web' | 'NativeSnap';
export interface TitleBarCaptionButtonState {
    Button: TitleBarCaptionButton | null;
    State: 'normal' | 'pointerOver' | 'pressed';
}
/** A host supplies real window actions; the control owns only the visuals. */
export interface TitleBarWindowControls {
    Minimize(): void | Promise<void>;
    ToggleMaximize(): void | Promise<void>;
    Close(): void | Promise<void>;
    IsMaximized(): boolean | Promise<boolean>;
    SubscribeStateChanged?(listener: () => void): (() => void) | Promise<() => void>;
    /** Route a native click only when it was not also delivered to the Web control. */
    SubscribeCaptionButtonAction?(listener: (button: TitleBarCaptionButton) => void): (() => void) | Promise<() => void>;
    /** Select Web hit testing or native Snap Layout hit testing for the buttons. */
    SetCaptionButtonHitTestMode?(mode: TitleBarCaptionHitTestMode): void | Promise<void>;
    UsesNativeCaptionHitTest?: boolean;
    SubscribeCaptionButtonState?(listener: (state: TitleBarCaptionButtonState) => void): (() => void) | Promise<() => void>;
    GetTitleBarInsets?(): TitleBarInsets | null;
    SubscribeTitleBarInsets?(listener: () => void): (() => void) | Promise<() => void>;
}
export interface TitleBarWindowHost {
    GetTitle(): string;
    SetTitle(title: string): void;
    IsInputActive?(): boolean;
    SubscribeActivation?(listener: (active: boolean) => void): () => void;
    /** Native AppWindow insets must be converted to this document's CSS pixels. */
    GetTitleBarInsets?(): TitleBarInsets | null;
    SubscribeTitleBarInsets?(listener: () => void): () => void;
    SetExtendsContentIntoTitleBar?(value: boolean): void | Promise<void>;
    SetPreferredHeightOption?(value: TitleBarHeightOption): void | Promise<void>;
    /** Optional ownership guard for hosts that contain nested demonstration bars. */
    IsTitleBarOwner?(element: HTMLElement): boolean;
    /** Actual non-client regions only. Ordinary browser windows have no implementation. */
    SetDragRegions?(regions: TitleBarDragRegions): void;
    ClearDragRegions?(): void;
    Minimize?(): void | Promise<void>;
    ToggleMaximize?(): void | Promise<void>;
    Close?(): void | Promise<void>;
    IsMaximized?(): boolean | Promise<boolean>;
    SubscribeStateChanged?(listener: () => void): (() => void) | Promise<() => void>;
    SubscribeCaptionButtonAction?(listener: (button: TitleBarCaptionButton) => void): (() => void) | Promise<() => void>;
    SetCaptionButtonHitTestMode?(mode: TitleBarCaptionHitTestMode): void | Promise<void>;
    UsesNativeCaptionHitTest?: boolean;
    SubscribeCaptionButtonState?(listener: (state: TitleBarCaptionButtonState) => void): (() => void) | Promise<() => void>;
}
export interface TitleBarHostAdapter {
    /** Return a host only for the TitleBar that owns the actual application window. */
    Connect(element: HTMLElement): TitleBarWindowHost | null;
}
export declare function setTitleBarHostAdapter(adapter: TitleBarHostAdapter | undefined): () => void;
/** Framework-neutral: register a native/window content host before mounting its TitleBar. */
export declare function registerTitleBarWindowHost(content: HTMLElement, host: TitleBarWindowHost): () => void;
/** AppWindow reports physical pixels; XAML and browser layout use logical pixels. */
export declare function nativeTitleBarMetricsToCssPixels(metrics: NativeTitleBarMetrics): TitleBarInsets | null;
/** Apply actual window policy before mounting the custom XAML TitleBar. */
export declare function configureTitleBarWindowHost(host: TitleBarWindowHost | null | undefined, configuration: TitleBarWindowConfiguration, signal?: AbortSignal): Promise<void>;
/** Convert physical window occlusion to the control's own arrange rectangle. */
export declare function getTitleBarHostPadding(bounds: TitleBarRegion, viewportWidth: number, insets: TitleBarInsets | null): TitleBarInsets | null;
export declare function createBrowserTitleBarWindowHost(owner: Window): TitleBarWindowHost;
export declare function connectTitleBarWindowHost(element: HTMLElement, adapter?: TitleBarHostAdapter | null): TitleBarWindowHost | null;
