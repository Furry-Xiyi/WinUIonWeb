import { type Directive, type StyleValue } from 'vue';
export declare const vAcrylicBrush: Directive<HTMLElement, StyleValue>;
export declare const vAcrylicBackdrop: Directive<HTMLElement, StyleValue>;
