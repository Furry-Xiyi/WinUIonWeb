import { type ComponentInternalInstance, type CSSProperties } from 'vue';
import { type AcrylicBrushValue } from './brushCore';
type ResourceContext = {
    Dispose: (callback: () => void) => void;
};
export declare const createAcrylicResource: (read: (name: string) => unknown, context?: ResourceContext) => AcrylicBrushValue;
export declare const AcrylicBrush: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    TintColor: {
        type: StringConstructor;
        default: string;
    };
    TintOpacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    TintLuminosityOpacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: null;
    };
    TintTransitionDuration: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    AlwaysUseFallback: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FallbackColor: {
        type: StringConstructor;
        default: string;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
}>, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    TintColor: {
        type: StringConstructor;
        default: string;
    };
    TintOpacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    TintLuminosityOpacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: null;
    };
    TintTransitionDuration: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    AlwaysUseFallback: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FallbackColor: {
        type: StringConstructor;
        default: string;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
}>> & Readonly<{}>, {
    TintColor: string;
    TintOpacity: string | number;
    TintLuminosityOpacity: string | number;
    TintTransitionDuration: string | number;
    AlwaysUseFallback: string | boolean;
    FallbackColor: string;
    Opacity: string | number;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export default AcrylicBrush;
export declare const resolveAcrylicResource: (name: string, instance: ComponentInternalInstance | null) => unknown;
export declare const resolveBrushStyle: (input: unknown, instance?: ComponentInternalInstance | null) => CSSProperties;
export declare const useAcrylicBrushStyle: (value: unknown | (() => unknown), instance?: ComponentInternalInstance | null) => import("vue").ComputedRef<CSSProperties>;
