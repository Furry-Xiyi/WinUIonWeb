import { n as e, t } from "./systemAccentColor-Cxi1uHgW.js";
export { t as connectSystemAccentColorHost, e as createBrowserSystemAccentColorHostAdapter };
