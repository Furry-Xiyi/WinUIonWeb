import { type NavigationStoryboardPair } from './shared';
/** SlideNavigationTransitionInfo::CreateStoryboards, ThemeTransitions.cpp:1515. */
export declare const createSlideStoryboards: (backward: boolean, info: Record<string, unknown>) => NavigationStoryboardPair;
