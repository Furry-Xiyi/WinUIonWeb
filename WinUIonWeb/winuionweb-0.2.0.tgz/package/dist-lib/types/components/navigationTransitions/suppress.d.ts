/** SuppressNavigationTransitionInfo::CreateStoryboards, ThemeTransitions.cpp:3075. */
export declare const createSuppressStoryboards: () => null;
