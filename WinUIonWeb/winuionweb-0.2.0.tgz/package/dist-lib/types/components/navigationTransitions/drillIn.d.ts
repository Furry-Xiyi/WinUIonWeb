import { type NavigationStoryboardPair } from './shared';
/** DrillInNavigationTransitionInfo::CreateStoryboards, ThemeTransitions.cpp:2830. */
export declare const createDrillInStoryboards: (backward: boolean) => NavigationStoryboardPair;
