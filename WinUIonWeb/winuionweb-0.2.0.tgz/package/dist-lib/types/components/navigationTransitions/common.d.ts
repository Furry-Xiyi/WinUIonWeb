import { type NavigationStoryboardPair, type NavigationStoryboardTarget, type NavigationTransitionStoryboard } from './shared';
/** CommonNavigationTransitionInfo::CreateStoryboards, ThemeTransitions.cpp:557. */
export declare const createCommonStoryboards: (backward: boolean) => NavigationStoryboardPair;
export declare const resolveCommonStoryboards: (storyboard: NavigationTransitionStoryboard, root: HTMLElement, incoming: boolean) => NavigationStoryboardTarget[];
