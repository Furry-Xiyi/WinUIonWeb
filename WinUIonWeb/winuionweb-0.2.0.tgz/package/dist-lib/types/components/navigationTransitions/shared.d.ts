export type NavigationAnimationTrack = {
    Keyframes: Keyframe[];
    Duration: number;
    Delay?: number;
    Easing?: string;
    Fill?: FillMode;
};
export type NavigationPageStoryboard = {
    Tracks: NavigationAnimationTrack[];
    InitialStyle: Record<string, string | number>;
    TransformOrigin?: string;
};
export type NavigationTransitionStoryboard = {
    Type: string;
    Entrance: NavigationPageStoryboard;
    Exit: NavigationPageStoryboard;
    Info: Record<string, unknown>;
    IsBack: boolean;
    DisableHitTesting: boolean;
};
export type NavigationStoryboardPair = {
    Entrance: NavigationPageStoryboard;
    Exit: NavigationPageStoryboard;
};
export type NavigationStoryboardTarget = {
    Element: HTMLElement;
    Storyboard: NavigationPageStoryboard;
};
export declare const entranceSpline = "cubic-bezier(0.1, 0.9, 0.2, 1)";
export declare const exitSpline = "cubic-bezier(0.7, 0, 1, 0.5)";
export declare const opacitySpline = "cubic-bezier(0.17, 0.17, 0, 1)";
export declare const exponentialIn: (exponent: number) => (progress: number) => number;
export declare const exponentialOut: (exponent: number) => (progress: number) => number;
export declare const exponentialInOut: (progress: number) => number;
export declare const circleOut: (progress: number) => number;
export declare const quadraticOut: (progress: number) => number;
export declare const tween: (property: string, from: string | number, to: string | number, duration: number, easing?: string, delay?: number) => NavigationAnimationTrack;
export declare const sampled: (property: string, from: number, to: number, duration: number, curve: (progress: number) => number, format?: (value: number) => string | number, delay?: number, intervals?: number) => NavigationAnimationTrack;
export declare const discreteOpacity: (from: number, to: number, time: number) => NavigationAnimationTrack;
export declare const page: (tracks: NavigationAnimationTrack[], initialStyle: Record<string, string | number>, origin?: string) => NavigationPageStoryboard;
export declare const scale: (value: number) => string;
export declare const translateY: (value: number) => string;
export declare const planeProjection = "matrix3d(1.001001001001001, 0, 0, 0, 0, 1.001001001001001, 0, 0, 0, 0, 1, -0.001001001001001001, 0, 0, 0, 1)";
export declare const attachedElements: (root: HTMLElement, property: string) => HTMLElement[];
export declare const transitionElement: (value: unknown, root: HTMLElement) => HTMLElement | null;
