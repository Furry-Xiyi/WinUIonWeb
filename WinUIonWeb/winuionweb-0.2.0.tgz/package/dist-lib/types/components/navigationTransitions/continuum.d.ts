import { type NavigationStoryboardPair, type NavigationStoryboardTarget, type NavigationTransitionStoryboard } from './shared';
/** ContinuumNavigationTransitionInfo::CreateStoryboards, ThemeTransitions.cpp:1826. */
export declare const createContinuumStoryboards: (backward: boolean) => NavigationStoryboardPair;
export declare const resolveContinuumStoryboards: (storyboard: NavigationTransitionStoryboard, root: HTMLElement, incoming: boolean) => NavigationStoryboardTarget[];
