import type { InjectionKey, Ref } from 'vue';
export type ToolTipInputMode = 'keyboard' | 'mouse' | 'touch' | 'none';
export type ToolTipPoint = {
    x: number;
    y: number;
};
export type ToolTipController = {
    Open: (mode: ToolTipInputMode, point?: ToolTipPoint) => void;
    Close: () => void;
    IsOpen: () => boolean;
    IsEnabled: () => boolean;
    Element: () => HTMLElement | null;
    UpdatePosition: () => Promise<void>;
};
export type ToolTipOwnerContext = {
    owner: Ref<HTMLElement | null>;
    inputMode: Ref<ToolTipInputMode>;
    point: Ref<ToolTipPoint | null>;
    theme: Ref<string>;
    attached?: boolean;
};
export declare const toolTipOwnerContextKey: InjectionKey<ToolTipOwnerContext>;
export declare const registerToolTip: (owner: HTMLElement, controller: ToolTipController) => () => void;
export declare const registeredToolTip: (owner: HTMLElement) => ToolTipController | undefined;
/** WinUI keeps a ToolTip open inside the convex hull of owner and popup. */
export declare const isInToolTipSafeZone: (point: ToolTipPoint, owner: DOMRect, tip: DOMRect) => boolean;
