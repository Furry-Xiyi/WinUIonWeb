declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    ClockIdentifier: {
        type: StringConstructor;
        default: undefined;
    };
    Header: {
        type: null;
        default: null;
    };
    HeaderTemplate: {
        type: null;
        default: null;
    };
    HeaderPlacement: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Language: {
        type: StringConstructor;
        default: string;
    };
    LightDismissOverlayMode: {
        type: StringConstructor;
        default: string;
    };
    MinuteIncrement: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    SelectedTime: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Time: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontWeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
}>, {
    Time: import("vue").WritableComputedRef<string | number | null | undefined, string | number | null | undefined>;
    SelectedTime: import("vue").WritableComputedRef<string | number | null | undefined, string | number | null | undefined>;
    Focus: () => void | undefined;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    TimeChanged: (...args: any[]) => void;
    SelectedTimeChanged: (...args: any[]) => void;
    "update:Time": (...args: any[]) => void;
    "update:SelectedTime": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    ClockIdentifier: {
        type: StringConstructor;
        default: undefined;
    };
    Header: {
        type: null;
        default: null;
    };
    HeaderTemplate: {
        type: null;
        default: null;
    };
    HeaderPlacement: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Language: {
        type: StringConstructor;
        default: string;
    };
    LightDismissOverlayMode: {
        type: StringConstructor;
        default: string;
    };
    MinuteIncrement: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    SelectedTime: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    Time: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontWeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
}>> & Readonly<{
    onTimeChanged?: ((...args: any[]) => any) | undefined;
    onSelectedTimeChanged?: ((...args: any[]) => any) | undefined;
    "onUpdate:Time"?: ((...args: any[]) => any) | undefined;
    "onUpdate:SelectedTime"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string;
    IsEnabled: string | boolean;
    Header: any;
    Background: string;
    BorderBrush: string;
    BorderThickness: string | number;
    CornerRadius: string | number;
    FontSize: string | number;
    FontFamily: string;
    FontWeight: string | number;
    RequestedTheme: string;
    HeaderTemplate: any;
    Visibility: string;
    Language: string;
    LightDismissOverlayMode: string;
    HeaderPlacement: string;
    ClockIdentifier: string;
    MinuteIncrement: string | number;
    SelectedTime: string | number;
    Time: string | number;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
