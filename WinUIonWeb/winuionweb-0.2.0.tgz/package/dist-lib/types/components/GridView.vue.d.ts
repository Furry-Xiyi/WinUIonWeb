declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    ItemsSource: {
        type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
        default: null;
    };
    IsGrouped: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsItemClickEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    CanDragItems: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    CanReorderItems: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    AllowDrop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
    SelectionMode: {
        type: StringConstructor;
        default: undefined;
    };
    SelectedItems: {
        type: (StringConstructor | ArrayConstructor)[];
        default: undefined;
    };
    SelectedItem: {
        type: null;
        default: undefined;
    };
    SelectedIndex: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    ItemTemplate: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    'ScrollViewer.IsHorizontalScrollChainingEnabled': {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
}>, {
    SemanticZoomOwner: import("vue").ShallowRef<import("./semanticZoomView").Owner | null, import("./semanticZoomView").Owner | null>;
    IsActiveView: import("vue").Ref<boolean, boolean>;
    IsZoomedInView: import("vue").Ref<boolean, boolean>;
    InitializeViewChange(): void;
    StartViewChangeFrom(source: import("./semanticZoomView").Location, destination: import("./semanticZoomView").Location): void;
    StartViewChangeTo(source: import("./semanticZoomView").Location, destination: import("./semanticZoomView").Location): void;
    MakeVisible: (location: import("./semanticZoomView").Location) => void;
    CompleteViewChangeFrom(_source: import("./semanticZoomView").Location, _destination: import("./semanticZoomView").Location): void;
    CompleteViewChangeTo(_source: import("./semanticZoomView").Location, destination: import("./semanticZoomView").Location): void;
    CompleteViewChange(): void;
    CanHorizontallyScroll: import("vue").ComputedRef<boolean>;
    CanVerticallyScroll: import("vue").ComputedRef<boolean>;
    ScrollIntoGroup: (group: any) => boolean;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    SelectionChanged: (...args: any[]) => void;
    ItemClick: (...args: any[]) => void;
    DragItemsStarting: (...args: any[]) => void;
    DragItemsCompleted: (...args: any[]) => void;
    DragOver: (...args: any[]) => void;
    Drop: (...args: any[]) => void;
    "update:ItemsSource": (...args: any[]) => void;
    "update:SelectedItem": (...args: any[]) => void;
    "update:SelectedItems": (...args: any[]) => void;
    "update:SelectedIndex": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    ItemsSource: {
        type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
        default: null;
    };
    IsGrouped: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsItemClickEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    CanDragItems: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    CanReorderItems: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    AllowDrop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
    SelectionMode: {
        type: StringConstructor;
        default: undefined;
    };
    SelectedItems: {
        type: (StringConstructor | ArrayConstructor)[];
        default: undefined;
    };
    SelectedItem: {
        type: null;
        default: undefined;
    };
    SelectedIndex: {
        type: (NumberConstructor | StringConstructor)[];
        default: undefined;
    };
    ItemTemplate: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    'ScrollViewer.IsHorizontalScrollChainingEnabled': {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
}>> & Readonly<{
    onSelectionChanged?: ((...args: any[]) => any) | undefined;
    onItemClick?: ((...args: any[]) => any) | undefined;
    onDragItemsStarting?: ((...args: any[]) => any) | undefined;
    onDragItemsCompleted?: ((...args: any[]) => any) | undefined;
    onDragOver?: ((...args: any[]) => any) | undefined;
    onDrop?: ((...args: any[]) => any) | undefined;
    "onUpdate:ItemsSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:SelectedItem"?: ((...args: any[]) => any) | undefined;
    "onUpdate:SelectedItems"?: ((...args: any[]) => any) | undefined;
    "onUpdate:SelectedIndex"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    IsEnabled: string | boolean;
    Background: string | Record<string, any>;
    BorderBrush: string;
    BorderThickness: string | number;
    CornerRadius: string | number;
    SelectedItem: any;
    ItemTemplate: string | Record<string, any>;
    FlowDirection: string;
    ItemsSource: string | unknown[] | Record<string, any>;
    SelectionMode: string;
    CanDragItems: string | boolean;
    CanReorderItems: string | boolean;
    AllowDrop: string | boolean;
    SelectedItems: string | unknown[];
    SelectedIndex: string | number;
    IsGrouped: string | boolean;
    IsItemClickEnabled: string | boolean;
    'ScrollViewer.IsHorizontalScrollChainingEnabled': string | boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
