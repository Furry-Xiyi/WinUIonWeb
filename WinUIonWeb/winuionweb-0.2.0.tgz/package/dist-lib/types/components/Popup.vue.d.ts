declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    IsOpen: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    Child: {
        type: (StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    Shadow: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    Translation: {
        type: (StringConstructor | ObjectConstructor)[];
        default: () => {
            X: number;
            Y: number;
            Z: number;
        };
    };
    HorizontalOffset: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    VerticalOffset: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    IsLightDismissEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    LightDismissOverlayMode: {
        type: StringConstructor;
        default: string;
    };
    ShouldConstrainToRootBounds: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    PlacementTarget: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    DesiredPlacement: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
}>, {
    IsOpen: import("vue").WritableComputedRef<boolean, boolean>;
    ActualPlacement: import("vue").ComputedRef<string>;
    HorizontalOffset: import("vue").WritableComputedRef<number, number>;
    VerticalOffset: import("vue").WritableComputedRef<number, number>;
    PlacementTarget: import("vue").WritableComputedRef<HTMLElement | null, HTMLElement | null>;
    DesiredPlacement: import("vue").WritableComputedRef<string, string>;
    IsLightDismissEnabled: import("vue").WritableComputedRef<boolean, boolean>;
    LightDismissOverlayMode: import("vue").WritableComputedRef<string, string>;
    RequestedTheme: import("vue").WritableComputedRef<string, string>;
    FlowDirection: import("vue").WritableComputedRef<string, string>;
    ShouldConstrainToRootBounds: import("vue").WritableComputedRef<boolean, boolean>;
    IsConstrainedToRootBounds: import("vue").ComputedRef<boolean>;
    Child: import("vue").WritableComputedRef<unknown, unknown>;
    Shadow: import("vue").WritableComputedRef<unknown, unknown>;
    Translation: import("vue").WritableComputedRef<string | {
        X?: number;
        Y?: number;
        Z?: number;
    }, string | {
        X?: number;
        Y?: number;
        Z?: number;
    }>;
    Element: import("vue").Ref<HTMLElement | null, HTMLElement | null>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Opened: (...args: any[]) => void;
    Closed: (...args: any[]) => void;
    ActualPlacementChanged: (...args: any[]) => void;
    "update:Shadow": (...args: any[]) => void;
    "update:Translation": (...args: any[]) => void;
    "update:IsOpen": (...args: any[]) => void;
    "update:Child": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    IsOpen: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    Child: {
        type: (StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    Shadow: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    Translation: {
        type: (StringConstructor | ObjectConstructor)[];
        default: () => {
            X: number;
            Y: number;
            Z: number;
        };
    };
    HorizontalOffset: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    VerticalOffset: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    IsLightDismissEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    LightDismissOverlayMode: {
        type: StringConstructor;
        default: string;
    };
    ShouldConstrainToRootBounds: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    PlacementTarget: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    DesiredPlacement: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onOpened?: ((...args: any[]) => any) | undefined;
    onClosed?: ((...args: any[]) => any) | undefined;
    onActualPlacementChanged?: ((...args: any[]) => any) | undefined;
    "onUpdate:Shadow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Translation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsOpen"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Child"?: ((...args: any[]) => any) | undefined;
}>, {
    RequestedTheme: string;
    Shadow: string | Record<string, any>;
    Translation: string | Record<string, any>;
    Child: string | Record<string, any>;
    FlowDirection: string;
    IsOpen: string | boolean;
    PlacementTarget: string | Record<string, any>;
    HorizontalOffset: string | number;
    VerticalOffset: string | number;
    ShouldConstrainToRootBounds: string | boolean;
    LightDismissOverlayMode: string;
    IsLightDismissEnabled: string | boolean;
    DesiredPlacement: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
