import './commandBarResources.css';
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    PrimaryCommands: {
        default: undefined;
    };
    SecondaryCommands: {
        default: undefined;
    };
    AlwaysExpanded: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Placement: {
        type: StringConstructor;
        default: string;
    };
    ShowMode: {
        type: StringConstructor;
        default: string;
    };
    AreOpenCloseAnimationsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    ShouldConstrainToRootBounds: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    LightDismissOverlayMode: {
        type: StringConstructor;
        default: string;
    };
}>, Record<string, unknown>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Opening: (...args: any[]) => void;
    Opened: (...args: any[]) => void;
    Closing: (...args: any[]) => void;
    Closed: (...args: any[]) => void;
    "update:PrimaryCommands": (...args: any[]) => void;
    "update:SecondaryCommands": (...args: any[]) => void;
    "update:AlwaysExpanded": (...args: any[]) => void;
    "update:Placement": (...args: any[]) => void;
    "update:ShowMode": (...args: any[]) => void;
    "update:AreOpenCloseAnimationsEnabled": (...args: any[]) => void;
    "update:ShouldConstrainToRootBounds": (...args: any[]) => void;
    "update:LightDismissOverlayMode": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    PrimaryCommands: {
        default: undefined;
    };
    SecondaryCommands: {
        default: undefined;
    };
    AlwaysExpanded: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Placement: {
        type: StringConstructor;
        default: string;
    };
    ShowMode: {
        type: StringConstructor;
        default: string;
    };
    AreOpenCloseAnimationsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    ShouldConstrainToRootBounds: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    LightDismissOverlayMode: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onOpening?: ((...args: any[]) => any) | undefined;
    onOpened?: ((...args: any[]) => any) | undefined;
    onClosing?: ((...args: any[]) => any) | undefined;
    onClosed?: ((...args: any[]) => any) | undefined;
    "onUpdate:PrimaryCommands"?: ((...args: any[]) => any) | undefined;
    "onUpdate:SecondaryCommands"?: ((...args: any[]) => any) | undefined;
    "onUpdate:AlwaysExpanded"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Placement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ShowMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:AreOpenCloseAnimationsEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ShouldConstrainToRootBounds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:LightDismissOverlayMode"?: ((...args: any[]) => any) | undefined;
}>, {
    Placement: string;
    PrimaryCommands: undefined;
    SecondaryCommands: undefined;
    AlwaysExpanded: string | boolean;
    ShowMode: string;
    AreOpenCloseAnimationsEnabled: string | boolean;
    ShouldConstrainToRootBounds: string | boolean;
    LightDismissOverlayMode: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
