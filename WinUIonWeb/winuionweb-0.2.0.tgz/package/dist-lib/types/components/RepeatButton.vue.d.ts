export declare const RepeatButtonContent: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: __VLS_WithSlots<import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Content: {
        type: null;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    ContentTemplate: {
        type: null;
        default: undefined;
    };
    ContentTransitions: {
        type: null;
        default: undefined;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    Delay: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Interval: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    ClickMode: {
        type: StringConstructor;
        default: string;
    };
}>, {
    Content: any;
    ContentTemplate: any;
    ContentTransitions: any;
    IsEnabled: boolean;
    Delay: number;
    Interval: number;
    RequestedTheme: string;
    Command: import("./uiCommandRuntime").UICommandMetadata | undefined;
    CommandParameter: unknown;
    Name: {};
    Element: any;
    IsPressed: any;
    Focus: () => any;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Click: (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Content: {
        type: null;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    ContentTemplate: {
        type: null;
        default: undefined;
    };
    ContentTransitions: {
        type: null;
        default: undefined;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    Delay: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Interval: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    ClickMode: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onClick?: ((...args: any[]) => any) | undefined;
}>, {
    IsEnabled: string | boolean;
    RequestedTheme: string;
    ContentTemplate: any;
    Content: any;
    ContentTransitions: any;
    ClickMode: string;
    Delay: string | number;
    Interval: string | number;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>, {
    default?: (props: {}) => any;
}>;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
