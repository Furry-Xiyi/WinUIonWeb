export declare const pivotResources: Readonly<Record<string, string | number>>;
