import type { SwipeItem, SwipeItems, SwipeMode } from './SwipeControl.types';
type ChangingHandler = (size: number, mode: SwipeMode) => void;
/** Internal ownership checks run before a vector mutation commits. */
export declare const observeSwipeItemsChanging: (collection: SwipeItemsCollection, owner: object, handler: ChangingHandler) => () => boolean;
export declare class SwipeItemsCollection implements SwipeItems {
    #private;
    constructor();
    get Mode(): SwipeMode;
    set Mode(value: SwipeMode);
    get Size(): number;
    get Count(): number;
    GetAt(index: number): SwipeItem;
    SetAt(index: number, value: SwipeItem): void;
    InsertAt(index: number, value: SwipeItem): void;
    RemoveAt(index: number): void;
    Append(value: SwipeItem): void;
    RemoveAtEnd(): void;
    Clear(): void;
    ReplaceAll(values: Iterable<SwipeItem>): void;
    IndexOf(value: SwipeItem): {
        found: boolean;
        index: number;
    };
    GetView(): ReadonlyArray<SwipeItem>;
    [Symbol.iterator](): Iterator<SwipeItem>;
}
export { SwipeItemsCollection as SwipeItems };
