import type { InjectionKey, VNode } from 'vue';
export type TextInputSurface = {
    Focused: () => void;
    Blurred: () => void;
    PointerEntered: (event: PointerEvent) => void;
    PointerExited: () => void;
};
export declare const textInputTemplateKey: InjectionKey<{
    Field?: (surface: TextInputSurface) => VNode | VNode[];
    Actions?: () => VNode | VNode[] | null;
    HideDeleteButton?: boolean;
    ActionsWidth?: () => number;
    ReserveDeleteButtonWidth?: number;
    DesiredWidthChanged?: (width: number) => void;
    KeyDown?: (event: KeyboardEvent) => void;
}>;
