import { type InjectionKey, type Ref } from 'vue';
export interface CommandBarContext {
    isOpen: Readonly<Ref<boolean>>;
    defaultLabelPosition: Readonly<Ref<string>>;
    isInOverflow: Readonly<Ref<boolean>>;
    isInFlyout?: Readonly<Ref<boolean>>;
    isEnabled?: Readonly<Ref<boolean>>;
    compact: Readonly<Ref<boolean>>;
    hasIcons: Readonly<Ref<boolean>>;
    hasToggleButtons: Readonly<Ref<boolean>>;
    closeOverflow: () => void;
    invokeCommand?: (sender: unknown, args: unknown) => void;
}
export declare const commandBarContextKey: InjectionKey<CommandBarContext>;
export interface AppBarToggleContext {
    checked: Readonly<Ref<boolean | null>>;
    toggle: (event: MouseEvent) => void;
    sender: () => unknown;
}
export declare const appBarToggleContextKey: InjectionKey<AppBarToggleContext | null>;
export declare const appBarProperty: (owner: "AppBarButton" | "AppBarToggleButton", property: string) => import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const appBarBoolean: (value: unknown) => value is true | "True";
