import { type ScrollBarScrollEventArgs } from './scrollBarOwner';
type __VLS_Props = {
    Value?: number | string;
    Minimum?: number | string;
    Maximum?: number | string;
    ViewportSize?: number | string;
    SmallChange?: number | string;
    LargeChange?: number | string;
    Orientation?: string;
    IndicatorMode?: string;
    IsEnabled?: boolean | string;
    Width?: number | string;
    Height?: number | string;
    Margin?: number | string;
    HorizontalAlignment?: string;
    VerticalAlignment?: string;
};
declare const __VLS_export: import("vue").DefineComponent<__VLS_Props, {
    Value: import("vue").WritableComputedRef<number, number>;
    Minimum: import("vue").ComputedRef<number>;
    Maximum: import("vue").ComputedRef<number>;
    ViewportSize: import("vue").ComputedRef<number>;
    Orientation: import("vue").ComputedRef<"Horizontal" | "Vertical">;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    ValueChanged: (sender: Record<string, unknown>, args: {
        OldValue: number;
        NewValue: number;
    }) => any;
    Scroll: (sender: Record<string, unknown>, args: ScrollBarScrollEventArgs) => any;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onValueChanged?: ((sender: Record<string, unknown>, args: {
        OldValue: number;
        NewValue: number;
    }) => any) | undefined;
    onScroll?: ((sender: Record<string, unknown>, args: ScrollBarScrollEventArgs) => any) | undefined;
}>, {
    IsEnabled: boolean | string;
    Value: number | string;
    Orientation: string;
    Minimum: number | string;
    Maximum: number | string;
    ViewportSize: number | string;
    SmallChange: number | string;
    LargeChange: number | string;
    IndicatorMode: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
