import { type Ref, type VNode } from 'vue';
export type TextFlyoutCommand = {
    Text?: string;
    Icon?: string;
    Value?: string;
    IsEnabled?: boolean;
};
export declare const textCommandFlyout: <T extends TextFlyoutCommand>(control: Ref<any>, commands: () => readonly T[], invoke: (command: T) => void, closed?: () => void, properties?: () => Record<string, unknown>) => import("vue").DefineComponent<{}, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
