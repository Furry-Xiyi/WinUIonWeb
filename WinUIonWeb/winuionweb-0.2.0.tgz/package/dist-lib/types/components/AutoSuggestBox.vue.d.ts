import type { VNode } from 'vue';
export declare const AutoSuggestBoxQueryIcon: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const AutoSuggestBoxHeader: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const AutoSuggestBoxDescription: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const AutoSuggestBoxHeaderTemplate: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const AutoSuggestBoxItemTemplate: import("vue").DefineComponent<{}, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const AutoSuggestBoxItemTemplateSelector: import("vue").DefineComponent<{}, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const AutoSuggestBoxResources: import("vue").DefineComponent<{}, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<{
    Text?: string;
    PlaceholderText?: string;
    Header?: unknown;
    HeaderTemplate?: unknown;
    Description?: string;
    QueryIcon?: string | VNode;
    ItemsSource?: (string | number | Record<string, unknown>)[] | string;
    ItemTemplate?: unknown;
    ItemTemplateSelector?: unknown;
    DisplayMemberPath?: string;
    TextMemberPath?: string;
    UpdateTextOnSelect?: boolean | string;
    IsSuggestionListOpen?: boolean | string;
    MaxSuggestionListHeight?: number | string;
    AutoMaximizeSuggestionArea?: boolean | string;
    DesiredCandidateWindowAlignment?: string;
    LightDismissOverlayMode?: string;
    TextBoxStyle?: unknown | null;
    KeepInteriorCornersSquare?: boolean | string;
    IsEnabled?: boolean | string;
    Width?: number | string;
}, {
    Text: string;
    ItemsSource: (string | number | Record<string, unknown>)[];
    IsSuggestionListOpen: boolean;
    ItemTemplate: unknown;
    ItemTemplateSelector: unknown;
    DisplayMemberPath: unknown;
    Header: unknown;
    HeaderTemplate: unknown;
    Description: unknown;
    Element: HTMLElement | null;
    Focus: () => true;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    SuggestionChosen: (sender: unknown, args: {
        SelectedItem: string | number | Record<string, unknown>;
    }) => any;
    TextChanged: (sender: unknown, args: {
        Reason: "SuggestionChosen" | "UserInput" | "ProgrammaticChange";
    }) => any;
    QuerySubmitted: (sender: unknown, args: {
        QueryText: string;
        ChosenSuggestion: (string | number | Record<string, unknown>) | null;
    }) => any;
    "update:Text": (value: string) => any;
    "update:IsSuggestionListOpen": (value: boolean) => any;
}, string, import("vue").PublicProps, Readonly<{
    Text?: string;
    PlaceholderText?: string;
    Header?: unknown;
    HeaderTemplate?: unknown;
    Description?: string;
    QueryIcon?: string | VNode;
    ItemsSource?: (string | number | Record<string, unknown>)[] | string;
    ItemTemplate?: unknown;
    ItemTemplateSelector?: unknown;
    DisplayMemberPath?: string;
    TextMemberPath?: string;
    UpdateTextOnSelect?: boolean | string;
    IsSuggestionListOpen?: boolean | string;
    MaxSuggestionListHeight?: number | string;
    AutoMaximizeSuggestionArea?: boolean | string;
    DesiredCandidateWindowAlignment?: string;
    LightDismissOverlayMode?: string;
    TextBoxStyle?: unknown | null;
    KeepInteriorCornersSquare?: boolean | string;
    IsEnabled?: boolean | string;
    Width?: number | string;
}> & Readonly<{
    onSuggestionChosen?: ((sender: unknown, args: {
        SelectedItem: string | number | Record<string, unknown>;
    }) => any) | undefined;
    onTextChanged?: ((sender: unknown, args: {
        Reason: "SuggestionChosen" | "UserInput" | "ProgrammaticChange";
    }) => any) | undefined;
    onQuerySubmitted?: ((sender: unknown, args: {
        QueryText: string;
        ChosenSuggestion: (string | number | Record<string, unknown>) | null;
    }) => any) | undefined;
    "onUpdate:Text"?: ((value: string) => any) | undefined;
    "onUpdate:IsSuggestionListOpen"?: ((value: boolean) => any) | undefined;
}>, {
    Width: number | string;
    Description: string;
    IsEnabled: boolean | string;
    Header: string;
    Text: string;
    ItemTemplate: undefined;
    HeaderTemplate: undefined;
    ItemsSource: (string | number | Record<string, unknown>)[] | string;
    ItemTemplateSelector: undefined;
    LightDismissOverlayMode: string;
    PlaceholderText: string;
    DesiredCandidateWindowAlignment: string;
    QueryIcon: string | VNode;
    DisplayMemberPath: string;
    TextMemberPath: string;
    UpdateTextOnSelect: boolean | string;
    IsSuggestionListOpen: boolean | string;
    MaxSuggestionListHeight: number | string;
    AutoMaximizeSuggestionArea: boolean | string;
    TextBoxStyle: undefined;
    KeepInteriorCornersSquare: boolean | string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
