export declare const animatedIconStateChangedEvent = "winui-animated-icon-state-changed";
export interface AnimatedIconStateChange {
    Target: object;
    State: string;
}
export declare const resolveAnimatedIconElement: (target: unknown) => Element | null;
export declare const GetState: (target: unknown) => string;
export declare const SetState: (target: unknown, value: unknown) => void;
export declare const findAnimatedIconStateAncestor: (target: unknown) => Element | null;
export declare const subscribeAnimatedIconState: (target: unknown, listener: (change: AnimatedIconStateChange) => void) => (() => void);
export declare const AnimatedIcon: Readonly<{
    SetState: (target: unknown, value: unknown) => void;
    GetState: (target: unknown) => string;
}>;
export declare const AnimatedIconAPI: Readonly<{
    SetState: (target: unknown, value: unknown) => void;
    GetState: (target: unknown) => string;
}>;
