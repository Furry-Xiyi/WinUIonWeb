/**
 * PersonPicture initials generation from WinUI-Reference's InitialsGenerator.cpp.
 * Windows wchar_t and JavaScript string indexing both use UTF-16 code units.
 */
export declare enum PersonPictureCharacterType {
    Other = 0,
    Standard = 1,
    Symbolic = 2,
    Glyph = 3
}
export interface PersonPictureContactName {
    FirstName?: string | null;
    LastName?: string | null;
    DisplayName?: string | null;
}
/** Classify the first three UTF-16 code units, with Glyph > Symbolic > Standard. */
export declare function getPersonPictureCharacterType(value: string): PersonPictureCharacterType;
/** Generate initials only for the character sets allowed by WinUI. */
export declare function initialsFromDisplayName(value: string | null | undefined): string;
/** Prefer a contact's FirstName and LastName when both are present. */
export declare function initialsFromContactObject(contact: PersonPictureContactName | null | undefined): string;
