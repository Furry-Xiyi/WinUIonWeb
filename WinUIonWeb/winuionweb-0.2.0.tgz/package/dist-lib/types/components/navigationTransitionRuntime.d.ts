import type { FrameNavigationMode } from './frameNavigationRuntime';
import type { NavigationPageStoryboard, NavigationStoryboardTarget, NavigationTransitionStoryboard } from './navigationTransitions/shared';
export type { NavigationAnimationTrack, NavigationPageStoryboard, NavigationTransitionStoryboard } from './navigationTransitions/shared';
/** Each official NavigationTransitionInfo owns its own independent storyboards. */
export declare const getNavigationTransitionStoryboard: (value: unknown, mode: FrameNavigationMode, enabled?: boolean) => NavigationTransitionStoryboard | null;
/** Resolve official attached target properties after the new Page has mounted. */
export declare const resolveNavigationPageStoryboards: (storyboard: NavigationTransitionStoryboard, root: HTMLElement, incoming: boolean) => NavigationStoryboardTarget[];
export declare const navigationStoryboardDuration: (source: NavigationPageStoryboard) => number;
