export type Locale = 'en-US' | 'zh-CN';
export type I18nValues = Record<string, string | number | boolean | null | undefined>;
export type ResourceMap = Record<string, string>;
export type ResourceBundle = Record<Locale, ResourceMap>;
export interface I18n {
    locale: Locale;
    t: (key: string, values?: I18nValues) => string;
}
export declare const i18nKey: unique symbol;
export declare const componentResources: ResourceBundle;
export declare const normalizeLocale: (locale?: string) => Locale;
export declare const createI18n: (locale?: string, extraResources?: Partial<ResourceBundle>) => I18n;
export declare const useI18n: () => I18n;
