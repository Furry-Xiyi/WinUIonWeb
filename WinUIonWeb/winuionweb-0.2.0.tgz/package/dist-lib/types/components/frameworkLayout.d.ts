import type { ComponentInternalInstance, CSSProperties } from 'vue';
export declare const frameworkLayoutStyle: (props: Record<string, unknown>, instance: ComponentInternalInstance | null) => CSSProperties;
