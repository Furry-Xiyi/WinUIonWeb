export declare const useAnimatedIconInput: (_selectedStates?: boolean, stateMapper?: (state: string, element: HTMLElement) => string) => {
    Attach: (element: unknown) => void;
    PointerEntered: (event: PointerEvent) => void;
    PointerExited: (event: PointerEvent) => void;
    PointerPressed: (event: PointerEvent) => void;
    PointerReleased: (event: PointerEvent) => void;
    KeyDown: (event: KeyboardEvent) => void;
    KeyUp: (event: KeyboardEvent) => void;
    LostFocus: (event: FocusEvent) => void;
    Reset: () => void;
    Refresh: () => void;
};
