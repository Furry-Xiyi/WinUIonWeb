export interface GridTrack {
    unit: 'auto' | 'pixel' | 'star';
    value: number;
    min: number;
    max: number;
}
export declare const parseGridTracks: (value: unknown, dimension: "Width" | "Height") => GridTrack[];
export declare const gridTrackCss: (track: GridTrack) => string;
/** Redistribute remaining star space after a definition reaches its min/max. */
export declare const constrainedStarSizes: (tracks: GridTrack[], available: number, measured: number[]) => number[];
