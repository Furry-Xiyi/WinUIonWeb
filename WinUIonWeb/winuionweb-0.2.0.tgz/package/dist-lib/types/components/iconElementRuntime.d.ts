import { type ComponentInternalInstance, type CSSProperties } from 'vue';
import './iconElementStyles.css';
/** Common FrameworkElement/IconElement dependency properties. */
export declare const iconElementProps: {
    Foreground: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: (StringConstructor | BooleanConstructor)[];
        default: string;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    IsHitTestVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
};
export declare const iconBoolean: (value: unknown, fallback?: boolean) => boolean;
export declare const iconFontFamily: (value: unknown) => string;
export declare const iconFontWeight: (value: unknown) => string | number;
export declare const useIconElement: (props: Record<string, unknown>, attrs: Record<string, unknown>, instance: ComponentInternalInstance | null, propertyNames?: string[]) => {
    Element: import("vue").Ref<HTMLElement | null, HTMLElement | null>;
    property: (name: string) => import("vue").WritableComputedRef<unknown, unknown>;
    read: (name: string) => unknown;
    resolve: (value: unknown) => unknown;
    layoutStyle: import("vue").ComputedRef<CSSProperties>;
    rootAttrs: import("vue").ComputedRef<{
        [k: string]: unknown;
    }>;
    api: Record<string, unknown>;
};
