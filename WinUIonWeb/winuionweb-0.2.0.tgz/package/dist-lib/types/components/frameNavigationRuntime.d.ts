export type FrameNavigationMode = 'New' | 'Back' | 'Forward';
export declare const navigationInputFrozen: import("vue").ShallowRef<boolean, boolean>;
export declare const acquireNavigationInputLock: (element?: HTMLElement | null) => (() => void);
export type NavigationCommit = {
    kind: 'Frame' | 'Route';
    completion: Promise<boolean>;
    complete: (navigated: boolean) => void;
};
export declare const pendingNavigationCompletion: () => Promise<boolean>;
export declare const pendingRouteNavigationCompletion: () => Promise<boolean>;
export declare const hasPendingRouteNavigation: () => boolean;
export declare const beginNavigationCommit: (element?: HTMLElement | null, kind?: NavigationCommit["kind"]) => NavigationCommit;
export declare const captureFrameNavigationCommit: <T>(action: () => T) => {
    result: T;
    hasRouteNavigation: boolean;
    completion: Promise<boolean>;
    release: () => void;
};
export interface SlideNavigationTimeline {
    Axis: 'X' | 'Y';
    ExitOffset: number;
    EntranceOffset: number;
    ExitDuration: number;
    EntranceDelay: number;
    EntranceDuration: number;
    ExitEasing: string;
    EntranceEasing: string;
}
export declare const getSlideNavigationTimeline: (info: unknown, mode: FrameNavigationMode) => SlideNavigationTimeline | null;
