export interface PopupBounds {
    left: number;
    top: number;
    right: number;
    bottom: number;
    width: number;
    height: number;
}
export interface PopupSize {
    width: number;
    height: number;
}
export declare const resolvePopupElement: (value: unknown) => HTMLElement | null;
export declare const popupBoundsFor: (element: Element | null, shouldConstrainToRootBounds?: boolean) => PopupBounds;
export declare const fitPopupPosition: (position: {
    left: number;
    top: number;
}, size: PopupSize, available: PopupBounds) => {
    left: number;
    top: number;
};
export declare const popupPlacementPosition: (target: PopupBounds | DOMRect, size: PopupSize, desiredPlacement: string, available: PopupBounds, gap?: number, rtl?: boolean) => {
    left: number;
    top: number;
    placement: string;
};
