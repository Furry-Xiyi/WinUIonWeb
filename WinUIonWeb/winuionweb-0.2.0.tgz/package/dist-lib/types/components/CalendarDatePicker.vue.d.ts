declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    CalendarIdentifier: {
        type: StringConstructor;
        default: string;
    };
    CalendarViewStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    Date: {
        type: (StringConstructor | DateConstructor)[];
        default: undefined;
    };
    DateFormat: {
        type: StringConstructor;
        default: string;
    };
    DayOfWeekFormat: {
        type: StringConstructor;
        default: string;
    };
    Description: {
        type: null;
        default: string;
    };
    DisplayMode: {
        type: StringConstructor;
        default: string;
    };
    FirstDayOfWeek: {
        type: StringConstructor;
        default: string;
    };
    Header: {
        type: null;
        default: string;
    };
    HeaderPlacement: {
        type: StringConstructor;
        default: string;
    };
    HeaderTemplate: {
        type: null;
        default: null;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsCalendarOpen: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    IsGroupLabelVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsOutOfScopeEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTodayHighlighted: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    LightDismissOverlayMode: {
        type: StringConstructor;
        default: string;
    };
    MaxDate: {
        type: (StringConstructor | DateConstructor)[];
        default: () => Date;
    };
    MinDate: {
        type: (StringConstructor | DateConstructor)[];
        default: () => Date;
    };
    PlaceholderText: {
        type: StringConstructor;
        default: string;
    };
    Language: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
}>, {
    Date: globalThis.Date | null;
    IsCalendarOpen: boolean;
    SetDisplayDate(input: globalThis.Date | string): void;
    SetYearDecadeDisplayDimensions(columns: number, rows: number): void;
    Focus: () => boolean;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Opened: (...args: any[]) => void;
    Closed: (...args: any[]) => void;
    DateChanged: (...args: any[]) => void;
    CalendarViewDayItemChanging: (...args: any[]) => void;
    "update:Date": (...args: any[]) => void;
    "update:IsCalendarOpen": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    CalendarIdentifier: {
        type: StringConstructor;
        default: string;
    };
    CalendarViewStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    Date: {
        type: (StringConstructor | DateConstructor)[];
        default: undefined;
    };
    DateFormat: {
        type: StringConstructor;
        default: string;
    };
    DayOfWeekFormat: {
        type: StringConstructor;
        default: string;
    };
    Description: {
        type: null;
        default: string;
    };
    DisplayMode: {
        type: StringConstructor;
        default: string;
    };
    FirstDayOfWeek: {
        type: StringConstructor;
        default: string;
    };
    Header: {
        type: null;
        default: string;
    };
    HeaderPlacement: {
        type: StringConstructor;
        default: string;
    };
    HeaderTemplate: {
        type: null;
        default: null;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsCalendarOpen: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    IsGroupLabelVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsOutOfScopeEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTodayHighlighted: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    LightDismissOverlayMode: {
        type: StringConstructor;
        default: string;
    };
    MaxDate: {
        type: (StringConstructor | DateConstructor)[];
        default: () => Date;
    };
    MinDate: {
        type: (StringConstructor | DateConstructor)[];
        default: () => Date;
    };
    PlaceholderText: {
        type: StringConstructor;
        default: string;
    };
    Language: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onOpened?: ((...args: any[]) => any) | undefined;
    onClosed?: ((...args: any[]) => any) | undefined;
    onDateChanged?: ((...args: any[]) => any) | undefined;
    onCalendarViewDayItemChanging?: ((...args: any[]) => any) | undefined;
    "onUpdate:Date"?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsCalendarOpen"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string;
    Description: any;
    IsEnabled: string | boolean;
    Header: any;
    Background: string;
    BorderBrush: string;
    BorderThickness: string | number;
    CornerRadius: string | number;
    RequestedTheme: string;
    HeaderTemplate: any;
    CalendarViewStyle: string | Record<string, any>;
    Visibility: string;
    Language: string;
    LightDismissOverlayMode: string;
    PlaceholderText: string;
    HeaderPlacement: string;
    DisplayMode: string;
    CalendarIdentifier: string;
    DayOfWeekFormat: string;
    FirstDayOfWeek: string;
    IsGroupLabelVisible: string | boolean;
    IsOutOfScopeEnabled: string | boolean;
    IsTodayHighlighted: string | boolean;
    MaxDate: string | Date;
    MinDate: string | Date;
    Date: string | Date;
    DateFormat: string;
    IsCalendarOpen: string | boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
