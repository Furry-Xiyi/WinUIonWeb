import { DesktopAcrylicBackdrop as DesktopAcrylicBackdropValue, MicaBackdrop as MicaBackdropValue } from './systemBackdrop';
import type { XamlResourceFactoryContext } from './UICommandProperties';
export declare const createMicaBackdropResource: (read: (name: string) => unknown, context?: Pick<XamlResourceFactoryContext, "Dispose">) => MicaBackdropValue;
export declare const createDesktopAcrylicBackdropResource: () => DesktopAcrylicBackdropValue;
export declare const MicaBackdrop: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Kind: {
        type: StringConstructor;
        default: string;
    };
}>, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Kind: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{}>, {
    Kind: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const DesktopAcrylicBackdrop: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const SystemBackdropElementSystemBackdrop: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
