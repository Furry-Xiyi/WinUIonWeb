import { getCurrentInstance, type VNode } from 'vue';
export declare const buttonContentProperty: (owner: string, property: "ContentTemplate" | "ContentTransitions" | "Resources") => import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const getButtonContentProperty: (node: VNode) => string | undefined;
export declare const useButtonContent: (props: Record<string, unknown>, readNodes: () => VNode[], instance: ReturnType<typeof getCurrentInstance>) => {
    ContentTemplate: import("vue").WritableComputedRef<any, any>;
    ContentTransitions: import("vue").WritableComputedRef<any, any>;
    renderTemplate: (value: unknown) => any;
};
