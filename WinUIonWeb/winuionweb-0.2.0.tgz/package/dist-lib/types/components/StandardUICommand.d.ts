import { XamlUICommand, type XamlUICommandOptions } from './XamlUICommand';
export declare const StandardUICommandKind: {
    readonly None: "None";
    readonly Cut: "Cut";
    readonly Copy: "Copy";
    readonly Paste: "Paste";
    readonly SelectAll: "SelectAll";
    readonly Delete: "Delete";
    readonly Share: "Share";
    readonly Save: "Save";
    readonly Open: "Open";
    readonly Close: "Close";
    readonly Pause: "Pause";
    readonly Play: "Play";
    readonly Stop: "Stop";
    readonly Forward: "Forward";
    readonly Backward: "Backward";
    readonly Undo: "Undo";
    readonly Redo: "Redo";
};
export type StandardUICommandKind = typeof StandardUICommandKind[keyof typeof StandardUICommandKind];
/** The web equivalent of Microsoft.UI.Xaml.Input.StandardUICommand. */
export declare class StandardUICommand extends XamlUICommand {
    private kind;
    private settingDefaults;
    private ownsLabel;
    private ownsDescription;
    private ownsIcon;
    private ownsAccelerators;
    private previousKey;
    private previousModifiers;
    constructor(Kind?: StandardUICommandKind, options?: XamlUICommandOptions);
    get Kind(): StandardUICommandKind;
    set Kind(value: StandardUICommandKind);
    protected OnPropertySet(property: string): void;
    private PopulateForKind;
}
export default StandardUICommand;
