export declare const linearMathToElement: (source: string) => Element;
export declare const parseMathML: (source: string) => Element;
export declare const loadRtf: (source: string | ArrayBuffer) => Promise<HTMLElement[]>;
export declare const saveRtf: (editor: HTMLElement) => string;
