declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    IsOpen: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Title: {
        type: StringConstructor;
        default: string;
    };
    Message: {
        type: StringConstructor;
        default: string;
    };
    Severity: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    IconSource: {
        type: null;
        default: null;
    };
    IsIconVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsClosable: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    CloseButtonStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    CloseButtonCommand: {
        type: null;
        default: null;
    };
    CloseButtonCommandParameter: {
        type: null;
        default: null;
    };
    ActionButton: {
        type: null;
        default: null;
    };
    Content: {
        type: null;
        default: null;
    };
    ContentTemplate: {
        type: null;
        default: null;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
}>, {
    IsOpen: boolean;
    Title: unknown;
    Message: unknown;
    Severity: unknown;
    IsIconVisible: unknown;
    IsClosable: unknown;
    IsEnabled: unknown;
    RequestedTheme: unknown;
    ActionButton: unknown;
    IconSource: unknown;
    Content: unknown;
    ContentTemplate: unknown;
    TemplateSettings: {
        IconElement: unknown;
    };
    Background: unknown;
    Foreground: unknown;
    BorderBrush: unknown;
    BorderThickness: unknown;
    CornerRadius: unknown;
    CloseButtonStyle: unknown;
    CloseButtonCommand: unknown;
    CloseButtonCommandParameter: unknown;
    Element: HTMLElement | null;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Opened: (...args: any[]) => void;
    Closing: (...args: any[]) => void;
    Closed: (...args: any[]) => void;
    CloseButtonClick: (...args: any[]) => void;
    "update:IsOpen": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    IsOpen: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Title: {
        type: StringConstructor;
        default: string;
    };
    Message: {
        type: StringConstructor;
        default: string;
    };
    Severity: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    IconSource: {
        type: null;
        default: null;
    };
    IsIconVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsClosable: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    CloseButtonStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    CloseButtonCommand: {
        type: null;
        default: null;
    };
    CloseButtonCommandParameter: {
        type: null;
        default: null;
    };
    ActionButton: {
        type: null;
        default: null;
    };
    Content: {
        type: null;
        default: null;
    };
    ContentTemplate: {
        type: null;
        default: null;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
}>> & Readonly<{
    onOpened?: ((...args: any[]) => any) | undefined;
    onClosing?: ((...args: any[]) => any) | undefined;
    onClosed?: ((...args: any[]) => any) | undefined;
    onCloseButtonClick?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsOpen"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string;
    IconSource: any;
    IsEnabled: string | boolean;
    Background: string;
    BorderBrush: string;
    BorderThickness: string | number;
    CornerRadius: string | number;
    RequestedTheme: string;
    ContentTemplate: any;
    CloseButtonStyle: string | Record<string, any>;
    Visibility: string;
    Content: any;
    IsClosable: string | boolean;
    Message: string;
    IsOpen: string | boolean;
    Title: string;
    CloseButtonCommand: any;
    CloseButtonCommandParameter: any;
    ActionButton: any;
    Severity: string | number;
    IsIconVisible: string | boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
