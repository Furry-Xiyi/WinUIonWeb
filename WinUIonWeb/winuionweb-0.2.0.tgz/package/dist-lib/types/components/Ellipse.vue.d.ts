declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Fill: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Stroke: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    StrokeThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    StrokeDashArray: {
        type: (StringConstructor | ArrayConstructor)[];
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Fill: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Stroke: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    StrokeThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    StrokeDashArray: {
        type: (StringConstructor | ArrayConstructor)[];
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Opacity: string | number;
    Fill: string | Record<string, any>;
    Stroke: string | Record<string, any>;
    Visibility: string;
    StrokeThickness: string | number;
    StrokeDashArray: string | unknown[];
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
