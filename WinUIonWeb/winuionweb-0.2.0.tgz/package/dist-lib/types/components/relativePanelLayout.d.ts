type Relation = 'LeftOf' | 'Above' | 'RightOf' | 'Below' | 'AlignLeftWith' | 'AlignTopWith' | 'AlignRightWith' | 'AlignBottomWith' | 'AlignHorizontalCenterWith' | 'AlignVerticalCenterWith';
type PanelRelation = 'AlignLeftWithPanel' | 'AlignTopWithPanel' | 'AlignRightWithPanel' | 'AlignBottomWithPanel' | 'AlignHorizontalCenterWithPanel' | 'AlignVerticalCenterWithPanel';
export type RelativePanelItem = {
    name?: string;
    desiredSize: [number, number];
    relations?: Partial<Record<Relation, string>>;
    panelRelations?: Partial<Record<PanelRelation, boolean>>;
};
export declare const resolveRelativePanelLayout: (items: RelativePanelItem[], availableSize: [number, number], finalSize?: [number, number], measure?: (index: number, available: [number, number]) => [number, number]) => {
    desiredSize: [number, number];
    measuredSizes: [number, number][];
    rectangles: {
        x: number;
        y: number;
        width: number;
        height: number;
    }[];
};
export declare const relativePanelStyleChanged: (element: HTMLElement) => boolean;
export declare const arrangeRelativePanel: (root: HTMLElement, options: {
    autoWidth: boolean;
    autoHeight: boolean;
    minimumHeight?: number;
}) => {
    width: number;
    height: number;
};
export {};
