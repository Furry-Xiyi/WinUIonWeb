declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Content: {
        type: null;
        default: undefined;
    };
    ContentTemplate: {
        type: null;
        default: undefined;
    };
    ContentTransitions: {
        type: null;
        default: undefined;
    };
    Flyout: {
        type: null;
        default: null;
    };
    Command: {
        type: (StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    CommandParameter: {
        default: undefined;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    ClickMode: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BackgroundSizing: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    FontWeight: {
        type: StringConstructor;
        default: string;
    };
    UseSystemFocusVisuals: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FocusVisualMargin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
}>, {
    Element: HTMLButtonElement | null;
    Name: {};
    Content: unknown;
    ContentTemplate: any;
    ContentTransitions: any;
    IsEnabled: boolean;
    RequestedTheme: unknown;
    Command: import("./uiCommandRuntime").UICommandMetadata | undefined;
    CommandParameter: unknown;
    Flyout: any;
    IsPressed: boolean;
    IsPointerOver: boolean;
    Focus: () => boolean;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Click: (...args: any[]) => void;
    KeyDown: (...args: any[]) => void;
    GotFocus: (...args: any[]) => void;
    LostFocus: (...args: any[]) => void;
    PointerMoved: (...args: any[]) => void;
    PointerPressed: (...args: any[]) => void;
    PointerReleased: (...args: any[]) => void;
    PointerEntered: (...args: any[]) => void;
    PointerExited: (...args: any[]) => void;
    PointerCanceled: (...args: any[]) => void;
    PointerCaptureLost: (...args: any[]) => void;
    KeyUp: (...args: any[]) => void;
    ContextRequested: (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Content: {
        type: null;
        default: undefined;
    };
    ContentTemplate: {
        type: null;
        default: undefined;
    };
    ContentTransitions: {
        type: null;
        default: undefined;
    };
    Flyout: {
        type: null;
        default: null;
    };
    Command: {
        type: (StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    CommandParameter: {
        default: undefined;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    ClickMode: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BackgroundSizing: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    FontWeight: {
        type: StringConstructor;
        default: string;
    };
    UseSystemFocusVisuals: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FocusVisualMargin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
}>> & Readonly<{
    onClick?: ((...args: any[]) => any) | undefined;
    onKeyDown?: ((...args: any[]) => any) | undefined;
    onGotFocus?: ((...args: any[]) => any) | undefined;
    onLostFocus?: ((...args: any[]) => any) | undefined;
    onPointerMoved?: ((...args: any[]) => any) | undefined;
    onPointerPressed?: ((...args: any[]) => any) | undefined;
    onPointerReleased?: ((...args: any[]) => any) | undefined;
    onPointerEntered?: ((...args: any[]) => any) | undefined;
    onPointerExited?: ((...args: any[]) => any) | undefined;
    onPointerCanceled?: ((...args: any[]) => any) | undefined;
    onPointerCaptureLost?: ((...args: any[]) => any) | undefined;
    onKeyUp?: ((...args: any[]) => any) | undefined;
    onContextRequested?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string;
    Command: string | Record<string, any>;
    IsEnabled: string | boolean;
    Background: string | Record<string, any>;
    BorderBrush: string;
    BorderThickness: string | number;
    CornerRadius: string | number;
    FontSize: string | number;
    HorizontalContentAlignment: string;
    VerticalContentAlignment: string;
    UseSystemFocusVisuals: string | boolean;
    IsTabStop: string | boolean;
    BackgroundSizing: string;
    FocusVisualMargin: string | number;
    FontFamily: string;
    FontWeight: string;
    RequestedTheme: string;
    Flyout: any;
    ContentTemplate: any;
    Visibility: string;
    Content: any;
    ContentTransitions: any;
    CommandParameter: undefined;
    ClickMode: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
