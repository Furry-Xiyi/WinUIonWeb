import type { ComponentInternalInstance, InjectionKey, Ref } from 'vue';
export interface ParallaxSize {
    width: number;
    height: number;
}
export interface ParallaxChildLayout {
    availableSize: Ref<ParallaxSize>;
    arrangedSize: Ref<ParallaxSize | null>;
    isDirectChild(instance: ComponentInternalInstance | null): boolean;
    reportDesiredSize(size: ParallaxSize): void;
}
export declare const parallaxChildLayoutKey: InjectionKey<ParallaxChildLayout>;
export declare function measureParallaxAxis(availableSize: number, childDesiredSize: number, minSize: number, maxSize: number): {
    availableSize: number;
    desiredSize: number;
};
export interface ParallaxOffsetsInput {
    kind: 'Absolute' | 'Relative';
    startOffset: number;
    endOffset: number;
    viewportSize: number;
    contentSize: number;
    zoomFactor: number;
    underpan: number;
    overpan: number;
    insideSource: boolean;
    parallaxOffset: number;
    parallaxSize: number;
}
export declare function resolveParallaxOffsets(input: ParallaxOffsetsInput): {
    startOffset: number;
    endOffset: number;
};
export interface ParallaxTranslationInput {
    position: number;
    startOffset: number;
    endOffset: number;
    shift: number;
    maxRatio: number;
    clamped: boolean;
}
export declare function computeParallaxTranslation(input: ParallaxTranslationInput): number;
export interface ParallaxArrangeInput {
    width: number;
    height: number;
    desiredWidth: number;
    desiredHeight: number;
    horizontalShift: number;
    verticalShift: number;
    horizontalAlignment: string;
    verticalAlignment: string;
    autoWidth: boolean;
    autoHeight: boolean;
}
export declare function arrangeParallaxChild(input: ParallaxArrangeInput): {
    x: number;
    y: number;
    width: number;
    height: number;
};
