declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    NumberOfPages: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    SelectedPageIndex: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxVisiblePips: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Orientation: {
        type: StringConstructor;
        default: string;
    };
    PreviousButtonVisibility: {
        type: StringConstructor;
        default: string;
    };
    NextButtonVisibility: {
        type: StringConstructor;
        default: string;
    };
    PreviousButtonStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    NextButtonStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    SelectedPipStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    NormalPipStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    WrapMode: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
}>, {
    NumberOfPages: import("vue").WritableComputedRef<unknown, unknown>;
    SelectedPageIndex: import("vue").WritableComputedRef<number, number>;
    MaxVisiblePips: import("vue").WritableComputedRef<unknown, unknown>;
    Orientation: import("vue").WritableComputedRef<unknown, unknown>;
    PreviousButtonVisibility: import("vue").WritableComputedRef<unknown, unknown>;
    NextButtonVisibility: import("vue").WritableComputedRef<unknown, unknown>;
    PreviousButtonStyle: import("vue").WritableComputedRef<unknown, unknown>;
    NextButtonStyle: import("vue").WritableComputedRef<unknown, unknown>;
    SelectedPipStyle: import("vue").WritableComputedRef<unknown, unknown>;
    NormalPipStyle: import("vue").WritableComputedRef<unknown, unknown>;
    WrapMode: import("vue").WritableComputedRef<unknown, unknown>;
    IsEnabled: import("vue").WritableComputedRef<unknown, unknown>;
    TemplateSettings: import("vue").ComputedRef<{
        PipsPagerItems: number[];
    }>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    SelectedIndexChanged: (...args: any[]) => void;
    "update:SelectedPageIndex": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    NumberOfPages: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    SelectedPageIndex: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxVisiblePips: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Orientation: {
        type: StringConstructor;
        default: string;
    };
    PreviousButtonVisibility: {
        type: StringConstructor;
        default: string;
    };
    NextButtonVisibility: {
        type: StringConstructor;
        default: string;
    };
    PreviousButtonStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    NextButtonStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    SelectedPipStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    NormalPipStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    WrapMode: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onSelectedIndexChanged?: ((...args: any[]) => any) | undefined;
    "onUpdate:SelectedPageIndex"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    IsEnabled: string | boolean;
    Background: string;
    IsTabStop: string | boolean;
    PreviousButtonStyle: string | Record<string, any>;
    NextButtonStyle: string | Record<string, any>;
    SelectedPipStyle: string | Record<string, any>;
    NormalPipStyle: string | Record<string, any>;
    FlowDirection: string;
    Orientation: string;
    NumberOfPages: string | number;
    SelectedPageIndex: string | number;
    MaxVisiblePips: string | number;
    PreviousButtonVisibility: string;
    NextButtonVisibility: string;
    WrapMode: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
