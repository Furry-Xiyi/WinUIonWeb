export declare const swipeControlResources: Readonly<Record<string, string>>;
