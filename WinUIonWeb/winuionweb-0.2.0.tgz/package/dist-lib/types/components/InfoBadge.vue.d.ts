export declare const InfoBadgeIconSourceProperty: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Value: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    IconSource: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    Style: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
}>, {
    Value: import("vue").WritableComputedRef<number, unknown>;
    Style: import("vue").WritableComputedRef<unknown, unknown>;
    IconSource: import("vue").WritableComputedRef<Record<string, unknown> | null, unknown>;
    RequestedTheme: import("vue").WritableComputedRef<string, string>;
    TemplateSettings: import("vue").ComputedRef<{
        InfoBadgeCornerRadius: unknown;
        IconElement: Record<string, unknown> | null;
    }>;
    Element: import("vue").Ref<HTMLElement | null, HTMLElement | null>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:Style": (...args: any[]) => void;
    "update:Value": (...args: any[]) => void;
    "update:IconSource": (...args: any[]) => void;
    "update:RequestedTheme": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Value: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    IconSource: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    Style: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
}>> & Readonly<{
    "onUpdate:Style"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Value"?: ((...args: any[]) => any) | undefined;
    "onUpdate:IconSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:RequestedTheme"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string;
    Opacity: string | number;
    IconSource: string | Record<string, any>;
    IsEnabled: string | boolean;
    Value: string | number;
    Background: string;
    CornerRadius: string | number;
    IsTabStop: string | boolean;
    RequestedTheme: string;
    Style: string | Record<string, any>;
    Visibility: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
