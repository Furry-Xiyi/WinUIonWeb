declare var __VLS_29: {};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_29) => any;
};
declare const __VLS_base: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Content: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    IsChecked: {
        type: (StringConstructor | BooleanConstructor | null)[];
        default: undefined;
    };
    IsThreeState: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Margin: {
        type: StringConstructor;
        default: string;
    };
}>, {
    IsChecked: boolean | null;
    readonly IsEnabled: boolean;
    readonly Content: unknown;
    readonly Element: HTMLElement | null;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Click: (...args: any[]) => void;
    Checked: (...args: any[]) => void;
    Unchecked: (...args: any[]) => void;
    Indeterminate: (...args: any[]) => void;
    "update:IsChecked": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Content: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    IsChecked: {
        type: (StringConstructor | BooleanConstructor | null)[];
        default: undefined;
    };
    IsThreeState: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Margin: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onClick?: ((...args: any[]) => any) | undefined;
    onChecked?: ((...args: any[]) => any) | undefined;
    onUnchecked?: ((...args: any[]) => any) | undefined;
    onIndeterminate?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsChecked"?: ((...args: any[]) => any) | undefined;
}>, {
    Margin: string;
    IsEnabled: string | boolean;
    IsTabStop: string | boolean;
    IsChecked: string | boolean | null;
    Content: string | number;
    IsThreeState: string | boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const __VLS_export: __VLS_WithSlots<typeof __VLS_base, __VLS_Slots>;
declare const _default: typeof __VLS_export;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
