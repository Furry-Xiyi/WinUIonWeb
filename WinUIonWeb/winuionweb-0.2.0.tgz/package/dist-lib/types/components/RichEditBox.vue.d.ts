declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<{
    AcceptsReturn?: boolean;
    CharacterCasing?: "Normal" | "Lower" | "Upper";
    ClipboardCopyFormat?: "AllFormats" | "PlainText";
    Description?: string;
    DesiredCandidateWindowAlignment?: "Default" | "BottomEdge";
    DisabledFormattingAccelerators?: string;
    FontFamily?: string;
    FontSize?: number | string;
    FontWeight?: number | string;
    FontStyle?: string;
    Header?: string;
    HeaderPlacement?: "Left" | "Top";
    HeaderTemplate?: unknown | null;
    HorizontalTextAlignment?: "Left" | "Center" | "Right" | "Justify";
    InputScope?: string;
    IsColorFontEnabled?: boolean;
    IsReadOnly?: boolean;
    IsEnabled?: boolean;
    IsSpellCheckEnabled?: boolean;
    IsTextPredictionEnabled?: boolean;
    MaxLength?: number;
    PlaceholderText?: string;
    PreventKeyboardDisplayOnProgrammaticFocus?: boolean;
    ProofingMenuFlyout?: unknown | null;
    SelectionFlyout?: unknown | null;
    ContextFlyout?: unknown | null;
    SelectionHighlightColor?: string;
    SelectionHighlightColorWhenNotFocused?: string;
    TextAlignment?: "Left" | "Center" | "Right" | "Justify";
    TextReadingOrder?: "Default" | "DetectFromContent" | "UseFlowDirection";
    TextWrapping?: "WrapWholeWords" | "NoWrap" | "Wrap";
    Width?: number | string;
    Height?: number | string;
    MinHeight?: number | string;
}, Record<string | symbol, unknown>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Paste: (args: {
        Handled: boolean;
    }) => any;
    TextCompositionStarted: () => any;
    TextCompositionChanged: () => any;
    TextCompositionEnded: () => any;
    TextChanging: (args: {
        IsContentChanging: boolean;
    }) => any;
    SelectionChanging: (args: {
        SelectionStart: number;
        SelectionLength: number;
        Cancel: boolean;
    }) => any;
    CopyingToClipboard: (args: {
        Handled: boolean;
    }) => any;
    CuttingToClipboard: (args: {
        Handled: boolean;
    }) => any;
    ContextMenuOpening: (args: {
        Handled: boolean;
        CursorLeft: number;
        CursorTop: number;
    }) => any;
    CandidateWindowBoundsChanged: (args: {
        rect: DOMRect | {
            x: number;
            y: number;
            width: number;
            height: number;
        };
    }) => any;
    Unloaded: (sender?: unknown, args?: unknown) => any;
    SelectionChanged: (sender?: unknown, args?: unknown) => any;
    TextChanged: (sender?: unknown, args?: unknown) => any;
    GotFocus: (sender?: unknown, args?: unknown) => any;
    LostFocus: (sender?: unknown, args?: unknown) => any;
    Loaded: (sender?: unknown, args?: unknown) => any;
}, string, import("vue").PublicProps, Readonly<{
    AcceptsReturn?: boolean;
    CharacterCasing?: "Normal" | "Lower" | "Upper";
    ClipboardCopyFormat?: "AllFormats" | "PlainText";
    Description?: string;
    DesiredCandidateWindowAlignment?: "Default" | "BottomEdge";
    DisabledFormattingAccelerators?: string;
    FontFamily?: string;
    FontSize?: number | string;
    FontWeight?: number | string;
    FontStyle?: string;
    Header?: string;
    HeaderPlacement?: "Left" | "Top";
    HeaderTemplate?: unknown | null;
    HorizontalTextAlignment?: "Left" | "Center" | "Right" | "Justify";
    InputScope?: string;
    IsColorFontEnabled?: boolean;
    IsReadOnly?: boolean;
    IsEnabled?: boolean;
    IsSpellCheckEnabled?: boolean;
    IsTextPredictionEnabled?: boolean;
    MaxLength?: number;
    PlaceholderText?: string;
    PreventKeyboardDisplayOnProgrammaticFocus?: boolean;
    ProofingMenuFlyout?: unknown | null;
    SelectionFlyout?: unknown | null;
    ContextFlyout?: unknown | null;
    SelectionHighlightColor?: string;
    SelectionHighlightColorWhenNotFocused?: string;
    TextAlignment?: "Left" | "Center" | "Right" | "Justify";
    TextReadingOrder?: "Default" | "DetectFromContent" | "UseFlowDirection";
    TextWrapping?: "WrapWholeWords" | "NoWrap" | "Wrap";
    Width?: number | string;
    Height?: number | string;
    MinHeight?: number | string;
}> & Readonly<{
    onPaste?: ((args: {
        Handled: boolean;
    }) => any) | undefined;
    onTextCompositionStarted?: (() => any) | undefined;
    onTextCompositionChanged?: (() => any) | undefined;
    onTextCompositionEnded?: (() => any) | undefined;
    onTextChanging?: ((args: {
        IsContentChanging: boolean;
    }) => any) | undefined;
    onSelectionChanging?: ((args: {
        SelectionStart: number;
        SelectionLength: number;
        Cancel: boolean;
    }) => any) | undefined;
    onCopyingToClipboard?: ((args: {
        Handled: boolean;
    }) => any) | undefined;
    onCuttingToClipboard?: ((args: {
        Handled: boolean;
    }) => any) | undefined;
    onContextMenuOpening?: ((args: {
        Handled: boolean;
        CursorLeft: number;
        CursorTop: number;
    }) => any) | undefined;
    onCandidateWindowBoundsChanged?: ((args: {
        rect: DOMRect | {
            x: number;
            y: number;
            width: number;
            height: number;
        };
    }) => any) | undefined;
    onUnloaded?: ((sender?: unknown, args?: unknown) => any) | undefined;
    onSelectionChanged?: ((sender?: unknown, args?: unknown) => any) | undefined;
    onTextChanged?: ((sender?: unknown, args?: unknown) => any) | undefined;
    onGotFocus?: ((sender?: unknown, args?: unknown) => any) | undefined;
    onLostFocus?: ((sender?: unknown, args?: unknown) => any) | undefined;
    onLoaded?: ((sender?: unknown, args?: unknown) => any) | undefined;
}>, {
    Width: number | string;
    Height: number | string;
    MinHeight: number | string;
    Description: string;
    IsEnabled: boolean;
    Header: string;
    FontSize: number | string;
    FontFamily: string;
    FontWeight: number | string;
    HeaderTemplate: undefined;
    ContextFlyout: undefined;
    FontStyle: string;
    TextAlignment: "Left" | "Center" | "Right" | "Justify";
    TextWrapping: "WrapWholeWords" | "NoWrap" | "Wrap";
    SelectionFlyout: undefined;
    PlaceholderText: string;
    AcceptsReturn: boolean;
    IsReadOnly: boolean;
    MaxLength: number;
    IsSpellCheckEnabled: boolean;
    IsTextPredictionEnabled: boolean;
    InputScope: string;
    CharacterCasing: "Normal" | "Lower" | "Upper";
    SelectionHighlightColor: string;
    DesiredCandidateWindowAlignment: "Default" | "BottomEdge";
    IsColorFontEnabled: boolean;
    PreventKeyboardDisplayOnProgrammaticFocus: boolean;
    ClipboardCopyFormat: "AllFormats" | "PlainText";
    DisabledFormattingAccelerators: string;
    HeaderPlacement: "Left" | "Top";
    HorizontalTextAlignment: "Left" | "Center" | "Right" | "Justify";
    ProofingMenuFlyout: undefined;
    SelectionHighlightColorWhenNotFocused: string;
    TextReadingOrder: "Default" | "DetectFromContent" | "UseFlowDirection";
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
