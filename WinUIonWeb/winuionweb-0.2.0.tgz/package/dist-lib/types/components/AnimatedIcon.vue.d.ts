import { type PropType } from 'vue';
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Source: {
        type: PropType<unknown>;
        default: unknown;
    };
    FallbackIconSource: {
        type: PropType<unknown>;
        default: unknown;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    MirroredWhenRightToLeft: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    IsHitTestVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
}>, {
    Source: import("vue").WritableComputedRef<unknown, unknown>;
    FallbackIconSource: import("vue").WritableComputedRef<unknown, unknown>;
    Foreground: import("vue").WritableComputedRef<unknown, unknown>;
    MirroredWhenRightToLeft: import("vue").WritableComputedRef<unknown, unknown>;
    Element: import("vue").ComputedRef<HTMLElement | null>;
    $el: import("vue").ComputedRef<HTMLElement | null>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:Source": (...args: any[]) => void;
    "update:FallbackIconSource": (...args: any[]) => void;
    "update:Foreground": (...args: any[]) => void;
    "update:MirroredWhenRightToLeft": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Source: {
        type: PropType<unknown>;
        default: unknown;
    };
    FallbackIconSource: {
        type: PropType<unknown>;
        default: unknown;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    MirroredWhenRightToLeft: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    IsHitTestVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
}>> & Readonly<{
    "onUpdate:Source"?: ((...args: any[]) => any) | undefined;
    "onUpdate:FallbackIconSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Foreground"?: ((...args: any[]) => any) | undefined;
    "onUpdate:MirroredWhenRightToLeft"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string;
    Opacity: string | number;
    Source: unknown;
    Visibility: string;
    IsHitTestVisible: string | boolean;
    FlowDirection: string;
    MirroredWhenRightToLeft: string | boolean;
    FallbackIconSource: unknown;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
