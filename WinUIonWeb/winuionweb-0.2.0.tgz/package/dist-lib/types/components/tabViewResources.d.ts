export declare const tabViewResources: Readonly<Record<string, string | number>>;
