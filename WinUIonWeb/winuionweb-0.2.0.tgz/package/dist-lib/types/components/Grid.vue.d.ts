import { type VNode } from 'vue';
import type { ThemeShadowValue } from './themeShadowRuntime';
export declare const GridContextFlyout: import("vue").DefineComponent<{}, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BackgroundSizing: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    ColumnDefinitions: {
        type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
        default: string;
    };
    RowDefinitions: {
        type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
        default: string;
    };
    ColumnSpacing: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    RowSpacing: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    Shadow: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    Translation: {
        type: (StringConstructor | ObjectConstructor)[];
        default: () => {
            X: number;
            Y: number;
            Z: number;
        };
    };
}>, {
    Element: import("vue").Ref<HTMLElement | null, HTMLElement | null>;
    Shadow: import("vue").WritableComputedRef<ThemeShadowValue | null | undefined, ThemeShadowValue | null | undefined>;
    Translation: import("vue").WritableComputedRef<string | number | {
        X?: number;
        Y?: number;
        Z?: number;
    }, string | number | {
        X?: number;
        Y?: number;
        Z?: number;
    }>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:Shadow": (...args: any[]) => void;
    "update:Translation": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BackgroundSizing: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    ColumnDefinitions: {
        type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
        default: string;
    };
    RowDefinitions: {
        type: (StringConstructor | ArrayConstructor | ObjectConstructor)[];
        default: string;
    };
    ColumnSpacing: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    RowSpacing: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    Shadow: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    Translation: {
        type: (StringConstructor | ObjectConstructor)[];
        default: () => {
            X: number;
            Y: number;
            Z: number;
        };
    };
}>> & Readonly<{
    "onUpdate:Shadow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Translation"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Background: string | Record<string, any>;
    BorderBrush: string;
    BorderThickness: string | number;
    CornerRadius: string | number;
    BackgroundSizing: string;
    Shadow: string | Record<string, any>;
    ColumnDefinitions: string | unknown[] | Record<string, any>;
    RowDefinitions: string | unknown[] | Record<string, any>;
    ColumnSpacing: string | number;
    RowSpacing: string | number;
    Visibility: string;
    Translation: string | Record<string, any>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
