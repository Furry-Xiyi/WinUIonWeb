import { type ComponentInternalInstance, type VNode } from 'vue';
type Scope = Record<string, unknown>;
export declare const xamlScopeKey: unique symbol;
export declare const xamlNameScopeKey: unique symbol;
export declare const xamlControlIdentityKey: unique symbol;
export declare const xamlItemContextKey: unique symbol;
export declare const eventNames: Set<string>;
export declare const cloneXamlVNodeWithDefaults: (node: VNode, defaults: Record<string, unknown>) => VNode;
/** Convert XAML's alpha-first 8-digit colors to the CSS rgba form. */
export declare const xamlColor: (value: unknown) => unknown;
export declare const resolveXamlValue: (value: unknown, instance: ComponentInternalInstance | null, extraScope?: Scope, preserveColor?: boolean) => unknown;
/**
 * Materialize an XAML DataTemplate against the current item.  Vue's compiler
 * keeps property-element children as VNodes, so the collection controls can
 * render the same tree for every item while resolving `{x:Bind Property}` in
 * the item's data context.
 */
export declare const materializeXamlVNode: (node: unknown, item: unknown, instance: ComponentInternalInstance | null) => unknown;
export declare const xamlTemplateComponent: (nodes: unknown[], item: unknown, instance: ComponentInternalInstance | null) => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>;
/** Write a control value back to the source of a XAML TwoWay binding. */
export declare const updateXamlBinding: (binding: unknown, value: unknown, instance: ComponentInternalInstance | null) => void;
export declare const resolveXamlHandler: (value: unknown, instance: ComponentInternalInstance | null, extraScope?: Scope) => Function | undefined;
export declare const normalizeXamlVNode: (node: VNode, instance: ComponentInternalInstance | null) => VNode;
/**
 * Resolve a bare XAML resource name against the owning page scope.  XAML lets a
 * `{StaticResource Key}` marker name an object that the code-behind provides
 * rather than one declared in `Page.Resources` — a DataTemplateSelector is the
 * common case.  `resolveXamlValue` cannot be used here because a bare identifier
 * is indistinguishable from a literal string, so look the name up directly.
 */
export declare const resolveXamlResourceObject: (name: unknown, instance: ComponentInternalInstance | null) => unknown;
export declare const normalizeXamlNodes: (nodes: VNode[], instance?: ComponentInternalInstance | null) => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>[];
export {};
