export declare const symbolGlyphs: Record<string, readonly [number, number]>;
export declare const resolveSymbolGlyph: (value: unknown) => string;
