import { type TextHighlighterValue } from './TextInline';
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    OverflowContentTarget: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    FontStyle: {
        type: StringConstructor;
        default: string;
    };
    FontWeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FontStretch: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    IsTextSelectionEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    SelectionHighlightColor: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    TextAlignment: {
        type: StringConstructor;
        default: string;
    };
    HorizontalTextAlignment: {
        type: StringConstructor;
        default: string;
    };
    CharacterSpacing: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    LineHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    LineStackingStrategy: {
        type: StringConstructor;
        default: string;
    };
    TextIndent: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    TextLineBounds: {
        type: StringConstructor;
        default: string;
    };
    OpticalMarginAlignment: {
        type: StringConstructor;
        default: string;
    };
    IsColorFontEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTextScaleFactorEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    TextReadingOrder: {
        type: StringConstructor;
        default: string;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
    TextDecorations: {
        type: StringConstructor;
        default: string;
    };
    SelectionFlyout: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    TextWrapping: {
        type: StringConstructor;
        default: string;
    };
    TextTrimming: {
        type: StringConstructor;
        default: string;
    };
    MaxLines: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
}>, {
    Element: import("vue").Ref<HTMLElement | null, HTMLElement | null>;
    TextHighlighters: {
        Add: (item: TextHighlighterValue) => number;
        Clear: () => {
            Background?: unknown;
            Foreground?: unknown;
            Ranges: {
                StartIndex: number;
                Length: number;
            }[];
        }[];
        Remove: (item: TextHighlighterValue) => void;
        RemoveAt: (index: number) => {
            Background?: unknown;
            Foreground?: unknown;
            Ranges: {
                StartIndex: number;
                Length: number;
            }[];
        }[];
        GetAt: (index: number) => {
            Background?: unknown;
            Foreground?: unknown;
            Ranges: {
                StartIndex: number;
                Length: number;
            }[];
        };
        readonly Count: number;
    };
    readonly HasOverflowContent: boolean;
    readonly IsTextTrimmed: boolean;
    readonly SelectedText: string;
    readonly ContentStart: {
        Offset: number;
    };
    readonly ContentEnd: {
        Offset: number;
    };
    SelectAll: () => void;
    Select: (start: {
        Offset: number;
    }, end: {
        Offset: number;
    }) => void;
    CopySelectionToClipboard: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    IsTextTrimmedChanged: (...args: any[]) => void;
    ContextMenuOpening: (...args: any[]) => void;
    SelectionChanged: (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    OverflowContentTarget: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    FontStyle: {
        type: StringConstructor;
        default: string;
    };
    FontWeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FontStretch: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    IsTextSelectionEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    SelectionHighlightColor: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    TextAlignment: {
        type: StringConstructor;
        default: string;
    };
    HorizontalTextAlignment: {
        type: StringConstructor;
        default: string;
    };
    CharacterSpacing: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    LineHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    LineStackingStrategy: {
        type: StringConstructor;
        default: string;
    };
    TextIndent: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    TextLineBounds: {
        type: StringConstructor;
        default: string;
    };
    OpticalMarginAlignment: {
        type: StringConstructor;
        default: string;
    };
    IsColorFontEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTextScaleFactorEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    TextReadingOrder: {
        type: StringConstructor;
        default: string;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
    TextDecorations: {
        type: StringConstructor;
        default: string;
    };
    SelectionFlyout: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    TextWrapping: {
        type: StringConstructor;
        default: string;
    };
    TextTrimming: {
        type: StringConstructor;
        default: string;
    };
    MaxLines: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
}>> & Readonly<{
    onIsTextTrimmedChanged?: ((...args: any[]) => any) | undefined;
    onContextMenuOpening?: ((...args: any[]) => any) | undefined;
    onSelectionChanged?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string | Record<string, any>;
    Opacity: string | number;
    FontSize: string | number;
    FontFamily: string;
    FontWeight: string | number;
    Visibility: string;
    CharacterSpacing: string | number;
    FontStretch: string;
    FontStyle: string;
    TextDecorations: string;
    FlowDirection: string;
    IsTextScaleFactorEnabled: string | boolean;
    TextIndent: string | number;
    TextAlignment: string;
    LineHeight: string | number;
    LineStackingStrategy: string;
    TextWrapping: string;
    SelectionFlyout: string | Record<string, any>;
    SelectionHighlightColor: string | Record<string, any>;
    IsColorFontEnabled: string | boolean;
    HorizontalTextAlignment: string;
    TextReadingOrder: string;
    TextLineBounds: string;
    TextTrimming: string;
    OverflowContentTarget: string | Record<string, any>;
    MaxLines: string | number;
    IsTextSelectionEnabled: string | boolean;
    OpticalMarginAlignment: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
