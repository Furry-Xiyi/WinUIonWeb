import { type PropType } from 'vue';
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Content: {
        type: PropType<unknown>;
        default: unknown;
    };
    ContentTemplate: {
        type: PropType<unknown>;
        default: unknown;
    };
    ContentTransitions: {
        type: PropType<unknown>;
        default: unknown;
    };
    Foreground: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Content: {
        type: PropType<unknown>;
        default: unknown;
    };
    ContentTemplate: {
        type: PropType<unknown>;
        default: unknown;
    };
    ContentTransitions: {
        type: PropType<unknown>;
        default: unknown;
    };
    Foreground: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{}>, {
    Foreground: string | Record<string, any>;
    HorizontalContentAlignment: string;
    VerticalContentAlignment: string;
    ContentTemplate: unknown;
    Content: unknown;
    ContentTransitions: unknown;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
