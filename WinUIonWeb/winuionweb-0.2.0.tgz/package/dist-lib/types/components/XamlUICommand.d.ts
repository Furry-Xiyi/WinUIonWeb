export interface KeyboardAccelerator {
    Key: string;
    Modifiers?: string;
    IsEnabled?: boolean;
}
export interface CommandIconSource {
    Symbol?: string;
    Glyph?: string;
    UriSource?: string;
    [property: string]: unknown;
}
export interface UICommand {
    CanExecute?: (parameter?: unknown) => boolean;
    Execute: (parameter?: unknown) => void;
}
export interface ExecuteRequestedEventArgs {
    Parameter: unknown;
}
export interface CanExecuteRequestedEventArgs extends ExecuteRequestedEventArgs {
    CanExecute: boolean;
}
export interface CommandPropertyChangedEventArgs {
    PropertyName: string;
    OldValue: unknown;
    NewValue: unknown;
}
export type CommandHandler = (sender: XamlUICommand, args: ExecuteRequestedEventArgs) => void;
export type CanExecuteHandler = (sender: XamlUICommand, args: CanExecuteRequestedEventArgs) => void;
export type CanExecuteChangedHandler = (sender: XamlUICommand, args: null) => void;
export type CommandPropertyChangedHandler = (sender: XamlUICommand, args: CommandPropertyChangedEventArgs) => void;
export interface CommandEventMap {
    ExecuteRequested: CommandHandler;
    CanExecuteRequested: CanExecuteHandler;
    CanExecuteChanged: CanExecuteChangedHandler;
    PropertyChanged: CommandPropertyChangedHandler;
}
export interface XamlUICommandOptions {
    AccessKey?: string;
    Command?: UICommand | null;
    Description?: string;
    IconSource?: CommandIconSource | null;
    KeyboardAccelerators?: KeyboardAccelerator[];
    Label?: string;
    ExecuteRequested?: CommandHandler;
    CanExecuteRequested?: CanExecuteHandler;
    CanExecuteChanged?: CanExecuteChangedHandler;
    PropertyChanged?: CommandPropertyChangedHandler;
}
type CommandEventName = keyof CommandEventMap;
/** Metadata and ICommand behavior for Microsoft.UI.Xaml.Input.XamlUICommand. */
export declare class XamlUICommand implements UICommand {
    private accessKey;
    private command;
    private description;
    private iconSource;
    private label;
    private readonly accelerators;
    private readonly observedAccelerators;
    private readonly observedIcons;
    private readonly eventListeners;
    ExecuteRequested?: CommandHandler;
    CanExecuteRequested?: CanExecuteHandler;
    CanExecuteChanged?: CanExecuteChangedHandler;
    PropertyChanged?: CommandPropertyChangedHandler;
    constructor(options?: XamlUICommandOptions);
    get AccessKey(): string;
    set AccessKey(value: string);
    get Command(): UICommand | null;
    set Command(value: UICommand | null);
    get Description(): string;
    set Description(value: string);
    get IconSource(): CommandIconSource | null;
    set IconSource(value: CommandIconSource | null);
    get KeyboardAccelerators(): KeyboardAccelerator[];
    get Label(): string;
    set Label(value: string);
    addEventListener<K extends CommandEventName>(name: K, handler: CommandEventMap[K]): void;
    removeEventListener<K extends CommandEventName>(name: K, handler: CommandEventMap[K]): void;
    CanExecute(parameter?: unknown): boolean;
    Execute(parameter?: unknown): void;
    NotifyCanExecuteChanged(): void;
    MatchesKeyboardEvent(event: KeyboardEvent): boolean;
    AttachKeyboardAccelerators(target?: Window | HTMLElement, parameter?: unknown): () => void;
    protected OnPropertySet(_property: string): void;
    protected NotifyPropertyChanged(PropertyName: string, OldValue: unknown, NewValue: unknown): void;
    private SetProperty;
    private RaiseEvent;
    private ObserveAccelerator;
    private ObserveIcon;
}
export default XamlUICommand;
