declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Fill: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Stroke: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    StrokeThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Stretch: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    RadiusX: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    RadiusY: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
}>, {
    Fill: import("vue").WritableComputedRef<unknown, unknown>;
    Stroke: import("vue").WritableComputedRef<unknown, unknown>;
    Element: import("vue").Ref<HTMLElement | null, HTMLElement | null>;
    ActualSize: import("vue").Ref<{
        X: number;
        Y: number;
    }, {
        X: number;
        Y: number;
    } | {
        X: number;
        Y: number;
    }>;
    ActualWidth: import("vue").ComputedRef<number>;
    ActualHeight: import("vue").ComputedRef<number>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:Fill": (...args: any[]) => void;
    "update:Stroke": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Fill: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Stroke: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    StrokeThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Stretch: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    RadiusX: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    RadiusY: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
}>> & Readonly<{
    "onUpdate:Fill"?: ((...args: any[]) => any) | undefined;
    "onUpdate:Stroke"?: ((...args: any[]) => any) | undefined;
}>, {
    Stretch: string;
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Fill: string | Record<string, any>;
    Stroke: string | Record<string, any>;
    RadiusX: string | number;
    RadiusY: string | number;
    StrokeThickness: string | number;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
