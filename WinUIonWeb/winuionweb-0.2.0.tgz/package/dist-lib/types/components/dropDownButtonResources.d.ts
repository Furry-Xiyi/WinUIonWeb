export declare const dropDownButtonThemeResourceAliases: {
    readonly Default: {
        readonly DropDownButtonForegroundSecondary: "TextFillColorSecondaryBrush";
        readonly DropDownButtonForegroundSecondaryPointerOver: "TextFillColorTertiaryBrush";
        readonly DropDownButtonForegroundSecondaryPressed: "TextFillColorTertiaryBrush";
    };
    readonly Light: {
        readonly DropDownButtonForegroundSecondary: "TextFillColorSecondaryBrush";
        readonly DropDownButtonForegroundSecondaryPointerOver: "TextFillColorTertiaryBrush";
        readonly DropDownButtonForegroundSecondaryPressed: "TextFillColorTertiaryBrush";
    };
    readonly HighContrast: {
        readonly DropDownButtonForegroundSecondary: "SystemColorButtonTextColorBrush";
        readonly DropDownButtonForegroundSecondaryPointerOver: "SystemColorHighlightColorBrush";
        readonly DropDownButtonForegroundSecondaryPressed: "SystemColorHighlightColorBrush";
    };
};
export declare const dropDownButtonResources: Record<string, unknown>;
