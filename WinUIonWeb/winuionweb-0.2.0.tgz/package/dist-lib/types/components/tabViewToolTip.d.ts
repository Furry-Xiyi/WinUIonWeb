import { type PropType } from 'vue';
/** ToolTipService.SetToolTip for native hosts in TabView's control template. */
export declare const TabViewTemplateToolTip: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Owner: {
        type: PropType<HTMLElement | null>;
        default: null;
    };
    Content: {
        type: StringConstructor;
        default: string;
    };
    Placement: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Owner: {
        type: PropType<HTMLElement | null>;
        default: null;
    };
    Content: {
        type: StringConstructor;
        default: string;
    };
    Placement: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{}>, {
    IsEnabled: boolean;
    Content: string;
    Placement: string;
    Owner: HTMLElement | null;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
