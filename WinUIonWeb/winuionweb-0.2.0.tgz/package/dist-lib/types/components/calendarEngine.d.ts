export declare const calendarDayMilliseconds = 86400000;
export declare const calendarDateSerial: (date: Date) => number;
export declare const calendarDateFromSerial: (serial: number) => Date;
export declare const parseCalendarDate: (value: unknown) => Date | null;
export interface CalendarMonth {
    index: number;
    start: number;
    end: number;
    year: number;
    yearIndex: number;
    month: string;
    text: string;
    label: string;
}
export interface CalendarYear {
    index: number;
    start: number;
    end: number;
    number: number;
    firstMonth: number;
    lastMonth: number;
    text: string;
}
/** Calendar boundaries come from the browser's ICU calendar implementation. */
export declare const createCalendarModel: (identifier: string, language: string, minimum: number, maximum: number) => {
    identifier: string;
    language: string;
    minimum: number;
    maximum: number;
    months: CalendarMonth[];
    years: CalendarYear[];
    monthAt: (serial: number) => CalendarMonth;
    yearAt: (serial: number) => CalendarYear;
    dayNumber: (serial: number) => string;
    day: (serial: number) => number;
    headerText: (serial: number) => string;
    yearText: (serial: number) => string;
    monthText: (serial: number) => string;
    formatSelectedDate: (serial: number, options: Intl.DateTimeFormatOptions) => string;
    fullDateText: (serial: number) => string;
    weekdayText: (serial: number, format: string) => string;
    displayYear: (year: CalendarYear) => number;
    formatNumber: (number: number) => string;
};
export type CalendarModel = ReturnType<typeof createCalendarModel>;
