import { type VNode } from 'vue';
export declare const layoutResourceChildren: (nodes: VNode[], marker: string) => VNode[];
