import { type PropType, type VNode } from 'vue';
export declare const ButtonFlyout: import("vue").DefineComponent<{}, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const ButtonContent: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const ButtonKeyboardAccelerators: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Style: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    Content: {
        type: PropType<unknown>;
        default: unknown;
    };
    ContentTemplate: {
        type: PropType<unknown>;
        default: unknown;
    };
    ContentTransitions: {
        type: PropType<unknown>;
        default: unknown;
    };
    ClickMode: {
        type: StringConstructor;
        default: string;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Command: {
        type: (StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    CommandParameter: {
        type: PropType<unknown>;
        default: unknown;
    };
    Flyout: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BackgroundSizing: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: StringConstructor;
        default: string;
    };
    Margin: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontWeight: {
        type: StringConstructor;
        default: string;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    UseSystemFocusVisuals: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FocusVisualMargin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
}>, {
    Element: HTMLElement | null;
    Flyout: unknown;
    IsEnabled: boolean;
    RequestedTheme: string;
    Name: {};
    Content: {} | null;
    ContentTemplate: any;
    ContentTransitions: any;
    Command: import("./uiCommandRuntime").UICommandMetadata | undefined;
    CommandParameter: unknown;
    IsPressed: boolean;
    IsPointerOver: boolean;
    Focus: () => boolean;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Click: (...args: any[]) => void;
    KeyDown: (...args: any[]) => void;
    GotFocus: (...args: any[]) => void;
    LostFocus: (...args: any[]) => void;
    PointerMoved: (...args: any[]) => void;
    PointerPressed: (...args: any[]) => void;
    PointerReleased: (...args: any[]) => void;
    PointerEntered: (...args: any[]) => void;
    PointerExited: (...args: any[]) => void;
    PointerCanceled: (...args: any[]) => void;
    PointerCaptureLost: (...args: any[]) => void;
    KeyUp: (...args: any[]) => void;
    ContextRequested: (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Style: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    Content: {
        type: PropType<unknown>;
        default: unknown;
    };
    ContentTemplate: {
        type: PropType<unknown>;
        default: unknown;
    };
    ContentTransitions: {
        type: PropType<unknown>;
        default: unknown;
    };
    ClickMode: {
        type: StringConstructor;
        default: string;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Command: {
        type: (StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    CommandParameter: {
        type: PropType<unknown>;
        default: unknown;
    };
    Flyout: {
        type: PropType<unknown>;
        default: unknown;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    BackgroundSizing: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Padding: {
        type: StringConstructor;
        default: string;
    };
    Margin: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    HorizontalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalContentAlignment: {
        type: StringConstructor;
        default: string;
    };
    FontFamily: {
        type: StringConstructor;
        default: string;
    };
    FontWeight: {
        type: StringConstructor;
        default: string;
    };
    FontSize: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    UseSystemFocusVisuals: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FocusVisualMargin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
}>> & Readonly<{
    onClick?: ((...args: any[]) => any) | undefined;
    onKeyDown?: ((...args: any[]) => any) | undefined;
    onGotFocus?: ((...args: any[]) => any) | undefined;
    onLostFocus?: ((...args: any[]) => any) | undefined;
    onPointerMoved?: ((...args: any[]) => any) | undefined;
    onPointerPressed?: ((...args: any[]) => any) | undefined;
    onPointerReleased?: ((...args: any[]) => any) | undefined;
    onPointerEntered?: ((...args: any[]) => any) | undefined;
    onPointerExited?: ((...args: any[]) => any) | undefined;
    onPointerCanceled?: ((...args: any[]) => any) | undefined;
    onPointerCaptureLost?: ((...args: any[]) => any) | undefined;
    onKeyUp?: ((...args: any[]) => any) | undefined;
    onContextRequested?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string;
    Padding: string;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string;
    Command: string | Record<string, any>;
    IsEnabled: string | boolean;
    Background: string | Record<string, any>;
    BorderBrush: string;
    BorderThickness: string | number;
    CornerRadius: string | number;
    FontSize: string | number;
    HorizontalContentAlignment: string;
    VerticalContentAlignment: string;
    UseSystemFocusVisuals: string | boolean;
    IsTabStop: string | boolean;
    BackgroundSizing: string;
    FocusVisualMargin: string | number;
    FontFamily: string;
    FontWeight: string;
    RequestedTheme: string;
    Flyout: unknown;
    ContentTemplate: unknown;
    Style: string;
    Visibility: string;
    Content: unknown;
    ContentTransitions: unknown;
    CommandParameter: unknown;
    ClickMode: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
