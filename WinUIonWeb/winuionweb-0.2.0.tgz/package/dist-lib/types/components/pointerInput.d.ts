export declare const isHoverPointer: (event: PointerEvent) => boolean;
export declare const installPointerInput: () => void;
