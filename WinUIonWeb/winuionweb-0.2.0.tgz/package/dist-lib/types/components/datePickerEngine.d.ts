export declare const createDatePickerModel: (identifier: string, language: string, minYear: Date, maxYear: Date) => {
    calendar: {
        identifier: string;
        language: string;
        minimum: number;
        maximum: number;
        months: import("./calendarEngine").CalendarMonth[];
        years: import("./calendarEngine").CalendarYear[];
        monthAt: (serial: number) => import("./calendarEngine").CalendarMonth;
        yearAt: (serial: number) => import("./calendarEngine").CalendarYear;
        dayNumber: (serial: number) => string;
        day: (serial: number) => number;
        headerText: (serial: number) => string;
        yearText: (serial: number) => string;
        monthText: (serial: number) => string;
        formatSelectedDate: (serial: number, options: Intl.DateTimeFormatOptions) => string;
        fullDateText: (serial: number) => string;
        weekdayText: (serial: number, format: string) => string;
        displayYear: (year: import("./calendarEngine").CalendarYear) => number;
        formatNumber: (number: number) => string;
    };
    minimum: number;
    maximum: number;
    years: import("./calendarEngine").CalendarYear[];
    coerce: (input: unknown) => Date | null;
    format: (serial: number, pattern: string, field: "day" | "month" | "year") => string;
    order: ("month" | "day" | "year")[];
};
