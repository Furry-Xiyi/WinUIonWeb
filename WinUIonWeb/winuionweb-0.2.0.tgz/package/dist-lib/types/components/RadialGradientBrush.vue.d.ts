export interface GradientPoint {
    X: number;
    Y: number;
}
export interface GradientStopValue {
    Color: string;
    Offset: number;
}
type VectorChangedArgs = {
    CollectionChange: 'Reset' | 'ItemInserted' | 'ItemRemoved' | 'ItemChanged';
    Index: number;
};
type VectorChangedHandler = (sender: GradientStopCollection, args: VectorChangedArgs) => void;
export declare const gradientPoint: (value: unknown, fallback?: GradientPoint) => GradientPoint;
export declare const createGradientStop: (values?: Partial<GradientStopValue>) => GradientStopValue;
export declare class GradientStopCollection implements Iterable<GradientStopValue> {
    #private;
    constructor();
    get Size(): number;
    get Count(): number;
    GetAt(index: number): {
        Color: string;
        Offset: number;
    };
    SetAt(index: number, value: GradientStopValue): void;
    InsertAt(index: number, value: GradientStopValue): void;
    Append(value: GradientStopValue): void;
    RemoveAt(index: number): void;
    RemoveAtEnd(): void;
    Clear(): void;
    ReplaceAll(values: Iterable<GradientStopValue>): void;
    IndexOf(value: GradientStopValue): {
        found: boolean;
        index: number;
    };
    GetView(): ReadonlyArray<GradientStopValue>;
    VectorChanged(handler: VectorChangedHandler): () => boolean;
    [Symbol.iterator](): ArrayIterator<{
        Color: string;
        Offset: number;
    }>;
}
export interface RadialGradientBrushValue {
    readonly __radialGradient: true;
    Center: GradientPoint;
    GradientOrigin: GradientPoint;
    RadiusX: number;
    RadiusY: number;
    MappingMode: 'RelativeToBoundingBox' | 'Absolute';
    SpreadMethod: 'Pad' | 'Reflect' | 'Repeat';
    InterpolationSpace: string;
    Opacity: number;
    FallbackColor: string;
    readonly GradientStops: GradientStopCollection;
}
export declare const createRadialGradientBrush: () => RadialGradientBrushValue;
export declare const GradientStop: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Color: {
        type: StringConstructor;
        default: string;
    };
    Offset: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
}>, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Color: {
        type: StringConstructor;
        default: string;
    };
    Offset: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
}>> & Readonly<{}>, {
    Color: string;
    Offset: string | number;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const RadialGradientStops: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Center: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    GradientOrigin: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    RadiusX: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    RadiusY: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MappingMode: {
        type: StringConstructor;
        default: string;
    };
    SpreadMethod: {
        type: StringConstructor;
        default: string;
    };
    InterpolationSpace: {
        type: StringConstructor;
        default: string;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    FallbackColor: {
        type: StringConstructor;
        default: string;
    };
}>, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Center: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    GradientOrigin: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    RadiusX: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    RadiusY: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MappingMode: {
        type: StringConstructor;
        default: string;
    };
    SpreadMethod: {
        type: StringConstructor;
        default: string;
    };
    InterpolationSpace: {
        type: StringConstructor;
        default: string;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    FallbackColor: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{}>, {
    Center: string | Record<string, any>;
    FallbackColor: string;
    Opacity: string | number;
    GradientOrigin: string | Record<string, any>;
    RadiusX: string | number;
    RadiusY: string | number;
    MappingMode: string;
    SpreadMethod: string;
    InterpolationSpace: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
