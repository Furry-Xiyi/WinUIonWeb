import { type InjectionKey, type PropType, type VNode } from 'vue';
export type IconSourceKind = 'FontIcon' | 'SymbolIcon' | 'BitmapIcon' | 'PathIcon' | 'ImageIcon';
export type IconSourceModel = Record<string, unknown> & {
    readonly __iconSourceKind: IconSourceKind;
    Foreground: unknown;
    CreateIconElement: () => VNode | null;
};
export declare const iconSourceContextKey: InjectionKey<(source: IconSourceModel | null) => void>;
export declare const IconSourceProperty: import("vue").DefineComponent<{}, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const ImageIconSourceProperty: import("vue").DefineComponent<{}, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const iconSourceKind: (node: VNode) => IconSourceKind | undefined;
export declare const iconSourceObjectKind: (source: Record<string, unknown>) => IconSourceKind | undefined;
/** IconSource properties map to the corresponding IconElement dependency properties. */
export declare const createIconSourceElementVNode: (source: Record<string, unknown>) => VNode | null;
export declare const createIconSourceModel: (kind: IconSourceKind) => IconSourceModel;
export declare const FontIconSource: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    [k: string]: {
        type: PropType<unknown>;
        default: unknown;
    };
}>, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    [k: string]: {
        type: PropType<unknown>;
        default: unknown;
    };
}>> & Readonly<{}>, {
    [x: string]: unknown;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const SymbolIconSource: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    [k: string]: {
        type: PropType<unknown>;
        default: unknown;
    };
}>, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    [k: string]: {
        type: PropType<unknown>;
        default: unknown;
    };
}>> & Readonly<{}>, {
    [x: string]: unknown;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const BitmapIconSource: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    [k: string]: {
        type: PropType<unknown>;
        default: unknown;
    };
}>, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    [k: string]: {
        type: PropType<unknown>;
        default: unknown;
    };
}>> & Readonly<{}>, {
    [x: string]: unknown;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const PathIconSource: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    [k: string]: {
        type: PropType<unknown>;
        default: unknown;
    };
}>, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    [k: string]: {
        type: PropType<unknown>;
        default: unknown;
    };
}>> & Readonly<{}>, {
    [x: string]: unknown;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const ImageIconSource: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    [k: string]: {
        type: PropType<unknown>;
        default: unknown;
    };
}>, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    [k: string]: {
        type: PropType<unknown>;
        default: unknown;
    };
}>> & Readonly<{}>, {
    [x: string]: unknown;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
