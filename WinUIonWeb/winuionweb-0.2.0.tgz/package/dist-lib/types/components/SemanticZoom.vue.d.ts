import type { ViewChangedArgs, Request, SemanticView } from './semanticZoomTypes';
export declare const SemanticZoomZoomedInView: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const SemanticZoomZoomedOutView: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    ZoomedInView: {
        type: ObjectConstructor;
        default: null;
    };
    ZoomedOutView: {
        type: ObjectConstructor;
        default: null;
    };
    IsZoomedInViewActive: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    CanChangeViews: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsZoomOutButtonEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    TabNavigation: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    'ScrollViewer.HorizontalScrollMode': {
        type: StringConstructor;
        default: string;
    };
    'ScrollViewer.VerticalScrollMode': {
        type: StringConstructor;
        default: string;
    };
    'ScrollViewer.IsHorizontalRailEnabled': {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    'ScrollViewer.IsVerticalRailEnabled': {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    'ScrollViewer.ZoomMode': {
        type: StringConstructor;
        default: string;
    };
}>, {
    ToggleActiveView: (request?: Request) => boolean;
    StartBringIntoView: () => void | undefined;
    IsZoomedInViewActive: import("vue").WritableComputedRef<boolean, boolean>;
    ZoomedInView: import("vue").ComputedRef<SemanticView | undefined>;
    ZoomedOutView: import("vue").ComputedRef<SemanticView | undefined>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    ViewChangeStarted: (args_0: unknown, args_1: ViewChangedArgs) => any;
    ViewChangeCompleted: (args_0: unknown, args_1: ViewChangedArgs) => any;
    "update:IsZoomedInViewActive": (args_0: boolean) => any;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    ZoomedInView: {
        type: ObjectConstructor;
        default: null;
    };
    ZoomedOutView: {
        type: ObjectConstructor;
        default: null;
    };
    IsZoomedInViewActive: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    CanChangeViews: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsZoomOutButtonEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsTabStop: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    TabNavigation: {
        type: StringConstructor;
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    'ScrollViewer.HorizontalScrollMode': {
        type: StringConstructor;
        default: string;
    };
    'ScrollViewer.VerticalScrollMode': {
        type: StringConstructor;
        default: string;
    };
    'ScrollViewer.IsHorizontalRailEnabled': {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    'ScrollViewer.IsVerticalRailEnabled': {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    'ScrollViewer.ZoomMode': {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onViewChangeStarted?: ((args_0: unknown, args_1: ViewChangedArgs) => any) | undefined;
    onViewChangeCompleted?: ((args_0: unknown, args_1: ViewChangedArgs) => any) | undefined;
    "onUpdate:IsZoomedInViewActive"?: ((args_0: boolean) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    IsEnabled: string | boolean;
    Background: string;
    BorderBrush: string;
    BorderThickness: string | number;
    'ScrollViewer.HorizontalScrollMode': string;
    'ScrollViewer.VerticalScrollMode': string;
    'ScrollViewer.IsHorizontalRailEnabled': string | boolean;
    'ScrollViewer.IsVerticalRailEnabled': string | boolean;
    'ScrollViewer.ZoomMode': string;
    IsTabStop: string | boolean;
    TabNavigation: string;
    ZoomedInView: Record<string, any>;
    ZoomedOutView: Record<string, any>;
    IsZoomedInViewActive: string | boolean;
    CanChangeViews: string | boolean;
    IsZoomOutButtonEnabled: string | boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
