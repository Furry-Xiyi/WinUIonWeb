export declare const MediaPlayerTransportControlsProperty: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Source: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    AreTransportControlsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    PosterSource: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Stretch: {
        type: StringConstructor;
        default: string;
    };
    AutoPlay: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    RenderTransform: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    RenderTransformOrigin: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    IsFullWindow: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    TransportControls: {
        type: ObjectConstructor;
        default: null;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
}>, {
    MediaPlayer: import("vue").Ref<HTMLVideoElement | null, HTMLVideoElement | null>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Loaded: (...args: any[]) => void;
    "update:IsFullWindow": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Source: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    AreTransportControlsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    PosterSource: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Stretch: {
        type: StringConstructor;
        default: string;
    };
    AutoPlay: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    RenderTransform: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    RenderTransformOrigin: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    IsFullWindow: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    TransportControls: {
        type: ObjectConstructor;
        default: null;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onLoaded?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsFullWindow"?: ((...args: any[]) => any) | undefined;
}>, {
    Stretch: string;
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    IsEnabled: string | boolean;
    Source: string | Record<string, any>;
    Visibility: string;
    AutoPlay: string | boolean;
    AreTransportControlsEnabled: string | boolean;
    PosterSource: string | Record<string, any>;
    RenderTransform: string | Record<string, any>;
    RenderTransformOrigin: string | Record<string, any>;
    IsFullWindow: string | boolean;
    TransportControls: Record<string, any>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
