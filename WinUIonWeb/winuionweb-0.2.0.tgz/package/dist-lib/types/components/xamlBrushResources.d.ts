import { type ComponentInternalInstance, type VNode } from 'vue';
type ResourceValues = Record<string, unknown>;
export declare const xamlResourceKey: (node: VNode) => string;
export declare const xamlResourceNodesEqual: (left: VNode | undefined, right: VNode | undefined) => boolean;
export declare const collectXamlResources: (nodes: VNode[], dictionary: Record<string, VNode>, theme?: string) => void;
export declare const useXamlBrushResources: (instance: ComponentInternalInstance | null, names?: ResourceValues) => {
    sync: (declarations: Record<string, VNode>) => void;
};
export {};
