import { type SystemBackdropState } from './systemBackdropHostAdapter';
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    SystemBackdrop: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    IsHitTestVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
}>, {
    SystemBackdrop: import("vue").WritableComputedRef<unknown, unknown>;
    CornerRadius: import("vue").WritableComputedRef<unknown, unknown>;
    Element: import("vue").Ref<HTMLElement | null, HTMLElement | null>;
    State: import("vue").ShallowRef<SystemBackdropState | null, SystemBackdropState | null>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:CornerRadius": (...args: any[]) => void;
    "update:SystemBackdrop": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    SystemBackdrop: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
    Opacity: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    IsHitTestVisible: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
}>> & Readonly<{
    "onUpdate:CornerRadius"?: ((...args: any[]) => any) | undefined;
    "onUpdate:SystemBackdrop"?: ((...args: any[]) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Opacity: string | number;
    SystemBackdrop: string | Record<string, any>;
    CornerRadius: string | number;
    RequestedTheme: string;
    Visibility: string;
    IsHitTestVisible: string | boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
