import { type ContentDialogPlacement, type ContentDialogResult } from './contentDialogRuntime';
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Title: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Content: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: string;
    };
    TitleTemplate: {
        type: (StringConstructor | ObjectConstructor | FunctionConstructor)[];
        default: undefined;
    };
    ContentTemplate: {
        type: (StringConstructor | ObjectConstructor | FunctionConstructor)[];
        default: undefined;
    };
    PrimaryButtonText: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    SecondaryButtonText: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CloseButtonText: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    PrimaryButtonStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    SecondaryButtonStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    CloseButtonStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    PrimaryButtonCommand: {
        type: (StringConstructor | ObjectConstructor | FunctionConstructor)[];
        default: undefined;
    };
    SecondaryButtonCommand: {
        type: (StringConstructor | ObjectConstructor | FunctionConstructor)[];
        default: undefined;
    };
    CloseButtonCommand: {
        type: (StringConstructor | ObjectConstructor | FunctionConstructor)[];
        default: undefined;
    };
    PrimaryButtonCommandParameter: {
        type: null;
        default: undefined;
    };
    SecondaryButtonCommandParameter: {
        type: null;
        default: undefined;
    };
    CloseButtonCommandParameter: {
        type: null;
        default: undefined;
    };
    DefaultButton: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsPrimaryButtonEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsSecondaryButtonEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FullSizeDesired: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    XamlRoot: {
        type: (StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    Style: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
}>, {
    ShowAsync: (value?: ContentDialogPlacement) => Promise<ContentDialogResult>;
    Hide: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Opened: (...args: any[]) => void;
    Closing: (...args: any[]) => void;
    Closed: (...args: any[]) => void;
    Loaded: (...args: any[]) => void;
    PrimaryButtonClick: (...args: any[]) => void;
    SecondaryButtonClick: (...args: any[]) => void;
    CloseButtonClick: (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Title: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Content: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: string;
    };
    TitleTemplate: {
        type: (StringConstructor | ObjectConstructor | FunctionConstructor)[];
        default: undefined;
    };
    ContentTemplate: {
        type: (StringConstructor | ObjectConstructor | FunctionConstructor)[];
        default: undefined;
    };
    PrimaryButtonText: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    SecondaryButtonText: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CloseButtonText: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    PrimaryButtonStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    SecondaryButtonStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    CloseButtonStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    PrimaryButtonCommand: {
        type: (StringConstructor | ObjectConstructor | FunctionConstructor)[];
        default: undefined;
    };
    SecondaryButtonCommand: {
        type: (StringConstructor | ObjectConstructor | FunctionConstructor)[];
        default: undefined;
    };
    CloseButtonCommand: {
        type: (StringConstructor | ObjectConstructor | FunctionConstructor)[];
        default: undefined;
    };
    PrimaryButtonCommandParameter: {
        type: null;
        default: undefined;
    };
    SecondaryButtonCommandParameter: {
        type: null;
        default: undefined;
    };
    CloseButtonCommandParameter: {
        type: null;
        default: undefined;
    };
    DefaultButton: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsPrimaryButtonEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsSecondaryButtonEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    FullSizeDesired: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    XamlRoot: {
        type: (StringConstructor | ObjectConstructor)[];
        default: undefined;
    };
    Style: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    FlowDirection: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onOpened?: ((...args: any[]) => any) | undefined;
    onClosing?: ((...args: any[]) => any) | undefined;
    onClosed?: ((...args: any[]) => any) | undefined;
    onLoaded?: ((...args: any[]) => any) | undefined;
    onPrimaryButtonClick?: ((...args: any[]) => any) | undefined;
    onSecondaryButtonClick?: ((...args: any[]) => any) | undefined;
    onCloseButtonClick?: ((...args: any[]) => any) | undefined;
}>, {
    Foreground: string;
    IsEnabled: string | boolean;
    Background: string;
    BorderBrush: string;
    BorderThickness: string | number;
    CornerRadius: string | number;
    RequestedTheme: string;
    ContentTemplate: string | Function | Record<string, any>;
    Style: string | Record<string, any>;
    CloseButtonStyle: string | Record<string, any>;
    TitleTemplate: string | Function | Record<string, any>;
    Content: string | number | Record<string, any>;
    FlowDirection: string;
    Title: string | number | Record<string, any>;
    PrimaryButtonText: string | number;
    SecondaryButtonText: string | number;
    CloseButtonText: string | number;
    PrimaryButtonStyle: string | Record<string, any>;
    SecondaryButtonStyle: string | Record<string, any>;
    PrimaryButtonCommand: string | Function | Record<string, any>;
    SecondaryButtonCommand: string | Function | Record<string, any>;
    CloseButtonCommand: string | Function | Record<string, any>;
    PrimaryButtonCommandParameter: any;
    SecondaryButtonCommandParameter: any;
    CloseButtonCommandParameter: any;
    DefaultButton: string;
    IsPrimaryButtonEnabled: string | boolean;
    IsSecondaryButtonEnabled: string | boolean;
    FullSizeDesired: string | boolean;
    XamlRoot: string | Record<string, any>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
