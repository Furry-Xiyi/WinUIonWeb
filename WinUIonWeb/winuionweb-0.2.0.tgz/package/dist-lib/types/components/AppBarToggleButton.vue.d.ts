export declare const AppBarToggleButtonIcon: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const AppBarToggleButtonContent: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const AppBarToggleButtonKeyboardAccelerators: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    IsChecked: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsThreeState: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
}>, Record<PropertyKey, any>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Click: (...args: any[]) => void;
    Checked: (...args: any[]) => void;
    Unchecked: (...args: any[]) => void;
    Indeterminate: (...args: any[]) => void;
    "update:IsChecked": (...args: any[]) => void;
    "update:IsThreeState": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    IsChecked: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsThreeState: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
}>> & Readonly<{
    onClick?: ((...args: any[]) => any) | undefined;
    onChecked?: ((...args: any[]) => any) | undefined;
    onUnchecked?: ((...args: any[]) => any) | undefined;
    onIndeterminate?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsChecked"?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsThreeState"?: ((...args: any[]) => any) | undefined;
}>, {
    IsChecked: string | boolean;
    IsThreeState: string | boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
