export type ContentDialogResult = 'None' | 'Primary' | 'Secondary';
export type ContentDialogPlacement = 'Popup' | 'InPlace' | 'UnconstrainedPopup';
export declare const acquireContentDialog: (root: object, owner: object, parent?: object | null, element?: object) => () => void;
export declare const createContentDialogEventArgs: (result?: ContentDialogResult) => {
    args: {
        GetDeferral(): {
            Complete(): void;
        };
        Result?: ContentDialogResult | undefined;
        Cancel: boolean;
    };
    completed: Promise<void>;
    finishDispatch(): void;
    disconnect(): void;
};
export declare const contentDialogFocusableElements: (root: HTMLElement | null) => HTMLElement[];
