/**
 * Keeps a secondary touch scrolling while the primary touch is captured by a
 * drag interaction. `touch-action: none` is needed for the drag pointer, so
 * native touch panning is unavailable on the same surface during that drag.
 */
export declare const attachSecondaryTouchScrollDuringDrag: (isDragging: () => boolean, getDragPointerId: () => number | null | undefined) => () => void;
