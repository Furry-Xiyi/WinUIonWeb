export declare const appBarResources: Readonly<Record<string, string | number>>;
