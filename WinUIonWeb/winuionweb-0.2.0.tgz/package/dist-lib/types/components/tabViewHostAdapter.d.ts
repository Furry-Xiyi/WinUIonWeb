/** Host integration for native TabView windowing events, without a framework runtime. */
export declare const tabViewHostAdapterKey: unique symbol;
export type TabViewWindowId = string | number;
export type TabViewSplitEdge = 'Left' | 'Right' | 'Top' | 'Bottom';
export type TabViewHostCancellationReason = 'HostUnavailable' | 'Cancelled' | 'Disposed' | 'Busy' | 'InvalidItems' | 'InvalidTarget' | 'SourceChanged' | 'TargetChanged' | 'Rejected' | 'HostError' | 'UpdateFailed' | 'RollbackFailed' | 'WindowUnavailable';
export interface TabViewHostCancelled {
    Status: 'Cancelled';
    Reason: TabViewHostCancellationReason;
    Error?: unknown;
    RollbackErrors?: readonly unknown[];
}
export interface TabViewHostAccepted<T = unknown> {
    Status: 'Accepted';
    Items: readonly T[];
    NewWindowId?: TabViewWindowId;
    Target?: TabViewHostSource<T>;
    DropIndex?: number;
}
export type TabViewHostResult<T = unknown> = TabViewHostAccepted<T> | TabViewHostCancelled;
export type TabViewHostDecision = {
    Status: 'Accepted';
} | TabViewHostCancelled;
type Awaitable<T> = T | Promise<T>;
/**
 * Write must publish synchronously to Read. Vue reactive arrays, React external
 * stores, Angular signals, and Svelte stores can all implement this contract.
 * React component state can mirror the store in its subscription.
 */
export interface TabViewHostSource<T = unknown> {
    Read(): readonly T[];
    Write(Items: readonly T[]): void;
    ReadSelectedItem?(): T | null | undefined;
    WriteSelectedItem?(Item: T | null): void;
}
export interface TabViewHostRequest<T = unknown> {
    Source: TabViewHostSource<T>;
    Items: readonly T[];
    Tabs: readonly unknown[];
    Signal?: AbortSignal;
    Pointer?: {
        ScreenX: number;
        ScreenY: number;
    };
}
export interface TabViewHostMoveRequest<T = unknown> extends TabViewHostRequest<T> {
    Target: TabViewHostSource<T>;
    DropIndex: number;
}
export interface TabViewHostSplitRequest<T = unknown> extends TabViewHostRequest<T> {
    Edge: TabViewSplitEdge;
}
export interface TabViewHostTearOutRequest<T = unknown> extends TabViewHostRequest<T> {
    NewWindowId: TabViewWindowId;
}
export interface TabViewHostDestination<T = unknown> {
    Status: 'Accepted';
    NewWindowId: TabViewWindowId;
    Target: TabViewHostSource<T>;
    /** Finish preparing the destination before either collection changes. */
    Commit?(Request: TabViewHostMoveRequest<T>): Awaitable<TabViewHostDecision | void>;
    /** Release a prepared window or pane when its transfer is cancelled. */
    Dispose?(): Awaitable<void>;
}
export interface TabViewHostOptions<T = unknown> {
    CreateWindow?(Request: TabViewHostRequest<T>): Awaitable<TabViewHostDestination<T> | TabViewHostCancelled>;
    Split?(Request: TabViewHostSplitRequest<T>): Awaitable<TabViewHostDestination<T> | TabViewHostCancelled>;
    Move?(Request: TabViewHostMoveRequest<T>): Awaitable<TabViewHostDecision | void>;
    /** Optional framework batching. The supplied operation must run synchronously. */
    Batch?(Operation: () => void): void;
}
export interface TabViewHostAdapter<T = unknown> {
    CreateWindow(Request: TabViewHostRequest<T>): Promise<TabViewHostResult<T>>;
    TearOut(Request: TabViewHostTearOutRequest<T>): Promise<TabViewHostResult<T>>;
    OpenWindow(Request: TabViewHostRequest<T>): Promise<TabViewHostResult<T>>;
    Move(Request: TabViewHostMoveRequest<T>): Promise<TabViewHostResult<T>>;
    Split(Request: TabViewHostSplitRequest<T>): Promise<TabViewHostResult<T>>;
    CancelWindow(NewWindowId: TabViewWindowId): Promise<void>;
    Dispose(): Promise<void>;
}
export declare function createTabViewCallbackSource<T>(Callbacks: TabViewHostSource<T>): TabViewHostSource<T>;
export interface TabViewMutableCollection<T> {
    readonly Count?: number;
    readonly Size?: number;
    GetAt?(Index: number): T;
    [Symbol.iterator]?(): Iterator<T>;
    RemoveAt(Index: number): unknown;
    InsertAt?(Index: number, Item: T): unknown;
    Insert?(Index: number, Item: T): unknown;
}
type SelectionCallbacks<T> = Pick<TabViewHostSource<T>, 'ReadSelectedItem' | 'WriteSelectedItem'>;
/** Adapts TabItems without clearing unaffected containers or their selection. */
export declare function createTabViewMutableCollectionSource<T>(Collection: TabViewMutableCollection<T>, Selection?: SelectionCallbacks<T>): TabViewHostSource<T>;
/**
 * CreateWindow corresponds to TabTearOutWindowRequested; TearOut corresponds to
 * TabTearOutRequested. The host owns actual windows and panes after acceptance.
 */
export declare function createTabViewHostAdapter<T = unknown>(Options?: TabViewHostOptions<T>): TabViewHostAdapter<T>;
export {};
