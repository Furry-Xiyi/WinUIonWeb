import type { InjectionKey } from 'vue';
export interface FlyoutInputContext {
    allowsHover(event: PointerEvent): boolean;
}
export declare const flyoutInputContextKey: InjectionKey<FlyoutInputContext>;
export interface FlyoutInputRegion {
    readonly Owner: unknown;
    readonly IsOpen: boolean;
    readonly Target: HTMLElement | null;
    readonly Presenter: HTMLElement | null;
    readonly DismissLayer: HTMLElement | null;
    Hide(restoreFocus?: boolean): void;
}
export declare const registerFlyoutInputRegion: (region: FlyoutInputRegion) => () => void;
export declare const isDescendantFlyoutOpening: (owner: unknown, ancestor: FlyoutInputRegion) => boolean;
export declare const hasOpenDescendantFlyout: (ancestor: FlyoutInputRegion) => boolean;
export declare const flyoutContainsNode: (ancestor: FlyoutInputRegion, node: Node | null) => boolean;
export declare const hideDescendantFlyouts: (ancestor: FlyoutInputRegion) => void;
export declare const nestedFlyoutLayers: (region: FlyoutInputRegion) => {
    overlay: number;
    presenter: number;
} | null;
