import { type Ref } from 'vue';
export type GridDefinition = Record<string, unknown>;
export declare const gridDefinitionContextKey: unique symbol;
export declare const gridDefinitionTargetKey: unique symbol;
export declare const cssLength: (value: unknown) => string;
/** XAML Thickness is ordered left,top,right,bottom; CSS is top,right,bottom,left. */
export declare const xamlThickness: (value: unknown) => string;
export declare const alignment: (value: unknown, axis: "horizontal" | "vertical") => string;
export declare const boolValue: (value: unknown) => boolean;
export declare const attachedValue: (element: Element, name: string) => string | undefined;
/** ContentPresenter arranges its sole UIElement inside the content alignment slot. */
export declare const applyContentPresenterChildren: (root: HTMLElement, horizontalContentAlignment: unknown, verticalContentAlignment: unknown) => void;
export declare const applyGridChildren: (root: HTMLElement) => void;
export declare const applyStackChildren: (root: HTMLElement, orientation: string) => void;
export declare const applyVariableSizedChildren: (root: HTMLElement) => void;
export declare const useLayoutObserver: (root: Ref<HTMLElement | null>, apply: () => void) => void;
