declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    IsOpen: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    Target: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    Title: {
        type: StringConstructor;
        default: string;
    };
    Subtitle: {
        type: StringConstructor;
        default: string;
    };
    Content: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: null;
    };
    HeroContent: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: null;
    };
    ActionButtonContent: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: null;
    };
    CloseButtonContent: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: null;
    };
    ActionButtonStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    CloseButtonStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    ActionButtonCommand: {
        type: (StringConstructor | ObjectConstructor | FunctionConstructor)[];
        default: null;
    };
    ActionButtonCommandParameter: {
        default: null;
    };
    CloseButtonCommand: {
        type: (StringConstructor | ObjectConstructor | FunctionConstructor)[];
        default: null;
    };
    CloseButtonCommandParameter: {
        default: null;
    };
    IconSource: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    TailVisibility: {
        type: StringConstructor;
        default: string;
    };
    PreferredPlacement: {
        type: StringConstructor;
        default: string;
    };
    PlacementMargin: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: number;
    };
    ShouldConstrainToRootBounds: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsLightDismissEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    HeroContentPlacement: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
}>, {
    IsOpen: import("vue").WritableComputedRef<boolean, boolean>;
    Target: import("vue").WritableComputedRef<unknown, unknown>;
    Title: import("vue").WritableComputedRef<unknown, unknown>;
    Subtitle: import("vue").WritableComputedRef<unknown, unknown>;
    Element: import("vue").Ref<HTMLElement | null, HTMLElement | null>;
    TemplateSettings: import("vue").ComputedRef<{
        IconElement: unknown;
    }>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    Opened: (...args: any[]) => void;
    Closing: (...args: any[]) => void;
    Closed: (...args: any[]) => void;
    CloseButtonClick: (...args: any[]) => void;
    ActionButtonClick: (...args: any[]) => void;
    "update:IsOpen": (...args: any[]) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    IsOpen: {
        type: (StringConstructor | BooleanConstructor)[];
        default: undefined;
    };
    Target: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    Title: {
        type: StringConstructor;
        default: string;
    };
    Subtitle: {
        type: StringConstructor;
        default: string;
    };
    Content: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: null;
    };
    HeroContent: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: null;
    };
    ActionButtonContent: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: null;
    };
    CloseButtonContent: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: null;
    };
    ActionButtonStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    CloseButtonStyle: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    ActionButtonCommand: {
        type: (StringConstructor | ObjectConstructor | FunctionConstructor)[];
        default: null;
    };
    ActionButtonCommandParameter: {
        default: null;
    };
    CloseButtonCommand: {
        type: (StringConstructor | ObjectConstructor | FunctionConstructor)[];
        default: null;
    };
    CloseButtonCommandParameter: {
        default: null;
    };
    IconSource: {
        type: (StringConstructor | ObjectConstructor)[];
        default: null;
    };
    TailVisibility: {
        type: StringConstructor;
        default: string;
    };
    PreferredPlacement: {
        type: StringConstructor;
        default: string;
    };
    PlacementMargin: {
        type: (NumberConstructor | StringConstructor | ObjectConstructor)[];
        default: number;
    };
    ShouldConstrainToRootBounds: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    IsLightDismissEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    HeroContentPlacement: {
        type: StringConstructor;
        default: string;
    };
    RequestedTheme: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
}>> & Readonly<{
    onOpened?: ((...args: any[]) => any) | undefined;
    onClosing?: ((...args: any[]) => any) | undefined;
    onClosed?: ((...args: any[]) => any) | undefined;
    onCloseButtonClick?: ((...args: any[]) => any) | undefined;
    onActionButtonClick?: ((...args: any[]) => any) | undefined;
    "onUpdate:IsOpen"?: ((...args: any[]) => any) | undefined;
}>, {
    Foreground: string;
    IconSource: string | Record<string, any>;
    Background: string;
    BorderBrush: string;
    BorderThickness: string | number;
    CornerRadius: string | number;
    RequestedTheme: string;
    CloseButtonStyle: string | Record<string, any>;
    Content: string | number | Record<string, any>;
    Target: string | Record<string, any>;
    IsOpen: string | boolean;
    ShouldConstrainToRootBounds: string | boolean;
    Title: string;
    Subtitle: string;
    CloseButtonCommand: string | Function | Record<string, any>;
    CloseButtonCommandParameter: null;
    IsLightDismissEnabled: string | boolean;
    HeroContent: string | number | Record<string, any>;
    ActionButtonContent: string | number | Record<string, any>;
    CloseButtonContent: string | number | Record<string, any>;
    ActionButtonStyle: string | Record<string, any>;
    ActionButtonCommand: string | Function | Record<string, any>;
    ActionButtonCommandParameter: null;
    TailVisibility: string;
    PreferredPlacement: string;
    PlacementMargin: string | number | Record<string, any>;
    HeroContentPlacement: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
