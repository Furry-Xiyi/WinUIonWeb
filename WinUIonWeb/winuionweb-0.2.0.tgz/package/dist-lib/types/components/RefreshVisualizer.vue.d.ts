import { type RefreshRequestedEventArgs, type RefreshStateChangedEventArgs, type RefreshVisualizerState } from './refreshRuntime';
import { RefreshVisualizerContent } from './RefreshProperties';
export { RefreshVisualizerContent };
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Orientation: {
        type: StringConstructor;
        default: string;
    };
    Content: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
}>, import("vue").Raw<{
    RequestRefresh: () => void;
    readonly State: RefreshVisualizerState;
    readonly Content: HTMLElement | null;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    RefreshRequested: (sender: unknown, args: RefreshRequestedEventArgs) => any;
    RefreshStateChanged: (sender: unknown, args: RefreshStateChangedEventArgs) => any;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Orientation: {
        type: StringConstructor;
        default: string;
    };
    Content: {
        type: (StringConstructor | ObjectConstructor)[];
        default: string;
    };
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    Foreground: {
        type: StringConstructor;
        default: string;
    };
    IsEnabled: {
        type: (StringConstructor | BooleanConstructor)[];
        default: boolean;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onRefreshRequested?: ((sender: unknown, args: RefreshRequestedEventArgs) => any) | undefined;
    onRefreshStateChanged?: ((sender: unknown, args: RefreshStateChangedEventArgs) => any) | undefined;
}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Foreground: string;
    IsEnabled: string | boolean;
    Background: string;
    Visibility: string;
    Content: string | Record<string, any>;
    Orientation: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
