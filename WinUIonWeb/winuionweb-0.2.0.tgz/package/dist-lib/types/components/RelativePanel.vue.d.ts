export declare const RelativePanelResources: import("vue").DefineComponent<{}, () => null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    BackgroundSizing: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    Width: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Height: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MinHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxWidth: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    MaxHeight: {
        type: (NumberConstructor | StringConstructor)[];
        default: string;
    };
    Background: {
        type: StringConstructor;
        default: string;
    };
    BackgroundSizing: {
        type: StringConstructor;
        default: string;
    };
    BorderBrush: {
        type: StringConstructor;
        default: string;
    };
    BorderThickness: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    CornerRadius: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Padding: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    Margin: {
        type: (NumberConstructor | StringConstructor)[];
        default: number;
    };
    HorizontalAlignment: {
        type: StringConstructor;
        default: string;
    };
    VerticalAlignment: {
        type: StringConstructor;
        default: string;
    };
    Visibility: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{}>, {
    Width: string | number;
    Height: string | number;
    MinWidth: string | number;
    MaxWidth: string | number;
    MinHeight: string | number;
    MaxHeight: string | number;
    Margin: string | number;
    Padding: string | number;
    HorizontalAlignment: string;
    VerticalAlignment: string;
    Background: string;
    BorderBrush: string;
    BorderThickness: string | number;
    CornerRadius: string | number;
    BackgroundSizing: string;
    Visibility: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
